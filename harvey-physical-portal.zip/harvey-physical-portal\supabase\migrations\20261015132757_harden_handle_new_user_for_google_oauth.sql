/*
# Harden handle_new_user trigger for Google OAuth sign-ups

Google OAuth may store the user's display name under different keys in
raw_user_meta_data depending on the Supabase version. This update adds
fallbacks for 'user_metadata->>name' and 'metadata->>name' to ensure
the profile is always created with the correct full_name.

Also ensures is_admin defaults to false for Google sign-ups (regular student).
*/

CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_full_name text;
BEGIN
  v_full_name := COALESCE(
    NEW.raw_user_meta_data->>'full_name',
    NEW.raw_user_meta_data->>'name',
    NEW.raw_user_meta_data->'user_metadata'->>'name',
    NEW.raw_user_meta_data->'metadata'->>'name',
    NEW.raw_user_meta_data->>'user_full_name',
    ''
  );

  INSERT INTO public.profiles (id, email, full_name, is_admin)
  VALUES (NEW.id, NEW.email, v_full_name, false);

  RETURN NEW;
END;
$$;
