/*
# Auto-promote owner email to admin

When a user with the owner's email (mohamed.ali.eldefrawi@gmail.com) signs up,
automatically set is_admin = true on their profile.

This is done via a trigger on the profiles table that checks the email column
after insert and promotes the owner.
*/

CREATE OR REPLACE FUNCTION public.promote_owner_admin()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF NEW.email = 'mal949100@gmail.com' THEN
    NEW.is_admin := true;
  END IF;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS on_profile_owner_promote ON profiles;
CREATE TRIGGER on_profile_owner_promote
  BEFORE INSERT OR UPDATE ON profiles
  FOR EACH ROW EXECUTE FUNCTION public.promote_owner_admin();
