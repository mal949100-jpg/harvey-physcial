import { useState } from 'react';
import { BookOpen, FileText, ChevronDown, ChevronLeft, GraduationCap, Calculator, TriangleAlert, ListChecks, Lightbulb } from 'lucide-react';
import { lessons, chapters, getDeepDiveContent } from '@/data/lessons';
import { chapterSoft } from '@/lib/chapterTheme';

export default function SummariesSection() {
  const [expandedLesson, setExpandedLesson] = useState<number | null>(null);
  const [selectedChapter, setSelectedChapter] = useState<number>(1);

  const chapterLessons = lessons.filter((l) => l.chapter === selectedChapter);

  return (
    <div className="space-y-6">
      <div className="bg-white dark:bg-slate-900 rounded-2xl p-6 shadow-sm border border-slate-100 dark:border-slate-800">
        <div className="flex items-center gap-3 mb-4">
          <div className="w-12 h-12 bg-emerald-50 dark:bg-emerald-500/15 rounded-xl flex items-center justify-center">
            <FileText className="w-6 h-6 text-emerald-600 dark:text-emerald-300" />
          </div>
          <div>
            <h2 className="text-xl font-bold text-slate-800 dark:text-slate-100">الملخصات</h2>
            <p className="text-sm text-slate-500 dark:text-slate-300">ملخصات منظمة لكل فصل ودروس المنهج</p>
          </div>
        </div>

        {/* Chapter selector */}
        <div className="flex gap-2 flex-wrap">
          {chapters.map((ch) => (
            <button
              key={ch.id}
              onClick={() => setSelectedChapter(ch.id)}
              className={`px-4 py-2 rounded-xl text-sm font-bold transition-all text-right ${
                selectedChapter === ch.id
                  ? 'bg-primary-600 text-white shadow-lg shadow-primary-600/30'
                  : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700'
              }`}
            >
              <span className="block">{ch.title}</span>
              <span className="block text-[11px] font-normal opacity-80">{ch.subtitle}</span>
            </button>
          ))}
        </div>
      </div>

      <div className="space-y-3">
        {chapterLessons.map((lesson) => {
          const isOpen = expandedLesson === lesson.id;
          return (
            <div
              key={lesson.id}
              className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-100 dark:border-slate-800 shadow-sm overflow-hidden transition-all hover:shadow-md"
            >
              <button
                onClick={() => setExpandedLesson(isOpen ? null : lesson.id)}
                className="w-full flex items-center gap-3 p-4 text-right hover:bg-slate-50/50 transition-colors"
              >
                <div className="w-10 h-10 bg-emerald-50 dark:bg-emerald-500/15 rounded-lg flex items-center justify-center flex-shrink-0">
                  <BookOpen className="w-5 h-5 text-emerald-600 dark:text-emerald-300" />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className={`text-[10px] px-2 py-0.5 rounded-full font-bold ${chapterSoft[lesson.chapter]}`}>
                      درس {lesson.id}
                    </span>
                    <h3 className="font-bold text-slate-700 dark:text-slate-100 text-sm">{lesson.title}</h3>
                  </div>
                </div>
                <ChevronDown
                  className={`w-5 h-5 text-slate-400 dark:text-slate-500 transition-transform ${
                    isOpen ? 'rotate-180' : ''
                  }`}
                />
              </button>

              {isOpen && (() => {
                const deepDive = getDeepDiveContent(lesson);
                return (
                  <div className="px-4 pb-5 animate-slide-down">
                    <div className="border-t border-slate-100 dark:border-slate-800 pt-4 space-y-5">
                      <section>
                        <div className="flex items-center gap-2 mb-2">
                          <GraduationCap className="w-5 h-5 text-primary-600 dark:text-primary-300" />
                          <h4 className="font-bold text-slate-700 dark:text-slate-100">مقدمة ومدخل للمفهوم العلمي</h4>
                        </div>
                        <p className="text-sm text-slate-600 dark:text-slate-300 leading-8">{deepDive.introduction}</p>
                      </section>

                      <section className="bg-primary-50 dark:bg-primary-500/15 rounded-xl p-4 border border-primary-100 dark:border-primary-500/30">
                        <div className="flex items-center gap-2 mb-3">
                          <BookOpen className="w-5 h-5 text-primary-600 dark:text-primary-300" />
                          <h4 className="font-bold text-slate-700 dark:text-slate-100">السكريبت الكامل للشرح</h4>
                        </div>
                        <div className="space-y-3">
                          {deepDive.lectureScript.map((paragraph, idx) => <p key={idx} className="text-xs text-slate-700 dark:text-slate-100 leading-8">{paragraph}</p>)}
                        </div>
                      </section>

                      <section>
                        <h4 className="font-bold text-slate-700 dark:text-slate-100 mb-2">المفاهيم الأساسية</h4>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                          {lesson.concepts.map((concept, idx) => (
                            <div key={idx} className="bg-slate-50 dark:bg-slate-800 rounded-lg p-3 border border-slate-100 dark:border-slate-800">
                              <p className="text-xs font-bold text-primary-700 dark:text-primary-300 mb-1">{concept.title}</p>
                              <p className="text-xs text-slate-600 dark:text-slate-300 leading-7">{concept.detail}</p>
                            </div>
                          ))}
                        </div>
                      </section>

                      <section>
                        <div className="flex items-center gap-2 mb-3">
                          <BookOpen className="w-5 h-5 text-primary-600 dark:text-primary-300" />
                          <h4 className="font-bold text-slate-700 dark:text-slate-100">كبسولة المراجعة السريعة</h4>
                        </div>
                        <ol className="list-decimal list-inside space-y-1.5 bg-emerald-50 dark:bg-emerald-500/15 rounded-xl p-4 text-xs text-slate-700 dark:text-slate-100 leading-7 border border-emerald-100 dark:border-emerald-500/30">
                          {deepDive.capsule.map((point, idx) => <li key={idx}>{point}</li>)}
                        </ol>
                      </section>

                      <section>
                        <h4 className="font-bold text-slate-700 dark:text-slate-100 mb-2">المصطلحات وتعريفاتها</h4>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                          {deepDive.terminology.map((entry, idx) => (
                            <div key={idx} className="bg-white dark:bg-slate-900 rounded-lg p-3 border border-primary-100 dark:border-primary-500/30">
                              <p className="text-xs font-bold text-primary-700 dark:text-primary-300 mb-1">{entry.term}</p>
                              <p className="text-xs text-slate-600 dark:text-slate-300 leading-7">{entry.meaning}</p>
                            </div>
                          ))}
                        </div>
                      </section>

                      <section>
                        <div className="flex items-center gap-2 mb-2">
                          <ListChecks className="w-5 h-5 text-emerald-600 dark:text-emerald-300" />
                          <h4 className="font-bold text-slate-700 dark:text-slate-100">الملاحظات الهامة</h4>
                        </div>
                        <ul className="list-disc list-inside space-y-1 text-xs text-slate-700 dark:text-slate-100 leading-7">
                          {deepDive.notes.map((note, idx) => <li key={idx}>{note}</li>)}
                        </ul>
                      </section>

                      <section>
                        <div className="flex items-center gap-2 mb-2">
                          <Lightbulb className="w-5 h-5 text-amber-500 dark:text-amber-300" />
                          <h4 className="font-bold text-slate-700 dark:text-slate-100">علل لما يأتي — الإجابة النموذجية</h4>
                        </div>
                        <div className="space-y-2">
                          {deepDive.reasons.map((reason, idx) => (
                            <div key={idx} className="bg-slate-50 dark:bg-slate-800 rounded-lg p-3 border border-slate-100 dark:border-slate-800">
                              <p className="text-xs font-bold text-slate-700 dark:text-slate-100 leading-7">{idx + 1}. {reason.question}</p>
                              <p className="text-[11px] text-slate-600 dark:text-slate-300 leading-7 mt-1">{reason.answer}</p>
                            </div>
                          ))}
                        </div>
                      </section>

                      <section>
                        <div className="flex items-center gap-2 mb-2">
                          <Calculator className="w-5 h-5 text-emerald-600 dark:text-emerald-300" />
                          <h4 className="font-bold text-slate-700 dark:text-slate-100">الاستنتاجات والقوانين</h4>
                        </div>
                        <div className="space-y-2">
                          {deepDive.derivations.map((derivation, idx) => (
                            <div key={idx} className="bg-emerald-50 dark:bg-emerald-500/15 rounded-lg p-3 border border-emerald-100 dark:border-emerald-500/30">
                              <p className="text-xs font-bold text-emerald-800 dark:text-emerald-200 mb-1">{derivation.title}</p>
                              <ol className="list-decimal list-inside space-y-1 text-[11px] text-slate-700 dark:text-slate-100 leading-7">
                                {derivation.steps.map((step, stepIdx) => <li key={stepIdx}>{step}</li>)}
                              </ol>
                              <p className="text-[11px] font-bold text-emerald-800 dark:text-emerald-200 mt-2 leading-7">النتائج المترتبة:</p>
                              <ul className="list-disc list-inside space-y-1 text-[11px] text-slate-700 dark:text-slate-100 leading-7">
                                {derivation.results.map((result, resultIdx) => <li key={resultIdx}>{result}</li>)}
                              </ul>
                              <p className="text-[11px] text-emerald-800 dark:text-emerald-200 mt-2 leading-7">{derivation.note}</p>
                            </div>
                          ))}
                        </div>
                      </section>

                      <section>
                        <h4 className="font-bold text-slate-700 dark:text-slate-100 mb-2">القوانين والرموز والوحدات</h4>
                        <div className="space-y-1.5">
                          {lesson.laws.map((law, idx) => (
                            <div key={idx} className="flex items-center gap-3 bg-amber-50 dark:bg-amber-500/15 rounded-lg p-2.5 border border-amber-100 dark:border-amber-500/30">
                              <ChevronLeft className="w-4 h-4 text-amber-600 dark:text-amber-300 flex-shrink-0" />
                              <div className="flex-1">
                                <p className="text-xs font-bold text-slate-700 dark:text-slate-100">{law.name}</p>
                                <p className="text-xs text-primary-700 dark:text-primary-300 font-semibold" dir="ltr">{law.formula}</p>
                                <p className="text-[11px] text-slate-500 dark:text-slate-300 leading-6">{law.explanation}</p>
                              </div>
                              <span className="text-[10px] px-2 py-0.5 bg-white dark:bg-slate-900 text-amber-700 dark:text-amber-300 rounded-full font-semibold">{law.units}</span>
                            </div>
                          ))}
                        </div>
                      </section>

                      <section className="bg-amber-50 dark:bg-amber-500/15 rounded-xl p-4 border border-amber-100 dark:border-amber-500/30">
                        <div className="flex items-center gap-2 mb-2">
                          <TriangleAlert className="w-5 h-5 text-amber-600 dark:text-amber-300" />
                          <h4 className="font-bold text-slate-700 dark:text-slate-100">تريكات الامتحان والنقاط الخفية</h4>
                        </div>
                        <ul className="list-disc list-inside space-y-1 text-xs text-slate-700 dark:text-slate-100 leading-7">
                          {deepDive.pitfalls.map((pitfall, idx) => <li key={idx}>{pitfall}</li>)}
                        </ul>
                      </section>

                      <section>
                        <div className="flex items-center gap-2 mb-2">
                          <ListChecks className="w-5 h-5 text-blue-600 dark:text-blue-300" />
                          <h4 className="font-bold text-slate-700 dark:text-slate-100">إطار حل المسائل خطوة بخطوة</h4>
                        </div>
                        <ol className="list-decimal list-inside space-y-1 bg-blue-50 dark:bg-blue-500/15 rounded-lg p-3 text-xs text-slate-700 dark:text-slate-100 leading-7">
                          {deepDive.problemFramework.map((step, idx) => <li key={idx}>{step}</li>)}
                        </ol>
                      </section>

                      <section>
                        <h4 className="font-bold text-slate-700 dark:text-slate-100 mb-2">أمثلة محلولة بالتفصيل</h4>
                        <div className="space-y-2">
                          {lesson.questions.map((question, idx) => (
                            <div key={idx} className="bg-white dark:bg-slate-900 rounded-lg p-3 border border-slate-200 dark:border-slate-700">
                              <p className="text-xs font-bold text-slate-700 dark:text-slate-100 leading-7">سؤال {idx + 1}: {question.q}</p>
                              <ol className="list-decimal list-inside space-y-1 mt-2 text-[11px] text-slate-600 dark:text-slate-300 leading-7">
                                {question.steps.map((step, stepIdx) => <li key={stepIdx}>{step}</li>)}
                              </ol>
                              <p className="text-xs font-bold text-primary-700 dark:text-primary-300 mt-2">الإجابة: {question.answer}</p>
                            </div>
                          ))}
                        </div>
                      </section>
                    </div>
                  </div>
                );
              })()}
            </div>
          );
        })}
      </div>
    </div>
  );
}
