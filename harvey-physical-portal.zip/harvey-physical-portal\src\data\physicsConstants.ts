/**
 * Physical constants used by the question generators.
 *
 * The ministry textbook (كتاب الوزارة) never assumes one fixed value for g: every
 * problem states the value the student should use (9.8 m/s² on Earth, sometimes 10
 * for mental arithmetic, 1.6 on the Moon). Generated problems therefore pick a
 * value per question and print it inside the question text.
 */

export interface GravityPreset {
  value: number;
  /** Where the value applies — appended to the problem statement. */
  context: string;
}

export const GRAVITY_EARTH: GravityPreset = { value: 9.8, context: 'على سطح الأرض' };
export const GRAVITY_EARTH_PRECISE: GravityPreset = { value: 9.81, context: 'على سطح الأرض' };
export const GRAVITY_EARTH_ROUNDED: GravityPreset = { value: 10, context: 'على سطح الأرض' };
export const GRAVITY_MOON: GravityPreset = { value: 1.6, context: 'على سطح القمر' };

/**
 * Ordered as in the textbook: 9.8 is the default, 10 only appears when the problem
 * is meant to be solved without a calculator.
 */
export const GRAVITY_MODEL: GravityPreset[] = [
  GRAVITY_EARTH,
  GRAVITY_EARTH,
  GRAVITY_EARTH_PRECISE,
  GRAVITY_EARTH_ROUNDED,
];

/** Constants referenced by name in explanations so no file hardcodes its own copy. */
export const PHYSICAL_CONSTANTS = {
  G: 6.67e-11,
  EARTH_MASS: 6e24,
  EARTH_RADIUS: 6.4e6,
  SPEED_OF_LIGHT: 3e8,
} as const;

/** How the ministry writes the given value inside a problem statement. */
export function gravityNote(value: number, context?: string): string {
  const place = context && context !== 'على سطح الأرض' ? ` ${context}` : '';
  return `(خذ g = ${value} m/s²${place})`;
}
