import { useEffect, useRef, useState } from 'react';
import {
  Database,
  Download,
  Upload,
  Trash2,
  Save,
  Timer,
  Copy,
  Check,
  AlertTriangle,
} from 'lucide-react';
import { useAuth } from '@/context/AuthContext';
import {
  clearAllGuestData,
  exportSnapshot,
  getChats,
  getFlashcardProgress,
  getGuestId,
  getMockExamDraft,
  getQuizDraft,
  getQuizResults,
  importSnapshot,
  isStorageWorking,
  storageUsageBytes,
} from '@/lib/guestStorage';
import { getExamPlan } from '@/data/examPlans';

interface Counts {
  chats: number;
  results: number;
  cards: number;
  draft: boolean;
  mockRunning: boolean;
  bytes: number;
}

function readCounts(): Counts {
  const mockDraft = getMockExamDraft();
  return {
    chats: getChats().length,
    results: getQuizResults().length,
    cards: Object.keys(getFlashcardProgress()).length,
    draft: getQuizDraft() !== null,
    mockRunning:
      mockDraft !== null && mockDraft.endsAt > Date.now() && getExamPlan(mockDraft.examId) !== undefined,
    bytes: storageUsageBytes(),
  };
}

export default function MyDataSection() {
  const { profile, setProfileName } = useAuth();
  const [counts, setCounts] = useState<Counts>(readCounts);
  const [storageOk, setStorageOk] = useState(true);
  const [copied, setCopied] = useState(false);
  const [message, setMessage] = useState<string | null>(null);
  const [failedMessage, setFailedMessage] = useState(false);
  const [confirmWipe, setConfirmWipe] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    setCounts(readCounts());
    setStorageOk(isStorageWorking());
  }, []);

  const guestId = getGuestId();

  const flash = (text: string, isError: boolean) => {
    setMessage(text);
    setFailedMessage(isError);
  };

  const downloadBackup = () => {
    const blob = new Blob([JSON.stringify(exportSnapshot(), null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `harvey-physical-backup-${new Date().toISOString().slice(0, 10)}.json`;
    link.click();
    URL.revokeObjectURL(url);
    flash('تم تنزيل نسخة احتياطية بكل بياناتك على هذا الجهاز.', false);
  };

  const restoreFromFile = async (file: File) => {
    const text = await file.text();
    const imported = importSnapshot(text);
    if (!imported) {
      flash('الملف غير صالح — تأكد أنه نسخة مُنزّلة من منصة هارفي فيزيكال.', true);
      return;
    }
    setCounts(readCounts());
    flash(
      `تم استعادة ${imported.chats} محادثة و${imported.results} نتيجة اختبار و${imported.cards} بطاقة.`,
      false,
    );
  };

  const wipeEverything = () => {
    clearAllGuestData();
    setCounts(readCounts());
    setConfirmWipe(false);
    flash('تم حذف كل البيانات المحلية ما عدا معرّف الجهاز والاسم.', false);
  };

  const copyId = async () => {
    try {
      await navigator.clipboard.writeText(guestId);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch {
      flash('انسخ المعرّف يدوياً من المربع.', true);
    }
  };

  return (
    <div className="space-y-6">
      <div className="bg-white dark:bg-slate-900 rounded-2xl p-6 shadow-sm border border-slate-100 dark:border-slate-800">
        <div className="flex items-center gap-3 mb-4">
          <div className="w-12 h-12 bg-cyan-50 dark:bg-cyan-500/15 rounded-xl flex items-center justify-center">
            <Database className="w-6 h-6 text-cyan-600 dark:text-cyan-300" />
          </div>
          <div>
            <h2 className="text-xl font-bold text-slate-800 dark:text-slate-100">بياناتي ونسخة احتياطية</h2>
            <p className="text-sm text-slate-500 dark:text-slate-300">
              كل تقدّمك محفوظ على هذا الجهاز فقط — بلا حساب ولا بريد إلكتروني
            </p>
          </div>
        </div>

        {!storageOk && (
          <div className="flex items-start gap-2 rounded-xl bg-rose-50 dark:bg-rose-500/15 border border-rose-100 dark:border-rose-500/30 p-4">
            <AlertTriangle className="w-5 h-5 text-rose-600 dark:text-rose-300 flex-shrink-0 mt-0.5" />
            <p className="text-sm text-rose-700 dark:text-rose-300 font-semibold">
              تخزين هذا الجهاز مقفل (وضع تصفّح خاص أو مساحة المتصفح ممتلئة)، لذا إجاباتك لن تُحفظ بعد
              إغلاق الصفحة. استخدم متصفحاً آخر أو اخرج من الوضع الخاص.
            </p>
          </div>
        )}
      </div>

      <div className="bg-white dark:bg-slate-900 rounded-2xl p-6 shadow-sm border border-slate-100 dark:border-slate-800">
        <h3 className="font-bold text-slate-800 dark:text-slate-100 mb-1">هوية الطالب على الجهاز</h3>
        <p className="text-xs text-slate-500 dark:text-slate-300 mb-4">
          الاسم يظهر في الشريط الجانبي ويُستخدم للترحيب. معرّف الجهاز يربط كل بياناتك ببعضها ولا يُرسل
          لأي مكان.
        </p>

        <label className="block mb-4">
          <span className="block text-xs font-bold text-slate-600 dark:text-slate-300 mb-1.5">اسمك</span>
          <input
            type="text"
            value={profile.full_name}
            onChange={(e) => setProfileName(e.target.value)}
            placeholder="مثال: أحمد محمد"
            className="w-full max-w-sm px-4 py-2.5 bg-slate-100 dark:bg-slate-800 rounded-xl border border-transparent focus:border-primary-400 focus:bg-white dark:focus:bg-slate-900 focus:ring-2 focus:ring-primary-100 dark:focus:ring-primary-500/30 transition-all text-sm text-slate-700 dark:text-slate-100 placeholder:text-slate-400 dark:placeholder:text-slate-500 outline-none"
          />
        </label>

        <span className="block text-xs font-bold text-slate-600 dark:text-slate-300 mb-1.5">معرّف الجهاز</span>
        <div className="flex items-center gap-2 max-w-sm">
          <code
            dir="ltr"
            className="flex-1 px-3 py-2.5 bg-slate-100 dark:bg-slate-800 rounded-xl text-xs text-slate-600 dark:text-slate-300 font-mono truncate"
          >
            {guestId}
          </code>
          <button
            onClick={() => void copyId()}
            className="flex items-center gap-1.5 px-3 py-2.5 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-600 dark:text-slate-300 rounded-xl text-xs font-bold transition-all flex-shrink-0"
          >
            {copied ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
            {copied ? 'تم' : 'نسخ'}
          </button>
        </div>
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        <StatCard label="محادثات محفوظة" value={counts.chats} />
        <StatCard label="نتائج اختبارات" value={counts.results} />
        <StatCard label="بطاقات مُراجَعة" value={counts.cards} />
        <StatCard label="مساحة مستخدمة" value={`${Math.round(counts.bytes / 1024)} KB`} />
      </div>

      {counts.draft && (
        <div className="bg-white dark:bg-slate-900 rounded-2xl p-4 shadow-sm border border-slate-100 dark:border-slate-800 flex items-center gap-3">
          <Save className="w-5 h-5 text-emerald-600 dark:text-emerald-300 flex-shrink-0" />
          <p className="text-sm text-slate-600 dark:text-slate-300">
            لديك محاولة اختبار غير مكتملة محفوظة — ستجدها تنتظرك في قسم الاختبارات التفاعلية.
          </p>
        </div>
      )}

      {counts.mockRunning && (
        <div className="bg-white dark:bg-slate-900 rounded-2xl p-4 shadow-sm border border-slate-100 dark:border-slate-800 flex items-center gap-3">
          <Timer className="w-5 h-5 text-amber-600 dark:text-amber-300 flex-shrink-0" />
          <p className="text-sm text-slate-600 dark:text-slate-300">
            امتحان تجريبي ما زال شغالاً على جهازك — المؤقّت يستمر حتى لو أغلقت الصفحة، وارجع له من قسم الامتحانات قبل أن ينتهي الوقت.
          </p>
        </div>
      )}

      {message && (
        <div
          className={`rounded-xl p-4 border text-sm font-semibold ${
            failedMessage
              ? 'bg-rose-50 dark:bg-rose-500/15 border-rose-100 dark:border-rose-500/30 text-rose-700 dark:text-rose-300'
              : 'bg-emerald-50 dark:bg-emerald-500/15 border-emerald-100 dark:border-emerald-500/30 text-emerald-700 dark:text-emerald-300'
          }`}
        >
          {message}
        </div>
      )}

      <div className="bg-white dark:bg-slate-900 rounded-2xl p-6 shadow-sm border border-slate-100 dark:border-slate-800">
        <h3 className="font-bold text-slate-800 dark:text-slate-100 mb-1">النسخة الاحتياطية</h3>
        <p className="text-xs text-slate-500 dark:text-slate-300 mb-4 leading-relaxed">
          حذف متصفح بياناته أو فتح المنصة من جهاز آخر يمحو التقدّم نهائياً. نزّل نسخة بين الحين والآخر
          لاستعادتها في أي وقت أو نقلها لجهاز جديد.
        </p>

        <div className="flex flex-wrap gap-2">
          <button
            onClick={downloadBackup}
            className="flex items-center gap-2 px-4 py-2.5 bg-primary-600 hover:bg-primary-700 text-white rounded-xl text-sm font-bold transition-all"
          >
            <Download className="w-4 h-4" />
            تنزيل نسخة
          </button>
          <button
            onClick={() => fileRef.current?.click()}
            className="flex items-center gap-2 px-4 py-2.5 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-100 rounded-xl text-sm font-bold transition-all"
          >
            <Upload className="w-4 h-4" />
            استعادة من ملف
          </button>
          <input
            ref={fileRef}
            type="file"
            accept="application/json,.json"
            className="hidden"
            onChange={(e) => {
              const file = e.target.files?.[0];
              if (file) void restoreFromFile(file);
              e.target.value = '';
            }}
          />
        </div>

        <div className="mt-6 pt-5 border-t border-slate-100 dark:border-slate-800">
          {confirmWipe ? (
            <div className="flex flex-wrap items-center gap-2">
              <span className="text-sm text-rose-700 dark:text-rose-300 font-bold">
                سيتم حذف المحادثات والنتائج والبطاقات. متأكد؟
              </span>
              <button
                onClick={wipeEverything}
                className="px-4 py-2 bg-rose-600 hover:bg-rose-700 text-white rounded-xl text-xs font-bold transition-all"
              >
                نعم، احذف كل شيء
              </button>
              <button
                onClick={() => setConfirmWipe(false)}
                className="px-4 py-2 bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 rounded-xl text-xs font-bold transition-all"
              >
                إلغاء
              </button>
            </div>
          ) : (
            <button
              onClick={() => setConfirmWipe(true)}
              className="flex items-center gap-2 px-4 py-2.5 bg-rose-50 dark:bg-rose-500/15 hover:bg-rose-100 dark:hover:bg-rose-500/25 text-rose-700 dark:text-rose-300 rounded-xl text-sm font-bold transition-all"
            >
              <Trash2 className="w-4 h-4" />
              حذف كل بياناتي المحلية
            </button>
          )}
        </div>
      </div>
    </div>
  );
}

function StatCard({ label, value }: { label: string; value: number | string }) {
  return (
    <div className="bg-white dark:bg-slate-900 rounded-2xl p-5 shadow-sm border border-slate-100 dark:border-slate-800">
      <p className="text-xs text-slate-500 dark:text-slate-300 mb-2">{label}</p>
      <p className="text-2xl font-bold text-slate-800 dark:text-slate-100">{value}</p>
    </div>
  );
}
