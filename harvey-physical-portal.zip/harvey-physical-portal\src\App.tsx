import { useEffect, useState } from 'react';
import Sidebar, { isTabId, type TabId } from '@/components/Sidebar';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import LessonsSection from '@/components/sections/LessonsSection';
import LawsSection from '@/components/sections/LawsSection';
import VideosSection from '@/components/sections/VideosSection';
import QuestionsSection from '@/components/sections/QuestionsSection';
import AssistantSection from '@/components/sections/AssistantSection';
import SavedChatsSection from '@/components/sections/SavedChatsSection';
import ExamsSection from '@/components/sections/ExamsSection';
import SummariesSection from '@/components/sections/SummariesSection';
import QuizzesSection from '@/components/sections/QuizzesSection';
import FlashcardsSection from '@/components/sections/FlashcardsSection';
import WeaknessTrackerSection from '@/components/sections/WeaknessTrackerSection';
import MyDataSection from '@/components/sections/MyDataSection';
import AdminDashboard from '@/components/sections/AdminDashboard';
import AdminLoginGate from '@/components/sections/AdminLoginGate';
import { useAuth } from '@/context/AuthContext';
import {
  getDarkModePref,
  getLastTab,
  isStorageWorking,
  setDarkModePref,
  setLastTab,
} from '@/lib/guestStorage';

function initialTab(): TabId {
  const stored = getLastTab();
  return isTabId(stored) ? stored : 'lessons';
}

function AppContent() {
  const { isAdmin } = useAuth();
  const [activeTab, setActiveTab] = useState<TabId>(initialTab);
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [showAdmin, setShowAdmin] = useState(false);
  const [darkMode, setDarkMode] = useState(getDarkModePref);
  const [storageBlocked, setStorageBlocked] = useState(false);
  const [storageNoticeClosed, setStorageNoticeClosed] = useState(false);

  useEffect(() => {
    document.documentElement.classList.toggle('dark', darkMode);
  }, [darkMode]);

  useEffect(() => {
    setStorageBlocked(!isStorageWorking());
  }, []);

  const selectTab = (tab: TabId) => {
    setActiveTab(tab);
    setLastTab(tab);
  };

  const toggleDarkMode = () => {
    setDarkMode((current) => {
      const next = !current;
      setDarkModePref(next);
      return next;
    });
  };

  if (showAdmin) {
    return isAdmin ? (
      <AdminDashboard onBack={() => setShowAdmin(false)} />
    ) : (
      <AdminLoginGate onBack={() => setShowAdmin(false)} />
    );
  }

  return (
    <div className="flex min-h-screen bg-slate-50 dark:bg-slate-950">
      <Sidebar
        activeTab={activeTab}
        onTabChange={selectTab}
        isOpen={sidebarOpen}
        onClose={() => setSidebarOpen(false)}
        onAdminClick={() => setShowAdmin(true)}
      />

      <div className="flex-1 flex flex-col min-w-0">
        <Header
          onMenuClick={() => setSidebarOpen(true)}
          searchQuery={searchQuery}
          onSearchChange={setSearchQuery}
          onAdminClick={() => setShowAdmin(true)}
          darkMode={darkMode}
          onToggleDarkMode={toggleDarkMode}
        />

        <main className="flex-1 p-4 lg:p-8 animate-fade-in">
          <div className="max-w-6xl mx-auto space-y-4">
            {storageBlocked && !storageNoticeClosed && (
              <div className="flex items-center justify-between gap-3 rounded-xl bg-rose-50 dark:bg-rose-500/15 border border-rose-100 dark:border-rose-500/30 p-4">
                <p className="text-sm text-rose-700 dark:text-rose-300 font-semibold">
                  هذا الجهاز لا يسمح بالحفظ المحلي (وضع تصفّح خاص أو مساحة ممتلئة)، فتقدّمك سيضيع عند
                  إغلاق الصفحة.
                </p>
                <button
                  onClick={() => setStorageNoticeClosed(true)}
                  className="flex-shrink-0 px-3 py-1.5 bg-rose-100 dark:bg-rose-500/25 text-rose-700 dark:text-rose-300 rounded-lg text-xs font-bold transition-all"
                >
                  حسناً
                </button>
              </div>
            )}

            <div className="space-y-6">
              {activeTab === 'lessons' && <LessonsSection searchQuery={searchQuery} />}
              {activeTab === 'summaries' && <SummariesSection />}
              {activeTab === 'laws' && <LawsSection searchQuery={searchQuery} />}
              {activeTab === 'videos' && <VideosSection searchQuery={searchQuery} />}
              {activeTab === 'questions' && <QuestionsSection searchQuery={searchQuery} />}
              {activeTab === 'quizzes' && <QuizzesSection />}
              {activeTab === 'flashcards' && <FlashcardsSection />}
              {activeTab === 'assistant' && <AssistantSection />}
              {activeTab === 'exams' && <ExamsSection />}
              {activeTab === 'saved-chats' && <SavedChatsSection />}
              {activeTab === 'weakness' && <WeaknessTrackerSection />}
              {activeTab === 'my-data' && <MyDataSection />}
            </div>
          </div>
        </main>

        <Footer />
      </div>
    </div>
  );
}

function App() {
  return <AppContent />;
}

export default App;
