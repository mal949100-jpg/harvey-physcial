import { useState, type FormEvent } from 'react';
import { Shield, Lock, LogIn, ArrowLeft, AlertCircle } from 'lucide-react';
import { useAuth } from '@/context/AuthContext';

export default function AdminLoginGate({ onBack }: { onBack: () => void }) {
  const { signIn, authReady } = useAuth();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    setBusy(true);
    const message = await signIn(email.trim(), password);
    setError(message);
    setBusy(false);
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-slate-50 dark:bg-slate-950 p-4">
      <div className="w-full max-w-md bg-white dark:bg-slate-900 rounded-2xl shadow-lg border border-slate-100 dark:border-slate-800 p-6 space-y-5">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 bg-amber-50 dark:bg-amber-500/15 rounded-xl flex items-center justify-center">
            <Shield className="w-6 h-6 text-amber-600 dark:text-amber-400" />
          </div>
          <div>
            <h1 className="text-lg font-bold text-slate-800 dark:text-slate-100">منطقة الإدارة</h1>
            <p className="text-xs text-slate-500 dark:text-slate-400">الدخول بالبريد وكلمة المرور المسجلين في Supabase</p>
          </div>
        </div>

        <div className="flex items-start gap-2 bg-slate-50 dark:bg-slate-800 border border-slate-100 dark:border-slate-700 rounded-xl p-3">
          <Lock className="w-4 h-4 text-slate-500 dark:text-slate-400 mt-0.5 shrink-0" />
          <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
           صلاحية الدخول تأتي من عمود <span className="font-bold">role</span> في جدول
            <span className="font-bold"> profiles</span> داخل قاعدة البيانات، ولا يتم منحها من
            مسار الصفحة أو من المتصفح. بدون جلسة صحيحة لا يمكن قراءة أي بيانات طلاب.
          </p>
        </div>

        <form onSubmit={submit} className="space-y-3">
          <label className="block">
            <span className="text-xs font-bold text-slate-600 dark:text-slate-300">البريد الإلكتروني</span>
            <input
              type="email"
              required
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="mt-1 w-full rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-800 dark:text-slate-100 px-3 py-2.5 text-sm focus:border-primary-500 focus:ring-2 focus:ring-primary-500/20 outline-none"
              placeholder="name@example.com"
            />
          </label>
          <label className="block">
            <span className="text-xs font-bold text-slate-600 dark:text-slate-300">كلمة المرور</span>
            <input
              type="password"
              required
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="mt-1 w-full rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-800 dark:text-slate-100 px-3 py-2.5 text-sm focus:border-primary-500 focus:ring-2 focus:ring-primary-500/20 outline-none"
              placeholder="••••••••"
            />
          </label>

          {error && (
            <div className="flex items-center gap-2 bg-error-500/10 border border-error-500/30 rounded-xl p-3">
              <AlertCircle className="w-4 h-4 text-error-600 shrink-0" />
              <p className="text-xs text-error-600 dark:text-error-500 font-semibold">{error}</p>
            </div>
          )}

          <button
            type="submit"
            disabled={busy || !authReady}
            className="w-full flex items-center justify-center gap-2 py-3 rounded-xl bg-primary-600 hover:bg-primary-700 disabled:opacity-60 text-white text-sm font-bold transition-all"
          >
            <LogIn className="w-4 h-4" />
            {busy ? 'جاري التحقق...' : 'دخول'}
          </button>
        </form>

        <button
          onClick={onBack}
          className="w-full flex items-center justify-center gap-2 py-2.5 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-600 dark:text-slate-300 text-sm font-semibold transition-all"
        >
          <ArrowLeft className="w-4 h-4" />
          العودة للمنصة
        </button>
      </div>
    </div>
  );
}
