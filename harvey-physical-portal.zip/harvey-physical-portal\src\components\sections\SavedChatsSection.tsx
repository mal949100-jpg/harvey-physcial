import { useState, useEffect } from 'react';
import { History, Trash2, MessageSquare, ChevronDown, Bot, User } from 'lucide-react';
import { getChats, deleteChatSession, type StoredChatSession } from '@/lib/guestStorage';

export default function SavedChatsSection() {
  const [sessions, setSessions] = useState<StoredChatSession[]>([]);
  const [expandedId, setExpandedId] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);

  const fetchSessions = () => {
    setSessions(getChats());
    setLoading(false);
  };

  useEffect(() => {
    fetchSessions();
  }, []);

  const toggleSession = (id: string) => {
    setExpandedId(expandedId === id ? null : id);
  };

  const handleDelete = (id: string) => {
    deleteChatSession(id);
    setSessions((prev) => prev.filter((s) => s.id !== id));
    if (expandedId === id) setExpandedId(null);
  };

  const formatDate = (d: string) => {
    return new Date(d).toLocaleDateString('ar-EG', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  };

  return (
    <div className="space-y-6">
      <div className="bg-white dark:bg-slate-900 rounded-2xl p-6 shadow-sm border border-slate-100 dark:border-slate-800">
        <div className="flex items-center gap-3 mb-4">
          <div className="w-12 h-12 bg-primary-50 dark:bg-primary-500/15 rounded-xl flex items-center justify-center">
            <History className="w-6 h-6 text-primary-600 dark:text-primary-300" />
          </div>
          <div>
            <h2 className="text-xl font-bold text-slate-800 dark:text-slate-100">سجل محادثاتي</h2>
            <p className="text-sm text-slate-500 dark:text-slate-300">مراجعة جميع أسئلتك السابقة والحلول</p>
          </div>
        </div>
      </div>

      {loading ? (
        <div className="text-center py-12 text-slate-400 dark:text-slate-500">
          <History className="w-12 h-12 mx-auto mb-3 opacity-40 animate-pulse" />
          <p>جاري التحميل...</p>
        </div>
      ) : sessions.length === 0 ? (
        <div className="text-center py-12 text-slate-400 dark:text-slate-500">
          <MessageSquare className="w-12 h-12 mx-auto mb-3 opacity-40" />
          <p>لا توجد محادثات محفوظة بعد</p>
          <p className="text-sm mt-2">استخدم المساعد الذكي وستُحفظ محادثاتك هنا تلقائياً</p>
        </div>
      ) : (
        <div className="space-y-3">
          {sessions.map((session) => {
            const isOpen = expandedId === session.id;
            return (
              <div
                key={session.id}
                className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-100 dark:border-slate-800 shadow-sm overflow-hidden transition-all hover:shadow-md"
              >
                <div className="flex items-center gap-3 p-4">
                  <button
                    onClick={() => toggleSession(session.id)}
                    className="flex-1 flex items-center gap-3 text-right"
                  >
                    <div className="w-10 h-10 bg-primary-50 dark:bg-primary-500/15 rounded-lg flex items-center justify-center flex-shrink-0">
                      <MessageSquare className="w-5 h-5 text-primary-600 dark:text-primary-300" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-bold text-slate-700 dark:text-slate-100 truncate">{session.title}</p>
                      <p className="text-xs text-slate-400 dark:text-slate-500">{formatDate(session.created_at)}</p>
                    </div>
                    <ChevronDown
                      className={`w-5 h-5 text-slate-400 dark:text-slate-500 transition-transform ${
                        isOpen ? 'rotate-180' : ''
                      }`}
                    />
                  </button>
                  <button
                    onClick={() => handleDelete(session.id)}
                    className="p-2 text-slate-400 dark:text-slate-500 hover:text-error-500 hover:bg-error-50 rounded-lg transition-all"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>

                {isOpen && (
                  <div className="px-4 pb-4 animate-slide-down">
                    <div className="border-t border-slate-100 dark:border-slate-800 pt-3 space-y-3">
                      {session.messages.length === 0 ? (
                        <p className="text-center text-sm text-slate-400 dark:text-slate-500 py-4">لا توجد رسائل</p>
                      ) : (
                        session.messages.map((msg, idx) => (
                          <div
                            key={idx}
                            className={`flex gap-3 ${msg.role === 'user' ? 'flex-row-reverse' : ''}`}
                          >
                            <div
                              className={`flex-shrink-0 w-8 h-8 rounded-full flex items-center justify-center ${
                                msg.role === 'user'
                                  ? 'bg-slate-200 dark:bg-slate-700'
                                  : 'bg-gradient-to-br from-primary-500 to-primary-700'
                              }`}
                            >
                              {msg.role === 'user' ? (
                                <User className="w-4 h-4 text-slate-600 dark:text-slate-300" />
                              ) : (
                                <Bot className="w-4 h-4 text-white" />
                              )}
                            </div>
                            <div
                              className={`max-w-[80%] rounded-xl p-3 ${
                                msg.role === 'user'
                                  ? 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-100'
                                  : 'bg-primary-50 dark:bg-primary-500/15 text-slate-700 dark:text-slate-100 border border-primary-100 dark:border-primary-500/30'
                              }`}
                            >
                              <p className="text-xs leading-relaxed">{msg.content}</p>
                              {msg.sections && msg.sections.length > 0 && (
                                <div className="mt-2 space-y-2">
                                  {msg.sections.map((section, sectionIdx) => (
                                    <section key={sectionIdx} className="bg-white dark:bg-slate-900 rounded-lg p-2 border border-primary-100 dark:border-primary-500/30">
                                      <p className="text-[11px] font-bold text-primary-700 dark:text-primary-300 mb-1">{section.title}</p>
                                      <p className="text-[11px] text-slate-700 dark:text-slate-100 leading-6 whitespace-pre-line" dir="auto">{section.body}</p>
                                    </section>
                                  ))}
                                </div>
                              )}
                              {msg.steps && msg.steps.length > 0 && (
                                <div className="mt-2 space-y-1.5">
                                  {msg.steps.map((step, sIdx) => <p key={sIdx} className="text-[11px] text-slate-700 dark:text-slate-100 leading-relaxed">{step}</p>)}
                                </div>
                              )}
                            </div>
                          </div>
                        ))
                      )}
                    </div>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
