import { part1 } from './part1';
import { part2 } from './part2';
import { part3 } from './part3';
import { part4 } from './part4';
import { part5 } from './part5';
import { part6 } from './part6';
import { part7 } from './part7';
import { part8 } from './part8';
import { part9 } from './part9';
import type { MinistryPart } from './types';

export type { MinistryLaw, MinistryLesson, MinistryPart } from './types';

/**
 * محتوى كتاب الوزارة الإضافي لكل درس، موزَّعاً على ملفات أجزاء حتى يبقى كل ملف قابلاً للمراجعة.
 * التوزيع: part1 (1-6)، part2 (7-9)، part3 (13-17)، part4 (18-23)، part5 (24-28)، part6 (29-34)،
 * part7 (35-40)، part8 (41-45)، part9 (10-12). لا يجوز تكرار رقم درس في ملفين.
 */
export const ministryLessons: MinistryPart = {
  ...part1,
  ...part2,
  ...part9,
  ...part3,
  ...part4,
  ...part5,
  ...part6,
  ...part7,
  ...part8,
};
