import { useCallback, useEffect, useMemo, useState } from 'react';
import {
  Layers,
  RotateCw,
  Check,
  Eye,
  Sparkles,
  Shuffle,
  ChevronRight,
  ChevronLeft,
  Keyboard,
} from 'lucide-react';
import { chapters, lessons, type ChapterId } from '@/data/lessons';
import { flashcards, type Flashcard } from '@/data/studyContent';
import {
  getFlashcardProgress,
  setFlashcardStatus,
  type CardStatus,
} from '@/lib/guestStorage';

const STATUS_LABEL: Record<CardStatus, string> = {
  mastered: 'محفوظة',
  learning: 'قيد التعلم',
  new: 'جديدة',
};

/**
 * Seeded so the same deck always shuffles into the same order: re-rendering after
 * a status change must not reshuffle the cards under the student's feet.
 */
function shuffleCards(cards: Flashcard[], seed: number): Flashcard[] {
  let a = seed >>> 0;
  const next = () => {
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
  const result = [...cards];
  for (let i = result.length - 1; i > 0; i--) {
    const j = Math.floor(next() * (i + 1));
    [result[i], result[j]] = [result[j], result[i]];
  }
  return result;
}

export default function FlashcardsSection() {
  const [chapter, setChapter] = useState<'all' | ChapterId>('all');
  const [lessonId, setLessonId] = useState<'all' | number>('all');
  const [statusFilter, setStatusFilter] = useState<'all' | CardStatus>('all');
  const [shuffleSeed, setShuffleSeed] = useState(0);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isFlipped, setIsFlipped] = useState(false);
  const [progress, setProgress] = useState<Record<string, CardStatus>>({});

  useEffect(() => {
    setProgress(getFlashcardProgress());
  }, []);

  const filtered = useMemo(() => {
    let cards = flashcards;
    if (chapter !== 'all') cards = cards.filter((c) => c.chapter === chapter);
    if (lessonId !== 'all') cards = cards.filter((c) => c.lessonId === lessonId);
    if (statusFilter !== 'all') {
      cards = cards.filter((c) => (progress[c.id] ?? 'new') === statusFilter);
    }
    return cards;
  }, [chapter, lessonId, statusFilter, progress]);

  const deck = useMemo(
    () => (shuffleSeed === 0 ? filtered : shuffleCards(filtered, shuffleSeed)),
    [filtered, shuffleSeed],
  );

  useEffect(() => {
    setCurrentIndex(0);
    setIsFlipped(false);
  }, [chapter, lessonId, statusFilter, shuffleSeed]);

  const currentCard: Flashcard | undefined = deck[currentIndex];

  const goNext = useCallback(() => {
    if (deck.length === 0) return;
    setIsFlipped(false);
    setTimeout(() => setCurrentIndex((prev) => (prev + 1) % deck.length), 150);
  }, [deck.length]);

  const goPrev = useCallback(() => {
    if (deck.length === 0) return;
    setIsFlipped(false);
    setTimeout(() => setCurrentIndex((prev) => (prev - 1 + deck.length) % deck.length), 150);
  }, [deck.length]);

  const mark = useCallback(
    (status: CardStatus) => {
      if (!currentCard) return;
      setProgress((prev) => ({ ...prev, [currentCard.id]: status }));
      setFlashcardStatus(currentCard.id, status);
      goNext();
    },
    [currentCard, goNext],
  );

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const tag = (e.target as HTMLElement | null)?.tagName;
      if (tag === 'INPUT' || tag === 'SELECT' || tag === 'TEXTAREA') return;
      if (e.key === 'ArrowRight') goPrev();
      else if (e.key === 'ArrowLeft') goNext();
      else if (e.key === ' ' || e.key === 'Enter') {
        e.preventDefault();
        setIsFlipped((f) => !f);
      } else if (e.key === '1') mark('learning');
      else if (e.key === '2') mark('mastered');
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [goNext, goPrev, mark]);

  const masteredCount = deck.filter((c) => progress[c.id] === 'mastered').length;
  const learningCount = deck.filter((c) => progress[c.id] === 'learning').length;
  const newCount = deck.length - masteredCount - learningCount;
  const currentStatus: CardStatus = currentCard ? progress[currentCard.id] ?? 'new' : 'new';
  const lessonOptions = lessons.filter((l) => chapter === 'all' || l.chapter === chapter);

  return (
    <div className="space-y-6">
      <div className="bg-white dark:bg-slate-900 rounded-2xl p-6 shadow-sm border border-slate-100 dark:border-slate-800">
        <div className="flex items-center gap-3 mb-4">
          <div className="w-12 h-12 bg-rose-50 dark:bg-rose-500/15 rounded-xl flex items-center justify-center">
            <Layers className="w-6 h-6 text-rose-600 dark:text-rose-400" />
          </div>
          <div className="flex-1">
            <h2 className="text-xl font-bold text-slate-800 dark:text-slate-100">فلاش كاردز</h2>
            <p className="text-sm text-slate-500 dark:text-slate-400">
              مراجعة سريعة للقوانين والتعريفات — {flashcards.length} بطاقة على كل الدروس
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 mb-4">
          <label className="block">
            <span className="text-xs font-bold text-slate-600 dark:text-slate-300">الفصل</span>
            <select
              value={String(chapter)}
              onChange={(e) => {
                const value = e.target.value === 'all' ? 'all' : Number(e.target.value);
                setChapter(value as 'all' | ChapterId);
                setLessonId('all');
              }}
              className="mt-1 w-full rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 px-3 py-2 text-sm text-slate-700 dark:text-slate-200 outline-none focus:border-primary-500"
            >
              <option value="all">كل الفصول</option>
              {chapters.map((ch) => (
                <option key={ch.id} value={ch.id}>
                  {ch.title}
                </option>
              ))}
            </select>
          </label>

          <label className="block">
            <span className="text-xs font-bold text-slate-600 dark:text-slate-300">الدرس</span>
            <select
              value={String(lessonId)}
              onChange={(e) => {
                const raw = e.target.value;
                setLessonId(raw === 'all' ? 'all' : Number(raw));
              }}
              className="mt-1 w-full rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 px-3 py-2 text-sm text-slate-700 dark:text-slate-200 outline-none focus:border-primary-500"
            >
              <option value="all">كل الدروس</option>
              <option value="0">أساسيات للحفظ المباشر</option>
              {lessonOptions.map((l) => (
                <option key={l.id} value={l.id}>
                  {l.title}
                </option>
              ))}
            </select>
          </label>

          <label className="block">
            <span className="text-xs font-bold text-slate-600 dark:text-slate-300">الحالة</span>
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value as 'all' | CardStatus)}
              className="mt-1 w-full rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 px-3 py-2 text-sm text-slate-700 dark:text-slate-200 outline-none focus:border-primary-500"
            >
              <option value="all">كل البطاقات</option>
              <option value="new">الجديدة فقط</option>
              <option value="learning">قيد التعلم فقط</option>
              <option value="mastered">المحفوظة فقط</option>
            </select>
          </label>
        </div>

        <div className="flex gap-3">
          <div className="flex-1 bg-emerald-50 dark:bg-emerald-500/15 rounded-xl p-3 text-center">
            <p className="text-2xl font-bold text-emerald-600 dark:text-emerald-400">{masteredCount}</p>
            <p className="text-xs text-emerald-700 dark:text-emerald-300">محفوظة</p>
          </div>
          <div className="flex-1 bg-amber-50 dark:bg-amber-500/15 rounded-xl p-3 text-center">
            <p className="text-2xl font-bold text-amber-600 dark:text-amber-400">{learningCount}</p>
            <p className="text-xs text-amber-700 dark:text-amber-300">قيد التعلم</p>
          </div>
          <div className="flex-1 bg-slate-50 dark:bg-slate-800 rounded-xl p-3 text-center">
            <p className="text-2xl font-bold text-slate-600 dark:text-slate-300">{newCount}</p>
            <p className="text-xs text-slate-500 dark:text-slate-400">جديدة</p>
          </div>
          <button
            onClick={() => setShuffleSeed((s) => (s === 0 ? Date.now() % 100000 : 0))}
            className={`px-4 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 ${
              shuffleSeed !== 0
                ? 'bg-primary-600 text-white'
                : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700'
            }`}
          >
            <Shuffle className="w-4 h-4" />
            {shuffleSeed !== 0 ? 'الترتيب الأصلي' : 'خلط'}
          </button>
        </div>

        {deck.length > 0 && (
          <div className="mt-4">
            <div className="h-2 rounded-full bg-slate-100 dark:bg-slate-800 overflow-hidden">
              <div
                className="h-full bg-gradient-to-l from-primary-500 to-primary-700 transition-all duration-300"
                style={{ width: `${((currentIndex + 1) / deck.length) * 100}%` }}
              />
            </div>
          </div>
        )}
      </div>

      {currentCard ? (
        <div className="space-y-4">
          <div className="flex items-center justify-between text-sm text-slate-500 dark:text-slate-400">
            <span>
              البطاقة {currentIndex + 1} من {deck.length}
            </span>
            <span
              className={`px-2.5 py-1 rounded-lg text-xs font-bold ${
                currentStatus === 'mastered'
                  ? 'bg-emerald-50 dark:bg-emerald-500/15 text-emerald-600 dark:text-emerald-400'
                  : currentStatus === 'learning'
                    ? 'bg-amber-50 dark:bg-amber-500/15 text-amber-600 dark:text-amber-400'
                    : 'bg-slate-100 dark:bg-slate-800 text-slate-500 dark:text-slate-400'
              }`}
            >
              {STATUS_LABEL[currentStatus]}
            </span>
          </div>

          <div
            role="button"
            tabIndex={0}
            aria-label="بطاقة مراجعة — اضغط للمس أو مفتاح المسافة للقلب"
            className="relative h-80 cursor-pointer"
            style={{ perspective: '1000px' }}
            onClick={() => setIsFlipped((f) => !f)}
            onKeyDown={(e) => {
              if (e.key === 'Enter') setIsFlipped((f) => !f);
            }}
          >
            <div
              className="relative w-full h-full transition-transform duration-500"
              style={{
                transformStyle: 'preserve-3d',
                transform: isFlipped ? 'rotateY(180deg)' : 'rotateY(0deg)',
              }}
            >
              <div
                className="absolute inset-0 bg-white dark:bg-slate-900 rounded-2xl shadow-lg border border-slate-100 dark:border-slate-800 flex flex-col items-center justify-center p-8"
                style={{ backfaceVisibility: 'hidden' }}
              >
                <div className="w-10 h-10 bg-rose-50 dark:bg-rose-500/15 rounded-lg flex items-center justify-center mb-3">
                  <Eye className="w-5 h-5 text-rose-500 dark:text-rose-400" />
                </div>
                <p className="text-xs text-slate-400 dark:text-slate-500 mb-2">
                  {currentCard.category}
                </p>
                <p className="text-2xl font-bold text-slate-800 dark:text-slate-100 text-center">
                  {currentCard.front}
                </p>
                <p className="text-xs text-slate-400 dark:text-slate-500 mt-4">اضغط للقلب</p>
              </div>

              <div
                className="absolute inset-0 bg-gradient-to-br from-primary-600 to-primary-800 rounded-2xl shadow-lg flex flex-col items-center justify-center p-8 text-white overflow-y-auto"
                style={{ backfaceVisibility: 'hidden', transform: 'rotateY(180deg)' }}
              >
                <div className="w-10 h-10 bg-white/20 rounded-lg flex items-center justify-center mb-3">
                  <Sparkles className="w-5 h-5 text-white" />
                </div>
                <p className="text-xs text-primary-200 mb-2">الإجابة</p>
                <p
                  className="text-lg font-bold text-center leading-relaxed whitespace-pre-line"
                  dir="auto"
                >
                  {currentCard.back}
                </p>
              </div>
            </div>
          </div>

          <div className="flex items-center justify-between gap-3">
            <button
              onClick={goPrev}
              className="px-4 py-2.5 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-600 dark:text-slate-300 rounded-xl text-sm font-semibold transition-all flex items-center gap-1.5"
            >
              <ChevronRight className="w-4 h-4" />
              السابق
            </button>

            <div className="flex gap-2">
              <button
                onClick={() => mark('learning')}
                className={`px-4 py-2.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 ${
                  currentStatus === 'learning'
                    ? 'bg-amber-500 text-white'
                    : 'bg-amber-50 dark:bg-amber-500/15 text-amber-600 dark:text-amber-400 hover:bg-amber-100 dark:hover:bg-amber-500/25'
                }`}
              >
                <RotateCw className="w-4 h-4" />
                قيد التعلم
              </button>
              <button
                onClick={() => mark('mastered')}
                className={`px-4 py-2.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 ${
                  currentStatus === 'mastered'
                    ? 'bg-emerald-500 text-white'
                    : 'bg-emerald-50 dark:bg-emerald-500/15 text-emerald-600 dark:text-emerald-400 hover:bg-emerald-100 dark:hover:bg-emerald-500/25'
                }`}
              >
                <Check className="w-4 h-4" />
                حفظت
              </button>
            </div>

            <button
              onClick={goNext}
              className="px-4 py-2.5 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-600 dark:text-slate-300 rounded-xl text-sm font-semibold transition-all flex items-center gap-1.5"
            >
              التالي
              <ChevronLeft className="w-4 h-4" />
            </button>
          </div>

          <div className="flex items-center justify-center gap-2 text-xs text-slate-400 dark:text-slate-500">
            <Keyboard className="w-4 h-4" />
            <span>المسافة للقلب · الأسهم للتنقل · 1 قيد التعلم · 2 حفظت</span>
          </div>
        </div>
      ) : (
        <div className="bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-2xl p-8 text-center text-slate-500 dark:text-slate-400 text-sm">
          لا توجد بطاقات مطابقة لهذا الفلتر — جرّب تغيير الفصل أو الحالة.
        </div>
      )}
    </div>
  );
}
