import {
  chapterLabel,
  chapters,
  getLessonById,
  lessonByTopic,
  lessons,
  lessonsOfChapter,
  lessonsOfTerm,
  termLabel,
  termOfChapter,
  type ChapterId,
  type TermId,
} from './lessons';
import { mulberry32 } from './questionFactory';
import { ministryQuizzes, type QuizDifficulty, type QuizQuestion } from './studyContent';

/**
 * The four paper types the platform has to offer:
 * partial = one lesson, cumulative = every three consecutive lessons of a chapter,
 * thematic = lessons that belong to one connected idea, final = whole chapter / whole term.
 */
export type ExamCategory = 'partial' | 'cumulative' | 'thematic' | 'final';

export interface ExamPlan {
  id: string;
  title: string;
  description: string;
  category: ExamCategory;
  term: TermId;
  chapterIds: ChapterId[];
  lessonIds: number[];
  questionCount: number;
  minutes: number;
}

export interface BuiltExam extends ExamPlan {
  questions: QuizQuestion[];
}

export interface ExamResult {
  score: number;
  total: number;
  percentage: number;
  unanswered: number;
  wrongTopics: string[];
  /** Where the mistakes came from, so the weakness list can name the lesson and the chapter. */
  wrongLessonIds: number[];
  wrongChapterIds: ChapterId[];
}

const SECONDS_PER_QUESTION = 90;
const DIFFICULTIES: QuizDifficulty[] = ['easy', 'medium', 'hard'];

function minutesFor(questionCount: number): number {
  return Math.max(5, Math.round((questionCount * SECONDS_PER_QUESTION) / 60));
}

/** Stable hash so an exam rebuilds the identical paper after a reload or a device return. */
function hashKey(key: string): number {
  let h = 2166136261;
  for (let i = 0; i < key.length; i++) {
    h ^= key.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return h >>> 0;
}

function shuffledWith<T>(items: T[], rand: () => number): T[] {
  const result = [...items];
  for (let i = result.length - 1; i > 0; i--) {
    const j = Math.floor(rand() * (i + 1));
    [result[i], result[j]] = [result[j], result[i]];
  }
  return result;
}

function modelsOf(lessonId: number): QuizQuestion[][] {
  return DIFFICULTIES.map(
    (difficulty) =>
      ministryQuizzes.find((quiz) => quiz.lessonId === lessonId && quiz.difficulty === difficulty)?.questions ?? [],
  );
}

/** Easy, medium and hard questions interleaved, so every paper spans all three levels. */
function candidatePool(lessonIds: number[]): QuizQuestion[] {
  const pool: QuizQuestion[] = [];
  for (const lessonId of lessonIds) {
    const models = modelsOf(lessonId);
    const longest = Math.max(0, ...models.map((model) => model.length));
    for (let index = 0; index < longest; index++) {
      for (const model of models) {
        const question = model[index];
        if (question) pool.push(question);
      }
    }
  }
  return pool;
}

function planOf(
  id: string,
  category: ExamCategory,
  title: string,
  description: string,
  lessonIds: number[],
  questionCount: number,
): ExamPlan {
  const present = lessonIds.filter((lessonId) => getLessonById(lessonId));
  const chapterIds = [...new Set(present.map((lessonId) => getLessonById(lessonId)!.chapter))] as ChapterId[];
  const term = chapterIds.length > 0 ? termOfChapter(chapterIds[0]) : 1;
  const available = candidatePool(present).length;
  const count = Math.max(1, Math.min(questionCount, available || questionCount));
  return {
    id,
    title,
    description,
    category,
    term,
    chapterIds,
    lessonIds: present,
    questionCount: count,
    minutes: minutesFor(count),
  };
}

/* ---------- 1) partial: one paper per lesson ---------- */

const partialPlans: ExamPlan[] = lessons.map((lesson) =>
  planOf(
    `ex-p-${lesson.id}`,
    'partial',
    `امتحان جزئي — ${lesson.title}`,
    `امتحان موقّت على درس «${lesson.title}» وحده: أسئلة مفاهيمية ومسائل رقمية بمستويات سهل ومتوسط وصعب.`,
    [lesson.id],
    15,
  ),
);

/* ---------- 2) cumulative: every three consecutive lessons of a chapter ---------- */

const cumulativePlans: ExamPlan[] = chapters.flatMap((chapter) => {
  const chapterLessons = lessonsOfChapter(chapter.id);
  const groups: number[][] = [];
  for (let i = 0; i < chapterLessons.length; i += 3) {
    groups.push(chapterLessons.slice(i, i + 3).map((lesson) => lesson.id));
  }
  return groups.map((group, index) => {
    const titles = group.map((lessonId) => getLessonById(lessonId)?.title).filter(Boolean).join(' + ');
    const first = group[0];
    const last = group[group.length - 1];
    return planOf(
      `ex-c-${chapter.id}-${index + 1}`,
      'cumulative',
      `امتحان تجميعي ${index + 1} — ${chapterLabel(chapter.id)} (دروس ${first} إلى ${last})`,
      `امتحان موقّت يجمع ثلاثة دروس متتالية: ${titles}.`,
      group,
      24,
    );
  });
});

/* ---------- 3) thematic: lessons that share one connected idea ---------- */

interface ThematicGroup {
  name: string;
  lessonIds: number[];
  idea: string;
}

const thematicGroups: ThematicGroup[] = [
  { name: 'المقادير المتجهة والحركة في مستوي', lessonIds: [1, 2, 3], idea: 'المتجهات ثم المقذوف الأفقي والمائل: نفس فكرة استقلال المركبتين.' },
  { name: 'العزوم والاتزان', lessonIds: [4, 5], idea: 'عزم القوة ثم شروط الاتزان الانتقالي والدوراني في مسألة واحدة.' },
  { name: 'الشغل والطاقة والقدرة', lessonIds: [6, 9], idea: 'القدرة والكفاءة مع الطاقة الميكانيكية وحفظها.' },
  { name: 'كمية الحركة والتصادمات', lessonIds: [7, 8, 9], idea: 'الدفع والزخم وحفظ كمية الحركة ومقارنة التصادمات المرن وغير المرن.' },
  { name: 'الحركة الدائرية والجاذبية', lessonIds: [10, 11, 12], idea: 'القوة المركزية في الوضعين الأفقي والرأسي ثم الجاذبية الكونية وكبلر.' },
  { name: 'الحركة الاهتزازية والبندولات', lessonIds: [13, 14, 15], idea: 'الاهتزاز التوافقي البسيط مع البندول الزنبركي والبسيط وقانون هوك.' },
  { name: 'الموجات والتداخل', lessonIds: [16, 17, 18], idea: 'الموجة الجيبية ثم التداخل والموجة الموقوفة ثم الانكسار.' },
  { name: 'الصوت وأثر الحركة النسبية', lessonIds: [19, 20], idea: 'تداخل موجات الصوت والنبضات مع تأثير دوبلر.' },
  { name: 'الضوء: انكسار وعدسات وتداخل', lessonIds: [18, 21, 22, 23], idea: 'الانكسار والانعكاس الكلي ثم العدسات ثم تجربة يونج.' },
  { name: 'الكهرباء الساكنة', lessonIds: [24, 25, 26], idea: 'الشحنة وقانون كولوم ثم المجال الكهربائي ثم الجهد وفرق الجهد.' },
  { name: 'المكثفات والتيار والمقاومة', lessonIds: [27, 28, 29], idea: 'السعة والتخزين الكهربي مع التيار وقانون أوم والمقاومة النوعية.' },
  { name: 'القدرة الكهربائية والدوائر', lessonIds: [30, 31], idea: 'الطاقة والقدرة وتأثير جول الحراري مع دوائر التوالي والتوازي.' },
  { name: 'المغناطيسية والحث الكهرومغناطيسي', lessonIds: [32, 33], idea: 'القوة على موصل في مجال ثم الحث وفاراديه ولنتز.' },
  { name: 'التيار المتردد والمحولات', lessonIds: [33, 34], idea: 'قواعد الحث مع قيم التيار المتردد والمحولات القدرة.' },
  { name: 'كمّ الطاقة وطبيعة الضوء', lessonIds: [35, 36, 37], idea: 'الإشعاع الحراري مع فرضية بلانك ثم التأثير الكهروضوئي.' },
  { name: 'الفوتون وازدواجية الموجة-جسم', lessonIds: [37, 38, 39], idea: 'تأثير كومبتون وطول دي برولي على نفس فكرة أن الجسيم يحمل طاقة وزخماً.' },
  { name: 'ذرة الهيدروجين والأطياف', lessonIds: [40, 41], idea: 'مستويات طاقة بور ثم السلاسل الطيفية وخطوط الامتصاص.' },
  { name: 'النشاط الإشعاعي والتحلل', lessonIds: [42, 43], idea: 'أنواع الإشعاع وقواعد التحول مع قانون التحلل وعمر النصف.' },
  { name: 'النواة والطاقة النووية', lessonIds: [44, 45], idea: 'الطاقة الربطية والنقصان الكتلي ثم الانشطار والاندماج.' },
];

const thematicPlans: ExamPlan[] = thematicGroups.map((group, index) =>
  planOf(
    `ex-t-${index + 1}`,
    'thematic',
    `امتحان موضوعي — ${group.name}`,
    `امتحان موقّت على مجموعة دروس مترابطة: ${group.idea}`,
    group.lessonIds,
    20,
  ),
);

/* ---------- 4) final: each chapter, then each term ---------- */

const chapterFinalPlans: ExamPlan[] = chapters.map((chapter) =>
  planOf(
    `ex-f-ch-${chapter.id}`,
    'final',
    `امتحان شامل نهاية ${chapterLabel(chapter.id)}`,
    `امتحان موقّت على كل دروس «${chapter.title}» بنسب متوازنة بين الدروس والمستويات.`,
    lessonsOfChapter(chapter.id).map((lesson) => lesson.id),
    30,
  ),
);

const termFinalPlans: ExamPlan[] = ([1, 2] as TermId[]).map((term) =>
  planOf(
    `ex-f-term-${term}`,
    'final',
    `امتحان شامل نهاية ${termLabel(term)}`,
    `امتحان موقّت على المنهج كاملًا لـ${termLabel(term)} (${lessonsOfTerm(term).length} درساً) — تدريب على الورقة الحقيقية.`,
    lessonsOfTerm(term).map((lesson) => lesson.id),
    45,
  ),
);

export const examPlans: ExamPlan[] = [...partialPlans, ...cumulativePlans, ...thematicPlans, ...chapterFinalPlans, ...termFinalPlans];

export const examCategories: { id: ExamCategory; label: string; hint: string }[] = [
  { id: 'partial', label: 'امتحانات جزئية', hint: 'امتحان لكل درس على حدة' },
  { id: 'cumulative', label: 'امتحانات تجميعية', hint: 'كل ثلاثة دروس متتالية' },
  { id: 'thematic', label: 'امتحانات موضوعية', hint: 'دروس ووحدات مترابطة' },
  { id: 'final', label: 'امتحانات شاملة', hint: 'نهاية كل فصل ونهاية كل ترم' },
];

export function examPlansByCategory(category: ExamCategory): ExamPlan[] {
  return examPlans.filter((plan) => plan.category === category);
}

export function getExamPlan(examId: string): ExamPlan | undefined {
  return examPlans.find((plan) => plan.id === examId);
}

const builtCache = new Map<string, BuiltExam>();

/** Questions are generated the first time a paper is opened, then cached for the session. */
export function buildExam(examId: string): BuiltExam | null {
  const plan = getExamPlan(examId);
  if (!plan || plan.lessonIds.length === 0) return null;
  const cached = builtCache.get(plan.id);
  if (cached) return cached;

  const rand = mulberry32(hashKey(plan.id));
  const questions = shuffledWith(candidatePool(plan.lessonIds), rand).slice(0, plan.questionCount);
  if (questions.length === 0) return null;

  const built: BuiltExam = { ...plan, questions, questionCount: questions.length };
  builtCache.set(built.id, built);
  return built;
}

export function scoreExam(exam: BuiltExam, answers: (number | null)[]): ExamResult {
  let score = 0;
  let unanswered = 0;
  const wrongTopics: string[] = [];
  const wrongLessonIds: number[] = [];
  const wrongChapterIds: ChapterId[] = [];

  exam.questions.forEach((question, index) => {
    const answer = answers[index];
    if (answer === null || answer === undefined) {
      unanswered++;
      return;
    }
    if (answer === question.correctIndex) {
      score++;
      return;
    }
    wrongTopics.push(question.topic);
    const lesson = lessonByTopic(question.topic);
    if (lesson) {
      wrongLessonIds.push(lesson.id);
      wrongChapterIds.push(lesson.chapter);
    }
  });

  const total = exam.questions.length;
  return {
    score,
    total,
    percentage: total === 0 ? 0 : Math.round((score / total) * 100),
    unanswered,
    wrongTopics: [...new Set(wrongTopics)],
    wrongLessonIds: [...new Set(wrongLessonIds)],
    wrongChapterIds: [...new Set(wrongChapterIds)].sort((a, b) => a - b),
  };
}

export function formatRemaining(seconds: number): string {
  const safe = Math.max(0, Math.floor(seconds));
  const minutes = Math.floor(safe / 60);
  const rest = safe % 60;
  return `${String(minutes).padStart(2, '0')}:${String(rest).padStart(2, '0')}`;
}

/**
 * A restored answer sheet is rebuilt against the live paper, so a stale record from an
 * older build can never point at a choice that does not exist.
 */
export function normalizeExamAnswers(exam: BuiltExam, saved: unknown[] | null): (number | null)[] {
  return exam.questions.map((question, index) => {
    const answer = saved?.[index];
    if (typeof answer !== 'number') return null;
    return Number.isInteger(answer) && answer >= 0 && answer < question.choices.length ? answer : null;
  });
}
