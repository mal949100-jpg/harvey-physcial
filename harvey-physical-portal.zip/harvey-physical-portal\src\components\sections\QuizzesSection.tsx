import { useState } from 'react';
import {
  ClipboardCheck,
  CheckCircle2,
  XCircle,
  ChevronLeft,
  ChevronDown,
  RotateCcw,
  Trophy,
  BookOpen,
  CircleAlert,
  Flame,
  Lightbulb,
  Save,
} from 'lucide-react';
import { ministryQuizzes as quizzes, type QuizQuestion, type QuizDifficulty } from '@/data/studyContent';
import { chapters } from '@/data/lessons';
import { chapterSoft } from '@/lib/chapterTheme';
import {
  addQuizResult,
  clearQuizDraft,
  getQuizDraft,
  saveQuizDraft,
} from '@/lib/guestStorage';

// A saved draft is clamped against the live quiz so a stale or hand-edited record
// can never point currentQ past the last question.
function readResumableDraft() {
  const draft = getQuizDraft();
  if (!draft) return null;
  const quiz = quizzes.find((q) => q.id === draft.quizId);
  if (!quiz) return null;
  const currentQ = Math.min(Math.max(draft.currentQ, 0), quiz.questions.length - 1);
  const answers = draft.answers.slice(0, currentQ);
  return { quizId: quiz.id, currentQ, answers };
}

const difficultyStyle: Record<QuizDifficulty, { badge: string; icon: typeof Flame; label: string }> = {
  easy: { badge: 'bg-emerald-100 dark:bg-emerald-500/25 text-emerald-700 dark:text-emerald-300', icon: Lightbulb, label: 'سهل' },
  medium: { badge: 'bg-amber-100 dark:bg-amber-500/25 text-amber-700 dark:text-amber-300', icon: CircleAlert, label: 'متوسط' },
  hard: { badge: 'bg-rose-100 dark:bg-rose-500/25 text-rose-700 dark:text-rose-300', icon: Flame, label: 'صعب' },
};

export default function QuizzesSection() {
  const [resumeDraft] = useState(readResumableDraft);
  const [showResumeNotice, setShowResumeNotice] = useState(resumeDraft !== null);
  const [activeQuizId, setActiveQuizId] = useState<string | null>(resumeDraft?.quizId ?? null);
  const [currentQ, setCurrentQ] = useState(resumeDraft?.currentQ ?? 0);
  const [answers, setAnswers] = useState<(number | null)[]>(resumeDraft?.answers ?? []);
  const [showResult, setShowResult] = useState(false);
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null);
  const [expandedLesson, setExpandedLesson] = useState<number | null>(null);
  const [expandedChapter, setExpandedChapter] = useState<number>(1);

  const activeQuiz = quizzes.find((q) => q.id === activeQuizId);

  const startQuiz = (quizId: string) => {
    clearQuizDraft();
    setShowResumeNotice(false);
    setActiveQuizId(quizId);
    setCurrentQ(0);
    setAnswers([]);
    setShowResult(false);
    setSelectedAnswer(null);
  };

  const selectAnswer = (idx: number) => {
    if (selectedAnswer !== null) return;
    setSelectedAnswer(idx);
  };

  const nextQuestion = () => {
    if (selectedAnswer === null) return;
    const newAnswers = [...answers, selectedAnswer];
    setAnswers(newAnswers);
    setSelectedAnswer(null);

    if (activeQuiz && currentQ + 1 < activeQuiz.questions.length) {
      const nextIndex = currentQ + 1;
      setCurrentQ(nextIndex);
      saveQuizDraft({ quizId: activeQuiz.id, currentQ: nextIndex, answers: newAnswers });
    } else {
      clearQuizDraft();
      finishQuiz(newAnswers);
    }
  };

  const prevQuestion = () => {
    if (currentQ > 0 && activeQuiz) {
      const prevAnswers = answers.slice(0, -1);
      const prevIndex = currentQ - 1;
      setAnswers(prevAnswers);
      setCurrentQ(prevIndex);
      setSelectedAnswer(null);
      saveQuizDraft({ quizId: activeQuiz.id, currentQ: prevIndex, answers: prevAnswers });
    }
  };

  const finishQuiz = (allAnswers: (number | null)[]) => {
    if (!activeQuiz) return;
    setShowResult(true);

    const score = allAnswers.filter(
      (a, i) => a === activeQuiz.questions[i].correctIndex
    ).length;

    const wrongTopics = activeQuiz.questions
      .filter((_q, i) => allAnswers[i] !== activeQuiz.questions[i].correctIndex)
      .map((q) => q.topic);

    addQuizResult({
      quiz_id: activeQuiz.id,
      score,
      total: activeQuiz.questions.length,
      wrong_topics: [...new Set(wrongTopics)],
    });
  };

  const resetQuiz = () => {
    setActiveQuizId(null);
    setShowResult(false);
    setCurrentQ(0);
    setAnswers([]);
    setSelectedAnswer(null);
  };

  // Group quizzes by lesson
  const quizzesByLesson = quizzes.reduce((acc, quiz) => {
    if (!acc[quiz.lessonId]) acc[quiz.lessonId] = [];
    acc[quiz.lessonId].push(quiz);
    return acc;
  }, {} as Record<number, typeof quizzes>);

  const lessonMeta = (lessonId: number) => {
    const lessonQuizzes = quizzesByLesson[lessonId] ?? [];
    const lesson = lessonQuizzes[0];
    return lesson ? { title: lesson.lessonTitle, chapter: lesson.chapter, quizzes: lessonQuizzes } : null;
  };

  if (!activeQuiz) {
    return (
      <div className="space-y-6">
        <div className="bg-white dark:bg-slate-900 rounded-2xl p-6 shadow-sm border border-slate-100 dark:border-slate-800">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-12 h-12 bg-violet-50 dark:bg-violet-500/15 rounded-xl flex items-center justify-center">
              <ClipboardCheck className="w-6 h-6 text-violet-600 dark:text-violet-300" />
            </div>
            <div>
              <h2 className="text-xl font-bold text-slate-800 dark:text-slate-100">الاختبارات التفاعلية</h2>
              <p className="text-sm text-slate-500 dark:text-slate-300">ثلاثة نماذج امتحانات لكل درس — سهل ومتوسط وصعب — مع تصحيح فوري وشرح خطوة بخطوة</p>
            </div>
          </div>
        </div>

        {chapters.map((chapter) => {
          const isChapterOpen = expandedChapter === chapter.id;
          const chapterLessons = Object.keys(quizzesByLesson)
            .map(Number)
            .filter((lid) => lessonMeta(lid)?.chapter === chapter.id)
            .sort((a, b) => a - b);

          return (
            <div key={chapter.id} className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-100 dark:border-slate-800 shadow-sm overflow-hidden">
              <button
                onClick={() => setExpandedChapter(isChapterOpen ? 0 : chapter.id)}
                className="w-full flex items-center gap-4 p-5 text-right hover:bg-slate-50/50 transition-colors"
              >
                <div className={`w-11 h-11 rounded-xl flex items-center justify-center ${chapterSoft[chapter.id]}`}>
                  <BookOpen className="w-6 h-6" />
                </div>
                <div className="flex-1">
                  <h3 className="font-bold text-slate-800 dark:text-slate-100 text-base">{chapter.title}</h3>
                  <p className="text-xs text-slate-500 dark:text-slate-300 mt-0.5">{chapter.subtitle} — 3 نماذج لكل درس</p>
                </div>
                <ChevronDown className={`w-5 h-5 text-slate-400 dark:text-slate-500 transition-transform ${isChapterOpen ? 'rotate-180' : ''}`} />
              </button>

              {isChapterOpen && (
                <div className="border-t border-slate-100 dark:border-slate-800 divide-y divide-slate-50 animate-slide-down">
                  {chapterLessons.map((lessonId) => {
                    const meta = lessonMeta(lessonId);
                    if (!meta) return null;
                    const isOpen = expandedLesson === lessonId;

                    return (
                      <div key={lessonId}>
                        <button
                          onClick={() => setExpandedLesson(isOpen ? null : lessonId)}
                          className="w-full flex items-center gap-3 p-4 text-right hover:bg-slate-50/50 transition-colors"
                        >
                          <span className="flex-shrink-0 w-8 h-8 bg-slate-100 dark:bg-slate-800 rounded-lg flex items-center justify-center text-xs font-bold text-slate-600 dark:text-slate-300">
                            {lessonId}
                          </span>
                          <span className="flex-1 text-sm font-bold text-slate-700 dark:text-slate-100">{meta.title}</span>
                          <span className="text-xs text-slate-400 dark:text-slate-500">3 نماذج</span>
                          <ChevronDown className={`w-4 h-4 text-slate-400 dark:text-slate-500 transition-transform ${isOpen ? 'rotate-180' : ''}`} />
                        </button>

                        {isOpen && (
                          <div className="px-4 pb-4 grid grid-cols-1 sm:grid-cols-3 gap-3 animate-fade-in">
                            {meta.quizzes.map((quiz) => {
                              const ds = difficultyStyle[quiz.difficulty];
                              const Icon = ds.icon;
                              return (
                                <button
                                  key={quiz.id}
                                  onClick={() => startQuiz(quiz.id)}
                                  className="bg-slate-50 dark:bg-slate-800 rounded-xl border border-slate-100 dark:border-slate-800 p-4 text-right hover:shadow-md hover:border-primary-200 transition-all group"
                                >
                                  <div className="flex items-center gap-2 mb-2">
                                    <div className={`w-9 h-9 rounded-lg flex items-center justify-center ${ds.badge}`}>
                                      <Icon className="w-5 h-5" />
                                    </div>
                                    <span className={`text-xs px-2 py-0.5 rounded-full font-bold ${ds.badge}`}>
                                      {ds.label}
                                    </span>
                                  </div>
                                  <p className="text-xs font-bold text-slate-700 dark:text-slate-100 mb-1">
                                    {quiz.difficulty === 'easy' ? 'نموذج 1 — سهل مباشر' : quiz.difficulty === 'medium' ? 'نموذج 2 — متوسط تطبيقي' : 'نموذج 3 — صعب متقدم'}
                                  </p>
                                  <p className="text-xs text-slate-500 dark:text-slate-300 mb-3 leading-relaxed">{quiz.description}</p>
                                  <div className="flex items-center justify-between">
                                    <span className="text-xs px-2.5 py-1 bg-primary-50 dark:bg-primary-500/15 text-primary-700 dark:text-primary-300 rounded-lg font-bold">
                                      {quiz.questions.length} سؤال
                                    </span>
                                    <span className="text-xs text-primary-600 dark:text-primary-300 font-bold group-hover:underline">
                                      ابدأ الآن →
                                    </span>
                                  </div>
                                </button>
                              );
                            })}
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          );
        })}
      </div>
    );
  }

  if (showResult) {
    const score = answers.filter(
      (a, i) => a === activeQuiz.questions[i].correctIndex
    ).length;
    const total = activeQuiz.questions.length;
    const percentage = Math.round((score / total) * 100);

    return (
      <div className="space-y-6">
        <div className="bg-white dark:bg-slate-900 rounded-2xl p-8 shadow-sm border border-slate-100 dark:border-slate-800 text-center">
          <div className="w-20 h-20 bg-gradient-to-br from-amber-400 to-amber-600 rounded-full flex items-center justify-center mx-auto mb-4 shadow-lg shadow-amber-500/30">
            <Trophy className="w-10 h-10 text-white" />
          </div>
          <h2 className="text-2xl font-bold text-slate-800 dark:text-slate-100 mb-2">نتيجة الكويز</h2>
          <p className="text-sm text-slate-500 dark:text-slate-300 mb-4">{activeQuiz.title}</p>
          <p className="text-4xl font-bold text-primary-600 dark:text-primary-300 mb-2">
            {score} / {total}
          </p>
          <p className="text-lg text-slate-500 dark:text-slate-300 mb-6">{percentage}%</p>

          <div className="space-y-2 text-right mb-6 max-h-96 overflow-y-auto">
            {activeQuiz.questions.map((q, i) => {
              const correct = answers[i] === q.correctIndex;
              return (
                <div
                  key={q.id}
                  className={`rounded-xl p-3 border ${
                    correct
                      ? 'bg-emerald-50 dark:bg-emerald-500/15 border-emerald-100 dark:border-emerald-500/30'
                      : 'bg-rose-50 dark:bg-rose-500/15 border-rose-100 dark:border-rose-500/30'
                  }`}
                >
                  <div className="flex items-start gap-2">
                    {correct ? (
                      <CheckCircle2 className="w-5 h-5 text-emerald-600 dark:text-emerald-300 flex-shrink-0 mt-0.5" />
                    ) : (
                      <XCircle className="w-5 h-5 text-rose-500 dark:text-rose-300 flex-shrink-0 mt-0.5" />
                    )}
                    <div className="flex-1">
                      <p className="text-xs font-bold text-slate-700 dark:text-slate-100 mb-1">{q.question}</p>
                      {!correct && (
                        <>
                          <p className="text-xs text-rose-600 dark:text-rose-300 font-semibold">
                            إجابتك: {q.choices[answers[i] ?? 0]}
                          </p>
                          <p className="text-xs text-emerald-700 dark:text-emerald-300 font-semibold">
                            الإجابة الصحيحة: {q.choices[q.correctIndex]}
                          </p>
                          <ol className="list-decimal list-inside space-y-1 mt-2 text-xs text-slate-600 dark:text-slate-300 leading-6">
                            {(q.steps).map((step, stepIdx) => <li key={stepIdx}>{step}</li>)}
                          </ol>
                        </>
                      )}
                      <p className="text-xs text-slate-400 dark:text-slate-500 mt-1">المفهوم: {q.explanation}</p>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>

          <button
            onClick={resetQuiz}
            className="px-6 py-2.5 bg-primary-600 hover:bg-primary-700 text-white rounded-xl text-sm font-bold transition-all inline-flex items-center gap-2"
          >
            <RotateCcw className="w-4 h-4" />
            العودة للكويزات
          </button>
        </div>
      </div>
    );
  }

  const question: QuizQuestion = activeQuiz.questions[currentQ];
  const answered = selectedAnswer !== null;
  const isLast = currentQ + 1 >= activeQuiz.questions.length;

  return (
    <div className="space-y-6">
      <div className="bg-white dark:bg-slate-900 rounded-2xl p-6 shadow-sm border border-slate-100 dark:border-slate-800">
        <div className="flex items-center justify-between mb-3">
          <div>
            <h2 className="text-lg font-bold text-slate-800 dark:text-slate-100">{activeQuiz.title}</h2>
            <p className="text-xs text-slate-500 dark:text-slate-300 mt-0.5">{activeQuiz.lessonTitle}</p>
          </div>
          <span className="text-sm text-slate-500 dark:text-slate-300 font-semibold">
            {currentQ + 1} / {activeQuiz.questions.length}
          </span>
        </div>

        <div className="w-full h-2 bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden mb-2">
          <div
            className="h-full bg-gradient-to-l from-primary-600 to-primary-400 rounded-full transition-all duration-300"
            style={{ width: `${((currentQ + 1) / activeQuiz.questions.length) * 100}%` }}
          />
        </div>
        <div className="flex items-center justify-between text-xs text-slate-400 dark:text-slate-500">
          <span>السؤال {currentQ + 1} من {activeQuiz.questions.length}</span>
          <span>{Math.round(((currentQ + 1) / activeQuiz.questions.length) * 100)}%</span>
        </div>

        {showResumeNotice && answers.length > 0 && (
          <div className="mt-3 flex items-center gap-2 rounded-xl bg-emerald-50 dark:bg-emerald-500/15 border border-emerald-100 dark:border-emerald-500/30 px-3 py-2">
            <Save className="w-4 h-4 text-emerald-600 dark:text-emerald-300 flex-shrink-0" />
            <p className="text-xs text-emerald-700 dark:text-emerald-300 font-semibold">
              استأنفنا محاولتك من آخر سؤال وصلته — إجاباتك محفوظة على هذا الجهاز وتُحفظ تلقائياً مع كل سؤال.
            </p>
          </div>
        )}
      </div>

      <div className="bg-white dark:bg-slate-900 rounded-2xl p-6 shadow-sm border border-slate-100 dark:border-slate-800">
        <p className="text-base font-bold text-slate-800 dark:text-slate-100 mb-4 leading-relaxed">
          {question.question}
        </p>

        <div className="space-y-2">
          {question.choices.map((choice, idx) => {
            const isCorrect = idx === question.correctIndex;
            const isSelected = idx === selectedAnswer;
            let style = 'border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 hover:border-primary-300 hover:bg-primary-50';

            if (answered && isCorrect) {
              style = 'border-emerald-400 bg-emerald-50 dark:bg-emerald-500/15';
            } else if (answered && isSelected && !isCorrect) {
              style = 'border-rose-400 bg-rose-50 dark:bg-rose-500/15';
            } else if (answered) {
              style = 'border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 opacity-60';
            }

            return (
              <button
                key={idx}
                onClick={() => selectAnswer(idx)}
                disabled={answered}
                className={`w-full flex items-center gap-3 p-3.5 rounded-xl border-2 text-right transition-all ${style}`}
              >
                <span
                  className={`flex-shrink-0 w-7 h-7 rounded-lg flex items-center justify-center text-xs font-bold ${
                    answered && isCorrect
                      ? 'bg-emerald-500 text-white'
                      : answered && isSelected && !isCorrect
                      ? 'bg-rose-500 text-white'
                      : 'bg-slate-200 dark:bg-slate-700 text-slate-600 dark:text-slate-300'
                  }`}
                >
                  {answered && isCorrect ? (
                    <CheckCircle2 className="w-4 h-4" />
                  ) : answered && isSelected && !isCorrect ? (
                    <XCircle className="w-4 h-4" />
                  ) : (
                    String.fromCharCode(0x0623 + idx)
                  )}
                </span>
                <span className="text-sm text-slate-700 dark:text-slate-100 font-semibold">{choice}</span>
              </button>
            );
          })}
        </div>

        {answered && (
          <div className={`mt-4 rounded-xl p-4 border animate-fade-in ${selectedAnswer === question.correctIndex ? 'bg-emerald-50 dark:bg-emerald-500/15 border-emerald-100 dark:border-emerald-500/30' : 'bg-rose-50 dark:bg-rose-500/15 border-rose-100 dark:border-rose-500/30'}`}>
            <p className="text-xs font-bold text-slate-700 dark:text-slate-100 mb-2">
              {selectedAnswer === question.correctIndex ? 'إجابة صحيحة — أحسنت، وهذا سبب صحتها:' : 'إجابة غير صحيحة — راجع الحل خطوة بخطوة:'}
            </p>
            <ol className="list-decimal list-inside space-y-1 text-xs text-slate-600 dark:text-slate-300 leading-7">
              {(question.steps).map((step, stepIdx) => <li key={stepIdx}>{step}</li>)}
            </ol>
            <p className="text-xs text-primary-700 dark:text-primary-300 font-semibold mt-2">{question.explanation}</p>
          </div>
        )}

        <div className="flex gap-2 mt-4">
          {currentQ > 0 && (
            <button
              onClick={prevQuestion}
              className="px-4 py-3 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-600 dark:text-slate-300 rounded-xl text-sm font-bold transition-all flex items-center gap-1"
            >
              <ChevronLeft className="w-4 h-4 rotate-180" />
              السابق
            </button>
          )}
          <button
            onClick={nextQuestion}
            disabled={!answered}
            className="flex-1 py-3 bg-primary-600 hover:bg-primary-700 disabled:bg-slate-200 disabled:text-slate-400 text-white rounded-xl text-sm font-bold transition-all flex items-center justify-center gap-2"
          >
            {isLast ? 'إنهاء الكويز' : 'السؤال التالي'}
            <ChevronLeft className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
}
