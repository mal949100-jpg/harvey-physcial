const GUEST_ID_KEY = 'guest_id';
const GUEST_NAME_KEY = 'guest_name';
const CHATS_KEY = 'guest_chats';
const FLASHCARD_KEY = 'guest_flashcards';
const QUIZ_KEY = 'guest_quiz_results';
const DRAFT_KEY = 'guest_quiz_draft';
const MOCK_DRAFT_KEY = 'guest_mock_exam_draft';
const TAB_KEY = 'guest_last_tab';
const ACTIVE_CHAT_KEY = 'guest_active_chat';

let cachedGuestId = '';
let writeFailed = false;

// localStorage can genuinely throw: Safari private mode rejects writes, and a full
// quota throws on any browser. One throw during render is a blank screen, so every
// write goes through here and only records the failure.
function safeSet(key: string, value: string): void {
  try {
    localStorage.setItem(key, value);
  } catch {
    writeFailed = true;
  }
}

function safeGet(key: string): string | null {
  try {
    return localStorage.getItem(key);
  } catch {
    return null;
  }
}

function safeRemove(key: string): void {
  try {
    localStorage.removeItem(key);
  } catch {
    writeFailed = true;
  }
}

function readJson<T>(key: string, fallback: T): T {
  const raw = safeGet(key);
  if (!raw) return fallback;
  try {
    return JSON.parse(raw) as T;
  } catch {
    return fallback;
  }
}

export function isStorageWorking(): boolean {
  if (writeFailed) return false;
  try {
    const probe = 'harvey_storage_probe';
    localStorage.setItem(probe, '1');
    localStorage.removeItem(probe);
    return true;
  } catch {
    return false;
  }
}

export function getGuestId(): string {
  if (cachedGuestId) return cachedGuestId;
  let id = safeGet(GUEST_ID_KEY) ?? '';
  if (!id) {
    id = `guest_${Date.now()}_${Math.random().toString(36).slice(2, 11)}`;
    safeSet(GUEST_ID_KEY, id);
  }
  cachedGuestId = id;
  return id;
}

export function getGuestName(): string {
  return safeGet(GUEST_NAME_KEY) ?? '';
}

export function setGuestName(name: string): void {
  safeSet(GUEST_NAME_KEY, name);
}

export interface StoredChatSection {
  title: string;
  body: string;
}

export interface StoredChatMessage {
  role: 'user' | 'bot';
  content: string;
  steps?: string[];
  sections?: StoredChatSection[];
}

export interface StoredChatSession {
  id: string;
  title: string;
  created_at: string;
  messages: StoredChatMessage[];
}

function isStoredChatSession(value: unknown): value is StoredChatSession {
  if (!value || typeof value !== 'object') return false;
  const chat = value as Partial<StoredChatSession>;
  return typeof chat.id === 'string' && typeof chat.title === 'string' && Array.isArray(chat.messages);
}

export function getChats(): StoredChatSession[] {
  const stored = readJson<unknown>(CHATS_KEY, []);
  return Array.isArray(stored) ? stored.filter(isStoredChatSession) : [];
}

export function saveChats(chats: StoredChatSession[]): void {
  safeSet(CHATS_KEY, JSON.stringify(chats));
}

export function addChatSession(title: string): StoredChatSession {
  const chats = getChats();
  const session: StoredChatSession = {
    id: `chat_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`,
    title: title.substring(0, 50),
    created_at: new Date().toISOString(),
    messages: [],
  };
  chats.unshift(session);
  saveChats(chats);
  setActiveChatId(session.id);
  return session;
}

export function appendChatMessage(
  sessionId: string,
  msg: StoredChatMessage,
): void {
  const chats = getChats();
  const session = chats.find((s) => s.id === sessionId);
  if (session) {
    session.messages.push(msg);
    saveChats(chats);
  }
}

export function deleteChatSession(sessionId: string): void {
  saveChats(getChats().filter((s) => s.id !== sessionId));
  if (getActiveChatId() === sessionId) setActiveChatId('');
}

export function getActiveChatId(): string {
  return safeGet(ACTIVE_CHAT_KEY) ?? '';
}

export function setActiveChatId(id: string): void {
  safeSet(ACTIVE_CHAT_KEY, id);
}

export function getChatById(sessionId: string): StoredChatSession | null {
  return getChats().find((s) => s.id === sessionId) ?? null;
}

export type CardStatus = 'new' | 'learning' | 'mastered';

const cardStatuses: CardStatus[] = ['new', 'learning', 'mastered'];

export function getFlashcardProgress(): Record<string, CardStatus> {
  const stored = readJson<unknown>(FLASHCARD_KEY, {});
  if (!stored || typeof stored !== 'object' || Array.isArray(stored)) return {};
  const source = stored as Record<string, unknown>;
  const progress: Record<string, CardStatus> = {};
  for (const [cardId, status] of Object.entries(source)) {
    if (cardStatuses.includes(status as CardStatus)) progress[cardId] = status as CardStatus;
  }
  return progress;
}

export function setFlashcardStatus(cardId: string, status: CardStatus): void {
  const progress = getFlashcardProgress();
  progress[cardId] = status;
  safeSet(FLASHCARD_KEY, JSON.stringify(progress));
}

export function setFlashcardProgressBulk(progress: Record<string, CardStatus>): void {
  safeSet(FLASHCARD_KEY, JSON.stringify(progress));
}

export interface StoredQuizResult {
  id: string;
  quiz_id: string;
  score: number;
  total: number;
  wrong_topics: string[];
  created_at: string;
}

function isStoredQuizResult(value: unknown): value is StoredQuizResult {
  if (!value || typeof value !== 'object') return false;
  const row = value as Partial<StoredQuizResult>;
  return (
    typeof row.id === 'string' &&
    typeof row.quiz_id === 'string' &&
    typeof row.score === 'number' &&
    typeof row.total === 'number' &&
    Array.isArray(row.wrong_topics) &&
    typeof row.created_at === 'string'
  );
}

export function getQuizResults(): StoredQuizResult[] {
  const stored = readJson<unknown>(QUIZ_KEY, []);
  return Array.isArray(stored) ? stored.filter(isStoredQuizResult) : [];
}

export function addQuizResult(result: Omit<StoredQuizResult, 'id' | 'created_at'>): void {
  const results = getQuizResults();
  results.push({
    ...result,
    id: `quiz_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`,
    created_at: new Date().toISOString(),
  });
  safeSet(QUIZ_KEY, JSON.stringify(results));
}

export function setQuizResultsBulk(results: StoredQuizResult[]): void {
  safeSet(QUIZ_KEY, JSON.stringify(results));
}

export interface QuizDraft {
  quizId: string;
  currentQ: number;
  answers: (number | null)[];
  savedAt: string;
}

export interface MockExamDraft {
  examId: string;
  answers: (number | null)[];
  // Absolute epoch ms, so a reload resumes the countdown instead of restarting it.
  endsAt: number;
}

export function getMockExamDraft(): MockExamDraft | null {
  const stored = readJson<unknown>(MOCK_DRAFT_KEY, null);
  return isMockExamDraft(stored) ? stored : null;
}

export function saveMockExamDraft(draft: MockExamDraft): void {
  safeSet(MOCK_DRAFT_KEY, JSON.stringify(draft));
}

export function clearMockExamDraft(): void {
  safeRemove(MOCK_DRAFT_KEY);
}

export function getQuizDraft(): QuizDraft | null {
  const stored = readJson<unknown>(DRAFT_KEY, null);
  if (!stored || typeof stored !== 'object') return null;
  const draft = stored as Partial<QuizDraft>;
  if (typeof draft.quizId !== 'string' || !Array.isArray(draft.answers)) return null;
  return {
    quizId: draft.quizId,
    currentQ: typeof draft.currentQ === 'number' ? draft.currentQ : 0,
    answers: draft.answers as (number | null)[],
    savedAt: typeof draft.savedAt === 'string' ? draft.savedAt : new Date().toISOString(),
  };
}

export function saveQuizDraft(draft: Omit<QuizDraft, 'savedAt'>): void {
  safeSet(DRAFT_KEY, JSON.stringify({ ...draft, savedAt: new Date().toISOString() }));
}

export function clearQuizDraft(): void {
  safeRemove(DRAFT_KEY);
}

export function getLastTab(): string {
  return safeGet(TAB_KEY) ?? '';
}

export function setLastTab(tab: string): void {
  safeSet(TAB_KEY, tab);
}

const DARK_MODE_KEY = 'harvey_dark_mode';

export function getDarkModePref(): boolean {
  return safeGet(DARK_MODE_KEY) === 'true';
}

export function setDarkModePref(on: boolean): void {
  safeSet(DARK_MODE_KEY, String(on));
}

export interface GuestSnapshot {
  version: 1;
  exportedAt: string;
  guestId: string;
  guestName: string;
  chats: StoredChatSession[];
  flashcardProgress: Record<string, CardStatus>;
  quizResults: StoredQuizResult[];
  quizDraft: QuizDraft | null;
  mockExamDraft: MockExamDraft | null;
}

export function exportSnapshot(): GuestSnapshot {
  return {
    version: 1,
    exportedAt: new Date().toISOString(),
    guestId: getGuestId(),
    guestName: getGuestName(),
    chats: getChats(),
    flashcardProgress: getFlashcardProgress(),
    quizResults: getQuizResults(),
    quizDraft: getQuizDraft(),
    mockExamDraft: getMockExamDraft(),
  };
}

export interface SnapshotCounts {
  chats: number;
  results: number;
  cards: number;
}

export function importSnapshot(raw: string): SnapshotCounts | null {
  let parsed: unknown;
  try {
    parsed = JSON.parse(raw);
  } catch {
    return null;
  }
  if (!parsed || typeof parsed !== 'object') return null;
  const snap = parsed as Partial<GuestSnapshot>;
  if (!Array.isArray(snap.chats) || !Array.isArray(snap.quizResults)) return null;

  const chats = snap.chats.filter(isStoredChatSession);
  const results = snap.quizResults.filter(isStoredQuizResult);
  const sourceCards =
    snap.flashcardProgress && typeof snap.flashcardProgress === 'object' ? snap.flashcardProgress : {};
  const cards: Record<string, CardStatus> = {};
  for (const [cardId, status] of Object.entries(sourceCards)) {
    if (cardStatuses.includes(status as CardStatus)) cards[cardId] = status as CardStatus;
  }

  saveChats(chats);
  setQuizResultsBulk(results);
  setFlashcardProgressBulk(cards);
  // An in-flight attempt must match the backup exactly, so clear first — a live draft
  // from this device would otherwise auto-resume on top of the restored state.
  clearQuizDraft();
  clearMockExamDraft();
  if (snap.quizDraft && typeof snap.quizDraft === 'object' && typeof snap.quizDraft.quizId === 'string') {
    saveQuizDraft({
      quizId: snap.quizDraft.quizId,
      currentQ: snap.quizDraft.currentQ ?? 0,
      answers: Array.isArray(snap.quizDraft.answers) ? snap.quizDraft.answers : [],
    });
  }
  if (snap.mockExamDraft && isMockExamDraft(snap.mockExamDraft)) {
    saveMockExamDraft(snap.mockExamDraft);
  }
  if (typeof snap.guestName === 'string' && snap.guestName) setGuestName(snap.guestName);
  return { chats: chats.length, results: results.length, cards: Object.keys(cards).length };
}

function isMockExamDraft(value: unknown): value is MockExamDraft {
  if (!value || typeof value !== 'object') return false;
  const draft = value as Partial<MockExamDraft>;
  return typeof draft.examId === 'string' && typeof draft.endsAt === 'number' && Array.isArray(draft.answers);
}

export function clearAllGuestData(): void {
  for (const key of [CHATS_KEY, FLASHCARD_KEY, QUIZ_KEY, DRAFT_KEY, MOCK_DRAFT_KEY, ACTIVE_CHAT_KEY, TAB_KEY]) {
    safeRemove(key);
  }
}

// Rough cost of the stored payload, in UTF-16 bytes, which is what browsers charge against quota.
export function storageUsageBytes(): number {
  let total = 0;
  for (const key of [
    CHATS_KEY,
    FLASHCARD_KEY,
    QUIZ_KEY,
    DRAFT_KEY,
    MOCK_DRAFT_KEY,
    GUEST_ID_KEY,
    GUEST_NAME_KEY,
  ]) {
    total += (safeGet(key)?.length ?? 0) * 2;
  }
  return total;
}
