import { useCallback, useEffect, useRef, useState } from 'react';
import {
  ArrowLeft,
  CheckCircle2,
  Clock,
  Flag,
  RotateCcw,
  Save,
  TimerReset,
  Trophy,
  XCircle,
} from 'lucide-react';
import {
  formatRemaining,
  normalizeExamAnswers,
  scoreExam,
  type BuiltExam,
  type ExamResult,
} from '@/data/examPlans';
import { chapterLabel, getLessonById } from '@/data/lessons';
import {
  addQuizResult,
  clearMockExamDraft,
  saveMockExamDraft,
  type MockExamDraft,
} from '@/lib/guestStorage';

interface MockExamRunnerProps {
  exam: BuiltExam;
  // A draft already validated by the caller: same exam id and still running.
  draft: MockExamDraft | null;
  onExit: () => void;
  // The caller remounts this component with a fresh key, which restarts the clock.
  onRetake: () => void;
}

export default function MockExamRunner({ exam, draft, onExit, onRetake }: MockExamRunnerProps) {
  const [endsAt] = useState(() => draft?.endsAt ?? Date.now() + exam.minutes * 60_000);
  const [answers, setAnswers] = useState<(number | null)[]>(() => normalizeExamAnswers(exam, draft?.answers ?? null));
  const [currentQ, setCurrentQ] = useState(() => {
    const firstBlank = normalizeExamAnswers(exam, draft?.answers ?? null).findIndex((a) => a === null);
    return firstBlank === -1 ? 0 : firstBlank;
  });
  const [remaining, setRemaining] = useState(() => Math.max(0, Math.ceil((endsAt - Date.now()) / 1000)));
  const [result, setResult] = useState<ExamResult | null>(null);
  const [confirmSubmit, setConfirmSubmit] = useState(false);
  const submittedRef = useRef(false);

  const answeredCount = answers.filter((a) => a !== null).length;
  const unansweredCount = exam.questions.length - answeredCount;

  const submit = useCallback(() => {
    if (submittedRef.current) return;
    submittedRef.current = true;
    const scored = scoreExam(exam, answers);
    addQuizResult({
      quiz_id: exam.id,
      score: scored.score,
      total: scored.total,
      wrong_topics: scored.wrongTopics,
    });
    clearMockExamDraft();
    setResult(scored);
  }, [answers, exam]);

  useEffect(() => {
    const id = setInterval(() => {
      const left = Math.max(0, Math.ceil((endsAt - Date.now()) / 1000));
      setRemaining(left);
      if (left === 0) clearInterval(id);
    }, 1000);
    return () => clearInterval(id);
  }, [endsAt]);

  // Time ran out — submit whatever is on the sheet, exactly like the invigilator collecting it.
  useEffect(() => {
    if (remaining === 0) submit();
  }, [remaining, submit]);

  const choose = (choiceIndex: number) => {
    const next = [...answers];
    next[currentQ] = choiceIndex;
    setAnswers(next);
    saveMockExamDraft({ examId: exam.id, answers: next, endsAt });
  };

  const goTo = (index: number) => {
    setCurrentQ(Math.min(Math.max(index, 0), exam.questions.length - 1));
    setConfirmSubmit(false);
  };

  const retake = () => {
    submittedRef.current = false;
    clearMockExamDraft();
    onRetake();
  };

  if (result) {
    const passed = result.percentage >= 50;
    return (
      <div className="space-y-6">
        <div className="bg-white dark:bg-slate-900 rounded-2xl p-8 shadow-sm border border-slate-100 dark:border-slate-800 text-center">
          <div
            className={`w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-4 shadow-lg ${
              passed
                ? 'bg-gradient-to-br from-amber-400 to-amber-600 shadow-amber-500/30'
                : 'bg-gradient-to-br from-slate-400 to-slate-600 shadow-slate-500/30'
            }`}
          >
            <Trophy className="w-10 h-10 text-white" />
          </div>
          <h2 className="text-2xl font-bold text-slate-800 dark:text-slate-100 mb-1">
            {passed ? 'نتيجة جيدة — كمّل' : 'النتيجة تحتاج مراجعة'}
          </h2>
          <p className="text-sm text-slate-500 dark:text-slate-300 mb-4">{exam.title}</p>
          <p className="text-4xl font-bold text-primary-600 dark:text-primary-300 mb-1">
            {result.score} / {result.total}
          </p>
          <p className="text-lg text-slate-500 dark:text-slate-300 mb-4">{result.percentage}%</p>

          <div className="flex flex-wrap items-center justify-center gap-2 mb-6">
            <span className="text-xs px-3 py-1 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 font-bold">
              صحيح: {result.score}
            </span>
            <span className="text-xs px-3 py-1 rounded-full bg-rose-50 dark:bg-rose-500/15 text-rose-700 dark:text-rose-300 font-bold">
              خطأ: {result.total - result.score - result.unanswered}
            </span>
            <span className="text-xs px-3 py-1 rounded-full bg-amber-50 dark:bg-amber-500/15 text-amber-700 dark:text-amber-300 font-bold">
              بدون إجابة: {result.unanswered}
            </span>
          </div>

          {result.wrongTopics.length > 0 && (
            <div className="mb-6 rounded-xl bg-slate-50 dark:bg-slate-800 p-4 text-right">
              <p className="text-xs font-bold text-slate-700 dark:text-slate-100 mb-2">
                نقاط ضعفك في هذا الامتحان — راجع هذه المفاهيم:
              </p>
              <div className="flex flex-wrap gap-1.5">
                {result.wrongTopics.map((topic) => (
                  <span
                    key={topic}
                    className="text-xs px-2 py-1 rounded-lg bg-rose-50 dark:bg-rose-500/15 text-rose-700 dark:text-rose-300 font-semibold"
                  >
                    {topic}
                  </span>
                ))}
              </div>
              {result.wrongChapterIds.length > 0 && (
                <div className="flex flex-wrap gap-1.5 mt-2">
                  <span className="text-xs text-slate-500 dark:text-slate-300 font-bold">العودة إلى:</span>
                  {result.wrongChapterIds.map((chapter) => (
                    <span
                      key={chapter}
                      className="text-xs px-2 py-1 rounded-lg bg-amber-50 dark:bg-amber-500/15 text-amber-700 dark:text-amber-300 font-bold"
                    >
                      {chapterLabel(chapter)}
                    </span>
                  ))}
                  {result.wrongLessonIds.slice(0, 4).map((lessonId) => (
                    <span
                      key={lessonId}
                      className="text-xs px-2 py-1 rounded-lg bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 font-semibold"
                    >
                      درس {lessonId}: {getLessonById(lessonId)?.title ?? 'غير معروف'}
                    </span>
                  ))}
                </div>
              )}
              <p className="text-xs text-slate-500 dark:text-slate-300 mt-3">
                النتيجة محفوظة في سجل نتائجك على هذا الجهاز تلقائياً، ونقاط الضعف ظهرت في صفحة تتبع نقاط الضعف.
              </p>
            </div>
          )}

          <div className="max-h-[32rem] overflow-y-auto space-y-2 text-right mb-6">
            {exam.questions.map((question, index) => {
              const answer = answers[index];
              const correct = answer === question.correctIndex;
              return (
                <div
                  key={question.id}
                  className={`rounded-xl p-3 border ${
                    correct
                      ? 'bg-emerald-50 dark:bg-emerald-500/15 border-emerald-100 dark:border-emerald-500/30'
                      : 'bg-rose-50 dark:bg-rose-500/15 border-rose-100 dark:border-rose-500/30'
                  }`}
                >
                  <div className="flex items-start gap-2">
                    {correct ? (
                      <CheckCircle2 className="w-5 h-5 text-emerald-600 dark:text-emerald-300 flex-shrink-0 mt-0.5" />
                    ) : (
                      <XCircle className="w-5 h-5 text-rose-500 dark:text-rose-300 flex-shrink-0 mt-0.5" />
                    )}
                    <div className="flex-1 min-w-0">
                      <p className="text-xs font-bold text-slate-700 dark:text-slate-100 mb-1">
                        {index + 1}. {question.question}
                      </p>
                      {!correct && (
                        <>
                          <p className="text-xs text-rose-600 dark:text-rose-300 font-semibold">
                            {answer === null ? 'لم تُجب' : `إجابتك: ${question.choices[answer]}`}
                          </p>
                          <p className="text-xs text-emerald-700 dark:text-emerald-300 font-semibold">
                            الإجابة الصحيحة: {question.choices[question.correctIndex]}
                          </p>
                        </>
                      )}
                      <p className="text-xs font-bold text-slate-600 dark:text-slate-300 mt-2">خطة الحل والإجابة النموذجية</p>
                      <ol className="list-decimal list-inside space-y-1 mt-1 text-xs text-slate-600 dark:text-slate-300 leading-6">
                        {question.steps.map((step, stepIdx) => (
                          <li key={stepIdx}>{step}</li>
                        ))}
                      </ol>
                      <p className="text-xs text-slate-400 dark:text-slate-500 mt-1">
                        المفهوم: {question.explanation}
                      </p>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>

          <div className="flex flex-wrap items-center justify-center gap-2">
            <button
              onClick={onExit}
              className="px-6 py-2.5 bg-primary-600 hover:bg-primary-700 text-white rounded-xl text-sm font-bold transition-all inline-flex items-center gap-2"
            >
              <ArrowLeft className="w-4 h-4 rotate-180" />
              العودة لقائمة الامتحانات
            </button>
            <button
              onClick={retake}
              className="px-6 py-2.5 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-600 dark:text-slate-300 rounded-xl text-sm font-bold transition-all inline-flex items-center gap-2"
            >
              <RotateCcw className="w-4 h-4" />
              إعادة الامتحان من جديد
            </button>
          </div>
        </div>
      </div>
    );
  }

  const question = exam.questions[currentQ];
  const lowTime = remaining <= 60;
  const warnTime = remaining <= 300;

  return (
    <div className="space-y-6">
      <div className="bg-white dark:bg-slate-900 rounded-2xl p-6 shadow-sm border border-slate-100 dark:border-slate-800">
        <div className="flex items-center justify-between gap-3 mb-4">
          <div className="min-w-0">
            <h2 className="text-lg font-bold text-slate-800 dark:text-slate-100 truncate">{exam.title}</h2>
            <p className="text-xs text-slate-500 dark:text-slate-300 mt-0.5">
              {answeredCount} مجاب من {exam.questions.length} — لا يظهر التصحيح إلا بعد التسليم
            </p>
          </div>
          <div
            className={`flex items-center gap-2 px-3 py-2 rounded-xl font-bold text-lg shrink-0 tabular-nums ${
              lowTime
                ? 'bg-rose-50 dark:bg-rose-500/15 text-rose-600 dark:text-rose-300 animate-pulse'
                : warnTime
                ? 'bg-amber-50 dark:bg-amber-500/15 text-amber-700 dark:text-amber-300'
                : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-100'
            }`}
            dir="ltr"
          >
            <Clock className="w-5 h-5" />
            {formatRemaining(remaining)}
          </div>
        </div>

        <div className="w-full h-2 bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden mb-3">
          <div
            className="h-full bg-gradient-to-l from-primary-600 to-primary-400 rounded-full transition-all duration-300"
            style={{ width: `${(answeredCount / exam.questions.length) * 100}%` }}
          />
        </div>

        {draft === null && (
          <div className="flex items-center gap-2 rounded-xl bg-slate-50 dark:bg-slate-800 px-3 py-2 mb-2">
            <TimerReset className="w-4 h-4 text-slate-500 dark:text-slate-300 shrink-0" />
            <p className="text-xs text-slate-600 dark:text-slate-300">
              المؤقّت يبدأ الآن ({exam.minutes} دقيقة). اخرجت من الصفحة؟ الوقت يستمر والجهاز يحفظ إجاباتك.
            </p>
          </div>
        )}
        {draft !== null && (
          <div className="flex items-center gap-2 rounded-xl bg-emerald-50 dark:bg-emerald-500/15 border border-emerald-100 dark:border-emerald-500/30 px-3 py-2 mb-2">
            <Save className="w-4 h-4 text-emerald-600 dark:text-emerald-300 shrink-0" />
            <p className="text-xs text-emerald-700 dark:text-emerald-300 font-semibold">
              استئناف المحاولة الجارية — المؤقّت يعد من وقت البداية الأصلي، وإجاباتك محفوظة على الجهاز.
            </p>
          </div>
        )}

        <div className="flex flex-wrap gap-1.5">
          {exam.questions.map((_, index) => {
            const isAnswered = answers[index] !== null;
            const isCurrent = index === currentQ;
            return (
              <button
                key={index}
                onClick={() => goTo(index)}
                className={`w-8 h-8 rounded-lg text-xs font-bold transition-all ${
                  isCurrent
                    ? 'bg-primary-600 text-white ring-2 ring-primary-300 ring-offset-1'
                    : isAnswered
                    ? 'bg-primary-50 dark:bg-primary-500/15 text-primary-700 dark:text-primary-300'
                    : 'bg-slate-100 dark:bg-slate-800 text-slate-500 dark:text-slate-300'
                }`}
              >
                {index + 1}
              </button>
            );
          })}
        </div>
      </div>

      <div className="bg-white dark:bg-slate-900 rounded-2xl p-6 shadow-sm border border-slate-100 dark:border-slate-800">
        <div className="flex items-center gap-2 mb-3">
          <span className="w-7 h-7 bg-slate-100 dark:bg-slate-800 rounded-lg flex items-center justify-center text-xs font-bold text-slate-600 dark:text-slate-300">
            {currentQ + 1}
          </span>
          <span className="text-xs px-2 py-0.5 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-500 dark:text-slate-300 font-semibold">
            {question.topic}
          </span>
        </div>

        <p className="text-base font-bold text-slate-800 dark:text-slate-100 mb-4 leading-relaxed">
          {question.question}
        </p>

        <div className="space-y-2">
          {question.choices.map((choice, idx) => {
            const isSelected = answers[currentQ] === idx;
            return (
              <button
                key={idx}
                onClick={() => choose(idx)}
                className={`w-full flex items-center gap-3 p-3.5 rounded-xl border-2 text-right transition-all ${
                  isSelected
                    ? 'border-primary-500 bg-primary-50 dark:bg-primary-500/15'
                    : 'border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 hover:border-primary-300'
                }`}
              >
                <span
                  className={`flex-shrink-0 w-7 h-7 rounded-lg flex items-center justify-center text-xs font-bold ${
                    isSelected
                      ? 'bg-primary-600 text-white'
                      : 'bg-slate-200 dark:bg-slate-700 text-slate-600 dark:text-slate-300'
                  }`}
                >
                  {String.fromCharCode(0x0623 + idx)}
                </span>
                <span className="text-sm text-slate-700 dark:text-slate-100 font-semibold">{choice}</span>
              </button>
            );
          })}
        </div>

        {confirmSubmit && (
          <div className="mt-4 rounded-xl p-4 border bg-amber-50 dark:bg-amber-500/15 border-amber-100 dark:border-amber-500/30 animate-fade-in">
            <p className="text-xs font-bold text-amber-800 dark:text-amber-300 mb-3">
              {unansweredCount > 0
                ? `لديك ${unansweredCount} سؤال بدون إجابة. هل تسلّم الآن؟`
                : 'سيُسلَّم الامتحان الآن وتظهر النتيجة.'}
            </p>
            <div className="flex gap-2">
              <button
                onClick={submit}
                className="px-4 py-2.5 bg-primary-600 hover:bg-primary-700 text-white rounded-xl text-xs font-bold transition-all"
              >
                تسليم نهائي
              </button>
              <button
                onClick={() => setConfirmSubmit(false)}
                className="px-4 py-2.5 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 rounded-xl text-xs font-bold transition-all"
              >
                رجوع
              </button>
            </div>
          </div>
        )}

        <div className="flex gap-2 mt-4">
          <button
            onClick={() => goTo(currentQ - 1)}
            disabled={currentQ === 0}
            className="px-4 py-3 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 disabled:opacity-50 text-slate-600 dark:text-slate-300 rounded-xl text-sm font-bold transition-all flex items-center gap-1"
          >
            <ArrowLeft className="w-4 h-4 rotate-180" />
            السابق
          </button>
          <button
            onClick={() => goTo(currentQ + 1)}
            disabled={currentQ + 1 >= exam.questions.length}
            className="flex-1 py-3 bg-primary-600 hover:bg-primary-700 disabled:bg-slate-200 disabled:text-slate-400 text-white rounded-xl text-sm font-bold transition-all flex items-center justify-center gap-2"
          >
            السؤال التالي
            <ArrowLeft className="w-4 h-4" />
          </button>
          <button
            onClick={() => setConfirmSubmit(true)}
            className="px-5 py-3 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-sm font-bold transition-all flex items-center gap-2"
          >
            <Flag className="w-4 h-4" />
            تسليم
          </button>
        </div>
      </div>
    </div>
  );
}
