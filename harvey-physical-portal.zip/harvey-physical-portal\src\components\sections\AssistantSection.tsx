import { useState, useRef, useEffect } from 'react';
import { Send, Sparkles, User, Bot, Plus } from 'lucide-react';
import { findRelevantLesson, stem } from '@/data/lessonMatch';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/context/AuthContext';
import {
  addChatSession,
  appendChatMessage,
  getActiveChatId,
  getChatById,
  setActiveChatId,
  type StoredChatSession,
  type StoredChatSection,
} from '@/lib/guestStorage';

interface Message {
  role: 'user' | 'bot';
  content: string;
  steps?: string[];
  sections?: StoredChatSection[];
}

function greeting(): Message {
  return {
    role: 'bot',
    content:
      'مرحباً بك في المساعد الذكي لمنصة هارفي فيزيكال! يمكنني مساعدتك في حل مسائل الفيزياء. اختر سؤالاً من الأزرار السريعة أو اكتب سؤالك. ستُحفظ محادثاتك في سجل محادثاتي.',
  };
}

function restoreActiveChat(): StoredChatSession | null {
  const activeId = getActiveChatId();
  return activeId ? getChatById(activeId) : null;
}

const quickQuestions = [
  "احسب السرعة النسبية لسيارتين",
  "أوجد مدى المقذوف بزاوية 45°",
  "شرح قانون الجاذبية الكونية",
  "احسب زمن دوري البندول البسيط",
  "كيف أطبق قانون سنيل في الانكسار؟",
  "احسب التردد في تأثير دوبلر",
  "ما هو شرط التداخل الهدام؟",
  "احسب بعد الصورة باستخدام معادلة العدسة",
  "كيف أحسب أقصى ارتفاع للمقذوف؟",
  "شرح معادلة يونج للشق المزدوج",
  "احسب قوة التنافر بين شحنتين بقانون كولوم",
  "أوجد السعة المكافئة لمكثفات على التوازي",
  "احسب شدة التيار في دائرة على التوالي",
  "ما هي القيمة الفعالة للتيار المتردد؟",
  "احسب عدد لفات الملف الثانوي في المحول",
  "كيف أجد طاقة الفوتون في التأثير الكهروضوئي؟",
  "احسب طول موجة دي برولي لإلكترون",
  "ما الفرق بين سلاسل ليمان وبالمر؟",
  "احسب العمر النصفي لعينة مشعة",
  "أوجد الطاقة الربطية لنواة",
];

function generateResponse(query: string): { content: string; sections: StoredChatSection[] } {
  const lesson = findRelevantLesson(query);
  const normalizedQuery = query.toLowerCase();

  if (!lesson) {
    return {
      content:
        'لم أتعرف على درس محدّد في سؤالك، فاذكر اسم القانون أو الكمية المطلوبة ووحّتها وسأرتّب لك الحل. المنهج أربعة فصول: الميكانيكا، والحركة الاهتزازية والموجات، والكهرباء والمغناطيسية، والفيزياء الحديثة.',
      sections: [
        {
          title: "كيف تصيغ سؤالك ليصلك الحل كاملًا؟",
          body:
            'اكتب الكمية المطلوبة ووحبتها (مثلاً: احسب شدة المجال الكهربائي بـ N/C)، أو اذكر اسم القانون (قانون كولوم، فاراديه، دي برولي)، أو انسخ نص المسألة كما هي.\n\n' +
            'إذا كنت تبحث عن درس بعينه، فتّش في قسم الشرح ثم اسألني عنه هنا مباشرة.',
        },
      ],
    };
  }

  const question = lesson.questions.find((candidate) => {
    const words = candidate.q.split(/\s+/).map(stem).filter((word) => word.length > 3);
    return words.filter((word) => normalizedQuery.includes(word)).length >= 2;
  }) ?? lesson.questions[0];
  const law = lesson.laws.find((candidate) =>
    normalizedQuery.includes(candidate.name.toLowerCase()) || normalizedQuery.includes(candidate.formula.toLowerCase())
  ) ?? lesson.laws[0];

  return {
    content: `حللت سؤالك ضمن درس «${lesson.title}». لن أعرض رقماً منفرداً؛ اتبع المراحل الآتية لفهم الحل والتحقق منه.`,
    sections: [
      {
        title: "أ) المعطيات والمطلوب وتحويل الوحدات",
        body: question
          ? `المسألة الأقرب لسؤالك: ${question.q}\n\nالمطلوب والمعطيات مستخرجان من نص المسألة. اكتب كل كمية برمزها، وحوّل km/h إلى m/s، وcm وmm إلى m، وmA إلى A، وkΩ إلى Ω، وμF إلى F، وnm إلى m، وeV إلى J قبل التعويض. إذا كان السؤال مفاهيمياً، فالمطلوب هو تفسير الظاهرة لا استخراج رقم.`
          : `الموضوع المطلوب هو ${lesson.title}. حدّد الجسم المدروس، الكميات المعطاة، الكمية المطلوبة، واتجاه كل كمية، ثم وحّد الوحدات قبل استخدام القانون.`,
      },
      {
        title: "ب) اختيار القانون وسبب اختياره",
        body: law
          ? `القانون المناسب هو ${law.name}: ${law.formula}. نختاره لأن ${law.explanation}؛ فهو يربط مباشرة بين الكميات المذكورة في السؤال، مع الالتزام بظروف تطبيقه.`
          : `نختار مبدأ ${lesson.title} بعد مطابقة المعطيات مع تعريف الظاهرة، ولا نختار القانون من شكل الأرقام فقط.`,
      },
      {
        title: "ج) التعويض والخطوات الحسابية بالتفصيل",
        body: question
          ? question.steps.join("\n")
          : "اكتب العلاقة أولاً بالرموز، اعزل المجهول، عوّض بالقيم بعد توحيد الوحدات، ثم راجع الإشارة والأبعاد في كل خطوة.",
      },
      {
        title: "د) الناتج النهائي مع وحدة القياس",
        body: question
          ? `${question.answer}. لا تُقبل الإجابة العددية وحدها؛ اذكر الاتجاه أو طبيعة الصورة أو حالة الحركة متى كان ذلك مطلوباً.`
          : "اكتب الناتج بعد التقريب المناسب ومع الوحدة الصحيحة، ولا تحذف الوحدة من السطر الأخير.",
      },
      {
        title: "هـ) التفسير الفيزيائي والمعنى العملي",
        body: `${lesson.summary} افحص هل يتفق الناتج مع الواقع: زيادة المؤثر يجب أن تغير النتيجة بالطريقة التي يحددها القانون، والوحدة والاتجاه يشرحان ما يعنيه الرقم عملياً.`,
      },
    ],
  };
}

export default function AssistantSection() {
  const { session: authSession } = useAuth();
  const [restoredChat] = useState(restoreActiveChat);
  const [messages, setMessages] = useState<Message[]>(() =>
    restoredChat && restoredChat.messages.length > 0 ? restoredChat.messages : [greeting()],
  );
  const [input, setInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const [currentSession, setCurrentSession] = useState<StoredChatSession | null>(restoredChat);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isTyping]);

  const buildBotMessage = (text: string): Message => {
    const response = generateResponse(text);
    return { role: 'bot', content: response.content, sections: response.sections };
  };

  // A question saved just before the tab closed never got its answer; complete it on return.
  useEffect(() => {
    if (!restoredChat) return;
    const last = restoredChat.messages[restoredChat.messages.length - 1];
    if (!last || last.role !== 'user') return;
    const botMsg = buildBotMessage(last.content);
    appendChatMessage(restoredChat.id, botMsg);
    setMessages((prev) => [...prev, botMsg]);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [restoredChat]);

  const ensureSession = (firstQuestion: string): StoredChatSession => {
    if (currentSession) return currentSession;
    const session = addChatSession(firstQuestion);
    setCurrentSession(session);
    return session;
  };

  const handleSend = (text: string) => {
    if (!text.trim()) return;
    const userMsg: Message = { role: 'user', content: text };
    setMessages((prev) => [...prev, userMsg]);
    setInput('');
    setIsTyping(true);

    const session = ensureSession(text);
    appendChatMessage(session.id, userMsg);

    // Analytics for the admin dashboard; a guest has no session and no DB privileges.
    if (authSession?.user.id) {
      void supabase.from('ai_queries').insert({ user_id: authSession.user.id, query_text: text });
    }

    setTimeout(() => {
      const botMsg = buildBotMessage(text);
      setMessages((prev) => [...prev, botMsg]);
      setIsTyping(false);
      appendChatMessage(session.id, botMsg);
    }, 800);
  };

  const startNewChat = () => {
    setActiveChatId('');
    setCurrentSession(null);
    setMessages([greeting()]);
  };

  return (
    <div className="space-y-4">
      <div className="bg-white dark:bg-slate-900 rounded-2xl p-6 shadow-sm border border-slate-100 dark:border-slate-800">
        <div className="flex items-center gap-3 mb-4">
          <div className="w-12 h-12 bg-gradient-to-br from-primary-500 to-primary-700 rounded-xl flex items-center justify-center">
            <Sparkles className="w-6 h-6 text-white" />
          </div>
          <div className="flex-1">
            <h2 className="text-xl font-bold text-slate-800 dark:text-slate-100">المساعد الذكي التفاعلي</h2>
            <p className="text-sm text-slate-500 dark:text-slate-300">اسأل المنصة — حل مسائل الفيزياء خطوة بخطوة</p>
          </div>
          <button
            onClick={startNewChat}
            className="flex items-center gap-1.5 px-3 py-2 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-600 dark:text-slate-300 rounded-xl text-xs font-bold transition-all flex-shrink-0"
          >
            <Plus className="w-4 h-4" />
            محادثة جديدة
          </button>
        </div>
      </div>

      <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-100 dark:border-slate-800 shadow-sm flex flex-col h-[600px]">
        <div className="flex-1 overflow-y-auto p-4 space-y-4">
          {messages.map((msg, idx) => (
            <div
              key={idx}
              className={`flex gap-3 animate-slide-up ${msg.role === 'user' ? 'flex-row-reverse' : ''}`}
            >
              <div
                className={`flex-shrink-0 w-9 h-9 rounded-full flex items-center justify-center ${
                  msg.role === 'user'
                    ? 'bg-slate-200 dark:bg-slate-700'
                    : 'bg-gradient-to-br from-primary-500 to-primary-700'
                }`}
              >
                {msg.role === 'user' ? (
                  <User className="w-5 h-5 text-slate-600 dark:text-slate-300" />
                ) : (
                  <Bot className="w-5 h-5 text-white" />
                )}
              </div>
              <div
                className={`max-w-[75%] rounded-2xl p-3.5 ${
                  msg.role === 'user'
                    ? 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-100'
                    : 'bg-primary-50 dark:bg-primary-500/15 text-slate-700 dark:text-slate-100 border border-primary-100 dark:border-primary-500/30'
                }`}
              >
                <p className="text-sm leading-relaxed">{msg.content}</p>
                {msg.sections && msg.sections.length > 0 && (
                  <div className="mt-3 space-y-3">
                    {msg.sections.map((section, sectionIdx) => (
                      <section key={sectionIdx} className="bg-white dark:bg-slate-900 rounded-lg p-3 border border-primary-100 dark:border-primary-500/30">
                        <h4 className="text-xs font-bold text-primary-700 dark:text-primary-300 mb-1.5">{section.title}</h4>
                        <p className="text-xs text-slate-700 dark:text-slate-100 leading-7 whitespace-pre-line" dir="auto">{section.body}</p>
                      </section>
                    ))}
                  </div>
                )}
                {msg.steps && msg.steps.length > 0 && (
                  <div className="mt-3 space-y-2">
                    {msg.steps.map((step, sIdx) => <p key={sIdx} className="text-xs text-slate-700 dark:text-slate-100 leading-relaxed">{step}</p>)}
                  </div>
                )}
              </div>
            </div>
          ))}

          {isTyping && (
            <div className="flex gap-3 animate-slide-up">
              <div className="flex-shrink-0 w-9 h-9 rounded-full bg-gradient-to-br from-primary-500 to-primary-700 flex items-center justify-center">
                <Bot className="w-5 h-5 text-white" />
              </div>
              <div className="bg-primary-50 dark:bg-primary-500/15 rounded-2xl p-4 border border-primary-100 dark:border-primary-500/30">
                <div className="flex gap-1.5">
                  <span className="w-2 h-2 bg-primary-400 rounded-full animate-bounce" style={{ animationDelay: '0ms' }}></span>
                  <span className="w-2 h-2 bg-primary-400 rounded-full animate-bounce" style={{ animationDelay: '150ms' }}></span>
                  <span className="w-2 h-2 bg-primary-400 rounded-full animate-bounce" style={{ animationDelay: '300ms' }}></span>
                </div>
              </div>
            </div>
          )}
          <div ref={messagesEndRef} />
        </div>

        <div className="border-t border-slate-100 dark:border-slate-800 p-3">
          <div className="flex gap-2 mb-3 overflow-x-auto pb-1">
            {quickQuestions.map((qq, idx) => (
              <button
                key={idx}
                onClick={() => handleSend(qq)}
                className="flex-shrink-0 px-3 py-1.5 bg-slate-100 dark:bg-slate-800 hover:bg-primary-50 hover:text-primary-700 text-slate-600 dark:text-slate-300 rounded-lg text-xs font-semibold transition-all whitespace-nowrap"
              >
                {qq}
              </button>
            ))}
          </div>

          <div className="flex gap-2">
            <input
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleSend(input)}
              placeholder="اكتب سؤالك هنا..."
              className="flex-1 px-4 py-2.5 bg-slate-100 dark:bg-slate-800 rounded-xl border border-transparent focus:border-primary-400 focus:bg-white dark:focus:bg-slate-900 focus:ring-2 focus:ring-primary-100 dark:focus:ring-primary-500/30 transition-all text-sm text-slate-700 dark:text-slate-100 placeholder:text-slate-400 dark:placeholder:text-slate-500 outline-none"
            />
            <button
              onClick={() => handleSend(input)}
              disabled={!input.trim() || isTyping}
              className="px-4 py-2.5 bg-primary-600 hover:bg-primary-700 disabled:bg-slate-300 text-white rounded-xl transition-all flex items-center gap-2 text-sm font-semibold"
            >
              <Send className="w-4 h-4" />
              إرسال
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
