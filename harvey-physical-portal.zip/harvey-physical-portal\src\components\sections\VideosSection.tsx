import { useState, useMemo } from 'react';
import { Video, Play, Search, Youtube, FlaskConical } from 'lucide-react';
import { lessons, chapters, chapterLabel } from '@/data/lessons';
import { interactiveSources } from '@/data/interactiveSources';
import { chapterSolid } from '@/lib/chapterTheme';

interface VideosSectionProps {
  searchQuery: string;
}

export default function VideosSection({ searchQuery }: VideosSectionProps) {
  const [selectedChapter, setSelectedChapter] = useState<number>(0);

  const filtered = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    if (!q) return lessons;
    return lessons.filter((l) => l.title.toLowerCase().includes(q));
  }, [searchQuery]);

  const chapterLessons = filtered.filter(
    (l) => l.chapter === selectedChapter || selectedChapter === 0
  );

  return (
    <div className="space-y-6">
      <div className="bg-white dark:bg-slate-900 rounded-2xl p-6 shadow-sm border border-slate-100 dark:border-slate-800">
        <div className="flex items-center gap-3 mb-4">
          <div className="w-12 h-12 bg-red-50 dark:bg-red-500/15 rounded-xl flex items-center justify-center">
            <Video className="w-6 h-6 text-red-600 dark:text-red-300" />
          </div>
          <div>
            <h2 className="text-xl font-bold text-slate-800 dark:text-slate-100">فيديوهات الشرح</h2>
            <p className="text-sm text-slate-500 dark:text-slate-300">روابط يوتيوب مباشرة ومصادر تفاعلية ومحاكاة لكل درس</p>
          </div>
        </div>

        <div className="flex gap-2 flex-wrap">
          <button
            onClick={() => setSelectedChapter(0)}
            className={`px-4 py-2 rounded-lg text-sm font-semibold transition-all ${
              selectedChapter === 0
                ? 'bg-primary-600 text-white shadow-md'
                : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700'
            }`}
          >
            جميع الفيديوهات
          </button>
          {chapters.map((ch) => (
            <button
              key={ch.id}
              onClick={() => setSelectedChapter(ch.id)}
              className={`px-4 py-2 rounded-lg text-sm font-semibold transition-all text-right ${
                selectedChapter === ch.id
                  ? 'bg-primary-600 text-white shadow-md'
                  : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700'
              }`}
            >
              <span className="block">{ch.title}</span>
              <span className="block text-[11px] font-normal opacity-80">{ch.subtitle}</span>
            </button>
          ))}
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {chapterLessons.map((lesson) => {
          const youtubeUrl = `https://www.youtube.com/results?search_query=${encodeURIComponent(lesson.youtubeSearch)}`;
          const sources = interactiveSources(lesson);
          return (
            <div
              key={lesson.id}
              className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-100 dark:border-slate-800 shadow-sm overflow-hidden hover:shadow-lg transition-all group"
            >
              <div className="relative h-36 bg-gradient-to-br from-red-500 to-red-700 flex items-center justify-center overflow-hidden">
                <div className="absolute inset-0 opacity-20 bg-[url('data:image/svg+xml,%3Csvg%20xmlns%3D%22http%3A//www.w3.org/2000/svg%22%20viewBox%3D%220%200%2050%2050%22%3E%3C/svg%3E')]"></div>
                <div className="relative z-10 text-center">
                  <div className="w-14 h-14 bg-white/20 backdrop-blur rounded-full flex items-center justify-center mb-2 mx-auto group-hover:scale-110 transition-transform">
                    <Play className="w-7 h-7 text-white fill-white mr-1" />
                  </div>
                  <p className="text-white/90 text-xs font-semibold">درس رقم {lesson.id}</p>
                </div>
                <span
                  className={`absolute top-2 right-2 text-xs px-2 py-1 rounded-full font-semibold ${chapterSolid[lesson.chapter]}`}
                >
                  {chapterLabel(lesson.chapter)}
                </span>
              </div>

              <div className="p-4">
                <h3 className="font-bold text-slate-800 dark:text-slate-100 text-sm mb-3 line-clamp-2 min-h-[2.5rem]">
                  {lesson.title}
                </h3>

                <div className="space-y-2">
                  <a
                    href={youtubeUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="w-full flex items-center justify-center gap-2 py-2.5 bg-red-600 hover:bg-red-700 text-white rounded-xl text-sm font-semibold transition-all hover:shadow-md"
                  >
                    <Youtube className="w-4 h-4" />
                    مشاهدة على يوتيوب
                  </a>
                  <a
                    href={`https://www.google.com/search?q=${encodeURIComponent(lesson.youtubeSearch)}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="w-full flex items-center justify-center gap-2 py-2.5 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-100 rounded-xl text-sm font-semibold transition-all"
                  >
                    <Search className="w-4 h-4" />
                    بحث في جوجل
                  </a>
                </div>

                <div className="pt-3 border-t border-slate-100 dark:border-slate-800">
                  <div className="flex items-center gap-1.5 mb-2">
                    <FlaskConical className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
                    <span className="text-xs font-bold text-slate-600 dark:text-slate-300">مصادر تفاعلية</span>
                  </div>
                  <div className="flex flex-wrap gap-1.5">
                    {sources.map((source) => (
                      <a
                        key={source.label}
                        href={source.url}
                        target="_blank"
                        rel="noopener noreferrer"
                        title={source.hint}
                        className="px-2.5 py-1 rounded-lg text-[11px] font-semibold bg-emerald-50 dark:bg-emerald-500/15 text-emerald-700 dark:text-emerald-300 hover:bg-emerald-100 dark:hover:bg-emerald-500/25 transition-all"
                      >
                        {source.label}
                      </a>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {chapterLessons.length === 0 && (
        <div className="text-center py-12 text-slate-400 dark:text-slate-500">
          <Video className="w-12 h-12 mx-auto mb-3 opacity-40" />
          <p>لا توجد فيديوهات مطابقة لبحثك</p>
        </div>
      )}
    </div>
  );
}
