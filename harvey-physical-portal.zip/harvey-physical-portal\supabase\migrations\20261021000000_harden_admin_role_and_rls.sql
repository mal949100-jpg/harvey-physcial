/*
# Harden admin role + real row level security

## Why
The previous setup had two holes:

1. The app decided "admin" from `window.location.pathname === '/admin'` (client-side only).
2. `profiles` had an `update_own_profile` policy `USING (auth.uid() = id) WITH CHECK (auth.uid() = id)`,
   so a signed-in student could write `is_admin = true` on their own row and become admin.
   The `promote_owner_admin` trigger only ever forced the flag ON for the owner email — it never
   reset it — so nothing stopped that escalation.

## What this does
- Replaces the writable `is_admin` boolean with a `role` column ('admin' | 'student') and makes
  `is_admin` a GENERATED column derived from it, so it can never be written directly.
- Adds `public.admin_emails` as the single source of truth for who may be promoted.
- Adds `public.is_admin()` — a SECURITY DEFINER helper — so policies stop self-referencing
  `profiles` (which was the reason `fix_rls_admin_email_access.sql` had to reach into `auth.users`).
- Removes the hardcoded admin email from RLS policies.
- Enables RLS on every app table and revokes `anon` access entirely:
  student data is unreachable without a real session. `FORCE` is deliberately not used —
  see the note above the DO block.

## Notes
- Column names verified against the real migrations: `chat_sessions.user_id`,
  `chat_messages.session_id`, `quiz_results.user_id`, `flashcard_progress.user_id`.
- Run in the Supabase SQL editor as a single transaction, then rotate the anon key.
*/

BEGIN;

-- ==================== ADMIN ALLOWLIST ====================
CREATE TABLE IF NOT EXISTS public.admin_emails (
  email text PRIMARY KEY,
  note text DEFAULT '',
  created_at timestamptz NOT NULL DEFAULT now()
);

INSERT INTO public.admin_emails (email, note)
VALUES ('mal949100@gmail.com', 'Super Admin — MOHAMED ALY ELDAFRAWY')
ON CONFLICT (email) DO NOTHING;

-- Only the SECURITY DEFINER trigger needs this (it runs as the table owner),
-- so no API role gets read access to the allowlist.
REVOKE ALL ON public.admin_emails FROM anon, authenticated;

-- ==================== PROFILES: role column ====================
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS role text NOT NULL DEFAULT 'student';

UPDATE public.profiles SET role = 'admin' WHERE is_admin = true AND role <> 'admin';
UPDATE public.profiles SET role = 'student' WHERE role NOT IN ('admin', 'student') OR role IS NULL;

ALTER TABLE public.profiles DROP CONSTRAINT IF EXISTS profiles_role_check;
ALTER TABLE public.profiles
  ADD CONSTRAINT profiles_role_check CHECK (role IN ('admin', 'student'));

CREATE INDEX IF NOT EXISTS idx_profiles_role ON public.profiles(role);

-- The escalation trigger is no longer needed: promotion happens in promote_profile_role below.
DROP TRIGGER IF EXISTS on_profile_owner_promote ON public.profiles;
DROP FUNCTION IF EXISTS public.promote_owner_admin();

-- is_admin becomes derived, so no client (or policy) can set it on its own.
ALTER TABLE public.profiles DROP COLUMN is_admin;
ALTER TABLE public.profiles
  ADD COLUMN is_admin boolean GENERATED ALWAYS AS (role = 'admin') STORED;

-- Promote/demote from the allowlist only. Runs on insert and on email change.
CREATE OR REPLACE FUNCTION public.promote_profile_role()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF EXISTS (SELECT 1 FROM public.admin_emails a WHERE a.email = NEW.email) THEN
    NEW.role := 'admin';
  ELSE
    NEW.role := 'student';
  END IF;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS on_profile_promote_role ON public.profiles;
CREATE TRIGGER on_profile_promote_role
  BEFORE INSERT OR UPDATE OF email, role ON public.profiles
  FOR EACH ROW EXECUTE FUNCTION public.promote_profile_role();

-- ==================== is_admin() HELPER ====================
-- SECURITY DEFINER so the admin policies on `profiles` do not read `profiles` itself
-- (that recursion is why the earlier migration fell back to auth.users).
CREATE OR REPLACE FUNCTION public.is_admin()
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.profiles p
    WHERE p.id = auth.uid() AND p.role = 'admin'
  );
$$;

REVOKE ALL ON FUNCTION public.is_admin() FROM anon;
GRANT ALL ON FUNCTION public.is_admin() TO authenticated;

-- handle_new_user must not trust a client-supplied metadata role either; the
-- promote_profile_role trigger above overwrites whatever the insert claims.
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_full_name text;
BEGIN
  v_full_name := COALESCE(
    NEW.raw_user_meta_data->>'full_name',
    NEW.raw_user_meta_data->>'name',
    NEW.raw_user_meta_data->'user_metadata'->>'name',
    NEW.raw_user_meta_data->'metadata'->>'name',
    NEW.raw_user_meta_data->>'user_full_name',
    ''
  );

  INSERT INTO public.profiles (id, email, full_name)
  VALUES (NEW.id, NEW.email, v_full_name)
  ON CONFLICT (id) DO NOTHING;

  RETURN NEW;
END;
$$;

-- ==================== RLS + NO ANON ====================
-- RLS is ENABLED (not FORCEd) on purpose: FORCE would also apply to the table owner,
-- and that is the role the SECURITY DEFINER functions above (handle_new_user,
-- promote_profile_role) run as — signing up a new student would start failing.
-- Every API role that can reach these tables is anon or authenticated, and both are
-- covered: RLS applies to them, and anon additionally has no table privileges at all.
DO $$
DECLARE
  t text;
BEGIN
  FOREACH t IN ARRAY ARRAY[
    'profiles', 'chat_sessions', 'chat_messages', 'ai_queries',
    'quiz_results', 'flashcard_progress'
  ]
  LOOP
    EXECUTE format('ALTER TABLE public.%I ENABLE ROW LEVEL SECURITY', t);
    EXECUTE format('REVOKE ALL ON public.%I FROM anon', t);
    EXECUTE format('GRANT SELECT, INSERT, UPDATE, DELETE ON public.%I TO authenticated', t);
  END LOOP;
END $$;

-- Drop anything granted to anon that survived from earlier revisions.
DO $$
DECLARE
  r record;
BEGIN
  FOR r IN
    SELECT schemaname, tablename, policyname
    FROM pg_policies
    WHERE schemaname = 'public'
      AND tablename IN ('profiles','chat_sessions','chat_messages','ai_queries',
                        'quiz_results','flashcard_progress')
      AND 'anon' = ANY (roles)
  LOOP
    EXECUTE format('DROP POLICY %I ON public.%I', r.policyname, r.tablename);
  END LOOP;
END $$;

-- ==================== profiles ====================
DROP POLICY IF EXISTS "select_own_profile" ON public.profiles;
DROP POLICY IF EXISTS "insert_own_profile" ON public.profiles;
DROP POLICY IF EXISTS "update_own_profile" ON public.profiles;

CREATE POLICY "profiles_select_own"
ON public.profiles FOR SELECT
TO authenticated
USING (auth.uid() = id);

CREATE POLICY "profiles_select_admin"
ON public.profiles FOR SELECT
TO authenticated
USING (public.is_admin());

-- A student may create only their own row, and only as a student.
CREATE POLICY "profiles_insert_self"
ON public.profiles FOR INSERT
TO authenticated
WITH CHECK (auth.uid() = id AND role = 'student');

-- THE FIX: students can rename themselves but can never write role='admin'.
CREATE POLICY "profiles_update_self"
ON public.profiles FOR UPDATE
TO authenticated
USING (auth.uid() = id AND role = 'student')
WITH CHECK (auth.uid() = id AND role = 'student');

CREATE POLICY "profiles_update_admin"
ON public.profiles FOR UPDATE
TO authenticated
USING (public.is_admin())
WITH CHECK (public.is_admin());

-- ==================== chat_sessions ====================
DROP POLICY IF EXISTS "select_own_sessions" ON public.chat_sessions;
DROP POLICY IF EXISTS "insert_own_sessions" ON public.chat_sessions;
DROP POLICY IF EXISTS "update_own_sessions" ON public.chat_sessions;
DROP POLICY IF EXISTS "delete_own_sessions" ON public.chat_sessions;

CREATE POLICY "chat_sessions_owner_all"
ON public.chat_sessions FOR ALL
TO authenticated
USING (auth.uid() = user_id OR public.is_admin())
WITH CHECK (auth.uid() = user_id);

-- ==================== chat_messages ====================
DROP POLICY IF EXISTS "select_own_messages" ON public.chat_messages;
DROP POLICY IF EXISTS "insert_own_messages" ON public.chat_messages;
DROP POLICY IF EXISTS "delete_own_messages" ON public.chat_messages;

CREATE POLICY "chat_messages_owner_select"
ON public.chat_messages FOR SELECT
TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM public.chat_sessions s
    WHERE s.id = chat_messages.session_id
      AND (s.user_id = auth.uid() OR public.is_admin())
  )
);

CREATE POLICY "chat_messages_owner_insert"
ON public.chat_messages FOR INSERT
TO authenticated
WITH CHECK (
  EXISTS (
    SELECT 1 FROM public.chat_sessions s
    WHERE s.id = chat_messages.session_id AND s.user_id = auth.uid()
  )
);

CREATE POLICY "chat_messages_owner_delete"
ON public.chat_messages FOR DELETE
TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM public.chat_sessions s
    WHERE s.id = chat_messages.session_id AND s.user_id = auth.uid()
  )
);

-- ==================== ai_queries ====================
DROP POLICY IF EXISTS "insert_own_query" ON public.ai_queries;
DROP POLICY IF EXISTS "select_admin_queries" ON public.ai_queries;

CREATE POLICY "ai_queries_insert_own"
ON public.ai_queries FOR INSERT
TO authenticated
WITH CHECK (auth.uid() = user_id);

CREATE POLICY "ai_queries_select_admin"
ON public.ai_queries FOR SELECT
TO authenticated
USING (public.is_admin());

-- ==================== quiz_results ====================
DROP POLICY IF EXISTS "select_own_quiz_results" ON public.quiz_results;
DROP POLICY IF EXISTS "insert_own_quiz_results" ON public.quiz_results;
DROP POLICY IF EXISTS "delete_own_quiz_results" ON public.quiz_results;

CREATE POLICY "quiz_results_owner_all"
ON public.quiz_results FOR ALL
TO authenticated
USING (auth.uid() = user_id OR public.is_admin())
WITH CHECK (auth.uid() = user_id);

-- ==================== flashcard_progress ====================
DROP POLICY IF EXISTS "select_own_flashcard_progress" ON public.flashcard_progress;
DROP POLICY IF EXISTS "upsert_own_flashcard_progress" ON public.flashcard_progress;
DROP POLICY IF EXISTS "update_own_flashcard_progress" ON public.flashcard_progress;
DROP POLICY IF EXISTS "delete_own_flashcard_progress" ON public.flashcard_progress;

CREATE POLICY "flashcard_progress_owner_all"
ON public.flashcard_progress FOR ALL
TO authenticated
USING (auth.uid() = user_id OR public.is_admin())
WITH CHECK (auth.uid() = user_id);

COMMIT;

/*
## Verify after running (SQL editor)

1. An anonymous key must see nothing:
     select count(*) from profiles;            -- as anon role, must return 0 rows / 401
     select email from profiles limit 1;       -- must be empty
   Test it from curl with the anon key only:
     curl -H "apikey: <ANON>" "https://<ref>.supabase.co/rest/v1/profiles?select=email"
     -> {"code":"42501",...} or "[]" (never a list of students)

2. A student must not be able to self-promote:
     update profiles set role='admin' where id = auth.uid();   -- must be rejected by RLS

3. The owner is still admin:
     select id, email, role, is_admin from profiles where role = 'admin';

## Still required outside the database
- Rotate the anon key / move it out of the published bundle if it was ever exposed.
- The frontend must now read the role from `supabase.auth.getSession()` + the `profiles`
  row — see src/context/AuthContext.tsx. `window.location.pathname` is no longer used.
- The admin password that was hardcoded in 20261015130940_create_super_admin_account.sql
  is now public in the repo: change it (Supabase dashboard → Authentication → Users) and
  delete that migration file from version control.
*/
