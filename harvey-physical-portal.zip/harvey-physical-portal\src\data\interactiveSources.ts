import type { Lesson } from './lessonTypes';

export interface InteractiveSource {
  label: string;
  url: string;
  hint: string;
}

/**
 * Simulation engines (PhET, GeoGebra, Falstad) index their material in English and do not
 * answer Arabic queries, so each lesson carries a short English keyword used only for search URLs.
 */
export const simKeywords: Record<number, string> = {
  1: 'relative velocity vector addition',
  2: 'horizontal projectile motion',
  3: 'projectile motion angle range',
  4: 'torque moment of force',
  5: 'static equilibrium forces',
  6: 'power and efficiency',
  7: 'impulse and momentum',
  8: 'conservation of momentum collision',
  9: 'momentum kinetic energy',
  10: 'circular motion centripetal force',
  11: 'vertical circular motion conical pendulum',
  12: 'kepler laws orbital motion gravitation',
  13: 'simple harmonic motion',
  14: 'mass spring oscillator',
  15: 'simple pendulum period',
  16: 'sine wave wavelength frequency',
  17: 'wave interference standing waves',
  18: 'wave refraction',
  19: 'sound interference beats',
  20: 'doppler effect sound',
  21: 'light refraction total internal reflection',
  22: 'thin lens image formation',
  23: 'young double slit interference',
  24: 'coulomb law electric charge',
  25: 'electric field strength',
  26: 'electric potential voltage',
  27: 'capacitance capacitor',
  28: "ohm's law current voltage",
  29: 'resistivity resistance wire',
  30: 'electric power joule heating',
  31: 'series parallel circuits',
  32: 'magnetic field lorentz force',
  33: 'electromagnetic induction faraday lenz',
  34: 'alternating current transformer',
  35: 'blackbody radiation spectrum',
  36: 'planck quantization energy',
  37: 'photoelectric effect threshold frequency',
  38: 'compton scattering photon',
  39: 'de broglie wavelength wave particle duality',
  40: 'bohr model hydrogen energy levels',
  41: 'hydrogen spectral lines rydberg',
  42: 'radioactive alpha beta gamma decay',
  43: 'radioactive half life decay law',
  44: 'nuclear binding mass defect',
  45: 'nuclear fission fusion reactor',
};

const enc = encodeURIComponent;

/** Links that go to a search on a known educational host rather than an invented deep link. */
export function interactiveSources(lesson: Lesson): InteractiveSource[] {
  const keyword = simKeywords[lesson.id] ?? 'physics simulation';
  const sources: InteractiveSource[] = [
    {
      label: 'محاكاة PhET',
      url: `https://www.google.com/search?q=${enc(`phet colorado simulations ${keyword}`)}`,
      hint: 'مختبر افتراضي مجاني من جامعة كولورادو: غيّر المتغيرات وشاهد النتيجة.',
    },
    {
      label: 'نموذج GeoGebra',
      url: `https://www.google.com/search?q=${enc(`geogebra ${keyword} physics`)}`,
      hint: 'رسم بياني تفاعلي للعلاقة بين كميات القانون.',
    },
    {
      label: 'تجربة عملية',
      url: `https://www.youtube.com/results?search_query=${enc(`${lesson.title} تجربة عملية معمل`)}`,
      hint: 'المشاهدة العملية للتجربة قبل الحل الورقي.',
    },
    {
      label: 'مرجع عربي مقروء',
      url: `https://ar.wikipedia.org/w/index.php?search=${enc(`${lesson.title} فيزياء`)}`,
      hint: 'تعريف المصطلح وسياقه العلمي في موسوعة عربية.',
    },
  ];
  if (lesson.chapter === 3) {
    sources.splice(2, 0, {
      label: 'مختبر دوائر Falstad',
      url: `https://www.google.com/search?q=${enc(`falstad ${keyword} circuit simulator`)}`,
      hint: 'توصيل دائري حيّ مع قراءة القيم لحظة بلحظة.',
    });
  }
  return sources;
}
