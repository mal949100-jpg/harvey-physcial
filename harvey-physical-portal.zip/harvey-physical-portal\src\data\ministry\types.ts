import type { MinistryReason, MinistrySymbol } from '../lessonTypes';

/** تفاصيل قانون واحد على مستوى كتاب الوزارة. */
export interface MinistryLaw {
  /** معنى كل رمز ووحدة قياسه كما ورد في القانون. */
  symbols: MinistrySymbol[];
  /** شروط وافتراضات تطبيق القانون. */
  conditions: string[];
  /** النتائج المترتبة: التناسبات وحالات المضاعفة والحالات الخاصة. */
  results: string[];
  /** العلاقة البيانية الصحيحة بين كميات القانون. */
  graph: string;
}

/** طبقة المحتوى الإضافية لكل درس: مصطلحات، ملاحظات، تعليلات، كبسولة، وتفاصيل القوانين. */
export interface MinistryLesson {
  terms: { term: string; meaning: string }[];
  notes: string[];
  reasons: MinistryReason[];
  capsule: string[];
  /** بالترتيب نفسه وعدد القوانين نفسه في lesson.laws. */
  laws: MinistryLaw[];
}

export type MinistryPart = Record<number, MinistryLesson>;
