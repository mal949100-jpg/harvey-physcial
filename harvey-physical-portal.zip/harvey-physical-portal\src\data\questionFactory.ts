import { GRAVITY_MODEL, type GravityPreset } from './physicsConstants';

export type Difficulty = 'easy' | 'medium' | 'hard';

export interface NumericProblem {
  question: string;
  choices: string[];
  correctIndex: number;
  explanation: string;
  steps: string[];
}

export interface ProblemTemplate {
  generate: (difficulty: Difficulty) => NumericProblem;
}

/* ============================================================
   DETERMINISTIC RANDOMNESS
   Questions are generated at module load and shown to the student, so a plain
   Math.random() would hand out a different paper on every reload — a saved quiz
   result would no longer match the question numbering. Every draw goes through
   this seeded generator, keyed by (lesson, difficulty, slot), so question 17 of
   the hard model of lesson 4 is always the same question with the same answer.
   ============================================================ */

export function mulberry32(seed: number): () => number {
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

let rand: () => number = Math.random;

/** Re-seeds every draw that follows; called once per generated question. */
export function seedDraw(lessonId: number, difficulty: Difficulty, slot: number): void {
  const diffOffset = difficulty === 'easy' ? 0 : difficulty === 'medium' ? 7 : 13;
  const key = lessonId * 100003 + slot * 1009 + diffOffset * 37 + 11;
  rand = mulberry32(key);
}

export function randBetween(): number {
  return rand();
}

export function shuffle<T>(arr: T[]): T[] {
  const result = [...arr];
  for (let i = result.length - 1; i > 0; i--) {
    const j = Math.floor(rand() * (i + 1));
    [result[i], result[j]] = [result[j], result[i]];
  }
  return result;
}

export function pick<T>(arr: T[]): T {
  return arr[Math.floor(rand() * arr.length)];
}

export function round(n: number, decimals = 2): number {
  const factor = Math.pow(10, decimals);
  return Math.round(n * factor) / factor;
}

/** g for the problem being generated right now, following the textbook model. */
export function gravity(): GravityPreset {
  return pick(GRAVITY_MODEL);
}

/** Filler options used only when a lesson does not supply enough wrong answers. */
export const GENERIC_WRONG = [
  'صيغة غير صحيحة لهذا القانون',
  'تعريف غير دقيق للمفهوم المطلوب',
  'الكمية المطلوبة متجهة وليست قياسية',
  'الناتج يحتاج تحويل الوحدات قبل الحساب',
];

/**
 * Always returns exactly four distinct choices with correctIndex pointing at
 * `correct`, so no question can render a duplicated or missing option.
 */
export function makeNumericChoices(correct: string, wrongs: string[]): { choices: string[]; correctIndex: number } {
  const uniqueWrong: string[] = [];
  for (const wrong of wrongs) {
    if (wrong && wrong !== correct && !uniqueWrong.includes(wrong)) uniqueWrong.push(wrong);
    if (uniqueWrong.length === 3) break;
  }
  for (const filler of GENERIC_WRONG) {
    if (uniqueWrong.length === 3) break;
    if (!uniqueWrong.includes(filler)) uniqueWrong.push(filler);
  }
  const all = shuffle([correct, ...uniqueWrong]);
  return { choices: all, correctIndex: all.indexOf(correct) };
}

export function generateWrongNumeric(base: number, unit: string): string[] {
  const variants = [
    round(base * 2, 2),
    round(base / 2, 2),
    round(base * 1.5, 2),
    round(base * 0.7, 2),
    round(base + base * 0.4, 2),
    round(base - base * 0.3, 2),
    round(base * 10, 2),
    round(base / 10, 2),
  ].filter((v) => v !== round(base, 2) && v > 0);
  return shuffle(variants).slice(0, 3).map((v) => `${v} ${unit}`);
}

export const randInt = (min: number, max: number): number => Math.floor(rand() * (max - min + 1)) + min;
export const randFloat = (min: number, max: number, decimals = 1): number => round(min + rand() * (max - min), decimals);
