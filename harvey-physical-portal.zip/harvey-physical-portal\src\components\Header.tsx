import { Menu, Atom, Search, Shield, User as UserIcon, Moon, Sun } from 'lucide-react';
import { useAuth } from '@/context/AuthContext';

interface HeaderProps {
  onMenuClick: () => void;
  searchQuery: string;
  onSearchChange: (q: string) => void;
  onAdminClick: () => void;
  darkMode: boolean;
  onToggleDarkMode: () => void;
}

export default function Header({
  onMenuClick,
  searchQuery,
  onSearchChange,
  onAdminClick,
  darkMode,
  onToggleDarkMode,
}: HeaderProps) {
  const { profile, isAdmin, roleLabel } = useAuth();

  return (
    <header className="bg-white dark:bg-slate-900 border-b border-slate-200 dark:border-slate-700 sticky top-0 z-20 shadow-sm">
      <div className="bg-gradient-to-l from-primary-700 via-primary-600 to-primary-500 text-white py-2">
        <div className="px-4 lg:px-8 flex items-center justify-between">
          <div className="flex items-center gap-2 text-sm">
            <Atom className="w-4 h-4" />
            <span className="font-semibold">هارفي فيزيكال — منصة الفيزياء للثانوية العامة</span>
          </div>
          <p className="text-xs text-primary-100 hidden sm:block">
            تم إنشاء هذا الموقع بواسطة <span className="font-bold text-white">محمد علي الدفراوي</span>
          </p>
        </div>
      </div>

      <div className="px-4 lg:px-8 py-3 flex items-center gap-4">
        <button
          onClick={onMenuClick}
          className="lg:hidden p-2 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
        >
          <Menu className="w-6 h-6 text-slate-700 dark:text-slate-100" />
        </button>

        <div className="flex-1 max-w-xl relative">
          <Search className="w-5 h-5 text-slate-400 dark:text-slate-500 absolute right-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => onSearchChange(e.target.value)}
            placeholder="ابحث في الدروس والقوانين والأسئلة..."
            className="w-full pr-11 pl-4 py-2.5 bg-slate-100 dark:bg-slate-800 rounded-xl border border-transparent focus:border-primary-400 focus:bg-white dark:focus:bg-slate-900 focus:ring-2 focus:ring-primary-100 dark:focus:ring-primary-500/30 transition-all text-sm text-slate-700 dark:text-slate-100 placeholder:text-slate-400 dark:placeholder:text-slate-500 outline-none"
          />
        </div>

        <div className="hidden md:flex items-center gap-2">
          <span className="px-3 py-1.5 bg-primary-50 dark:bg-primary-500/15 text-primary-700 dark:text-primary-300 rounded-lg text-xs font-bold">
            الصف الثاني الثانوي
          </span>
          <span className="px-3 py-1.5 bg-emerald-50 dark:bg-emerald-500/15 text-emerald-700 dark:text-emerald-300 rounded-lg text-xs font-bold">
            2026
          </span>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={onToggleDarkMode}
            aria-label={darkMode ? 'تفعيل الوضع الفاتح' : 'تفعيل الوضع الداكن'}
            className="p-2 rounded-lg bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-600 dark:text-slate-300 transition-colors"
          >
            {darkMode ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
          </button>
          {isAdmin && (
            <button
              onClick={onAdminClick}
              className="hidden sm:flex items-center gap-1.5 px-3 py-2 bg-amber-50 dark:bg-amber-500/15 hover:bg-amber-100 dark:hover:bg-amber-500/25 text-amber-700 dark:text-amber-300 rounded-lg text-xs font-bold transition-all"
            >
              <Shield className="w-4 h-4" />
              الإدارة
            </button>
          )}
          <div className="hidden sm:flex items-center gap-2">
            <div className="w-8 h-8 bg-gradient-to-br from-primary-500 to-primary-700 rounded-full flex items-center justify-center text-xs font-bold text-white">
              {profile.full_name?.charAt(0) || <UserIcon className="w-4 h-4" />}
            </div>
            {isAdmin && (
              <span className="flex items-center gap-1 text-xs font-bold text-amber-700 dark:text-amber-300 bg-amber-50 dark:bg-amber-500/15 px-2 py-1 rounded-lg">
                <Shield className="w-3 h-3" />
                {roleLabel}
              </span>
            )}
          </div>
        </div>
      </div>
    </header>
  );
}
