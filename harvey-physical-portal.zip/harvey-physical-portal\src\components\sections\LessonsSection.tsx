import { useState, useMemo } from 'react';
import { ChevronDown, BookOpen, Lightbulb, FileText, GraduationCap, Calculator, TriangleAlert, ListChecks } from 'lucide-react';
import { chapterLabel, chapters, getDeepDiveContent, lessons, termLabel, termOfChapter } from '@/data/lessons';
import { chapterSoft } from '@/lib/chapterTheme';

interface LessonsSectionProps {
  searchQuery: string;
}

export default function LessonsSection({ searchQuery }: LessonsSectionProps) {
  const [expandedId, setExpandedId] = useState<number | null>(1);
  const [selectedChapter, setSelectedChapter] = useState<number>(0);

  const filtered = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    if (!q) return lessons;
    return lessons.filter(
      (l) =>
        l.title.toLowerCase().includes(q) ||
        l.summary.toLowerCase().includes(q) ||
        l.concepts.some((c) => c.title.toLowerCase().includes(q) || c.detail.toLowerCase().includes(q))
    );
  }, [searchQuery]);

  const chapterLessons = filtered.filter((l) => l.chapter === selectedChapter || selectedChapter === 0);

  return (
    <div className="space-y-6">
      <div className="rounded-2xl p-6 shadow-sm border border-slate-100 dark:border-slate-800" style={{ backgroundColor: '#93c5fd' }}>
        <div className="flex items-center gap-3 mb-4">
          <div className="w-12 h-12 bg-white/30 rounded-xl flex items-center justify-center">
            <BookOpen className="w-6 h-6 text-primary-700 dark:text-primary-300" />
          </div>
          <div>
            <h2 className="text-xl font-bold text-slate-800 dark:text-slate-100">شرح الدروس وكتاب الوزارة</h2>
            <p className="text-sm text-slate-700 dark:text-slate-100">شرح نظري شامل وملخصات لكل دروس المنهج ({lessons.length} درساً في {chapters.length} فصول)</p>
          </div>
        </div>

        <div className="flex gap-2 flex-wrap">
          <button
            onClick={() => setSelectedChapter(0)}
            className={`px-4 py-2 rounded-lg text-sm font-semibold transition-all ${
              selectedChapter === 0
                ? 'bg-primary-600 text-white shadow-md'
                : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700'
            }`}
          >
            جميع الدروس
          </button>
          {chapters.map((ch) => (
            <button
              key={ch.id}
              onClick={() => setSelectedChapter(ch.id)}
              className={`px-4 py-2 rounded-lg text-sm font-semibold transition-all text-right ${
                selectedChapter === ch.id
                  ? 'bg-primary-600 text-white shadow-md'
                  : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700'
              }`}
            >
              <span className="block">{ch.title}</span>
              <span className="block text-[11px] font-normal opacity-80">{ch.subtitle}</span>
            </button>
          ))}
        </div>
      </div>

      <div className="space-y-3">
        {chapterLessons.map((lesson) => {
          const isOpen = expandedId === lesson.id;
          return (
            <div
              key={lesson.id}
              className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-100 dark:border-slate-800 shadow-sm overflow-hidden transition-all hover:shadow-md"
            >
              <button
                onClick={() => setExpandedId(isOpen ? null : lesson.id)}
                className="w-full flex items-center gap-4 p-5 text-right hover:bg-slate-50/50 transition-colors"
              >
                <div
                  className={`flex-shrink-0 w-12 h-12 rounded-xl flex items-center justify-center font-bold text-lg ${chapterSoft[lesson.chapter]}`}
                >
                  {lesson.id}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 flex-wrap">
                    <h3 className="font-bold text-slate-800 dark:text-slate-100 text-base">{lesson.title}</h3>
                    <span className={`text-xs px-2 py-0.5 rounded-full ${chapterSoft[lesson.chapter]}`}>
                      {chapterLabel(lesson.chapter)}
                    </span>
                    <span className="text-xs px-2 py-0.5 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300">
                      {termLabel(termOfChapter(lesson.chapter))}
                    </span>
                  </div>
                  <p className="text-sm text-slate-500 dark:text-slate-300 mt-1 line-clamp-1">{lesson.summary}</p>
                </div>
                <ChevronDown
                  className={`w-5 h-5 text-slate-400 dark:text-slate-500 flex-shrink-0 transition-transform ${
                    isOpen ? 'rotate-180' : ''
                  }`}
                />
              </button>

              {isOpen && (() => {
                const deepDive = getDeepDiveContent(lesson);
                return (
                  <div className="px-5 pb-5 space-y-5 animate-slide-down">
                    <section className="border-t border-slate-100 dark:border-slate-800 pt-4">
                      <div className="flex items-center gap-2 mb-3">
                        <GraduationCap className="w-5 h-5 text-primary-600 dark:text-primary-300" />
                        <h4 className="font-bold text-slate-700 dark:text-slate-100">مقدمة ومدخل للمفهوم العلمي</h4>
                      </div>
                      <p className="text-sm text-slate-600 dark:text-slate-300 leading-8">{deepDive.introduction}</p>
                    </section>

                    <section className="rounded-2xl p-5 border border-emerald-100 dark:border-emerald-500/30 bg-emerald-50/70 dark:bg-emerald-500/10">
                      <div className="flex items-center gap-2 mb-3">
                        <FileText className="w-5 h-5 text-emerald-600 dark:text-emerald-300" />
                        <h4 className="font-bold text-slate-700 dark:text-slate-100">كبسولة المراجعة قبل الحل</h4>
                      </div>
                      <ol className="list-decimal list-inside space-y-1.5 text-xs text-slate-700 dark:text-slate-100 leading-7">
                        {deepDive.capsule.map((point, idx) => <li key={idx}>{point}</li>)}
                      </ol>
                    </section>

                    <section className="bg-primary-50/60 rounded-2xl p-5 border border-primary-100 dark:border-primary-500/30">
                      <div className="flex items-center gap-2 mb-4">
                        <BookOpen className="w-5 h-5 text-primary-600 dark:text-primary-300" />
                      </div>
                      <div className="space-y-4">
                        {deepDive.lectureScript.map((paragraph, idx) => (
                          <p key={idx} className="text-sm text-slate-700 dark:text-slate-100 leading-8">{paragraph}</p>
                        ))}
                      </div>
                    </section>

                    <section>
                      <div className="flex items-center gap-2 mb-3">
                        <Lightbulb className="w-5 h-5 text-amber-500 dark:text-amber-300" />
                        <h4 className="font-bold text-slate-700 dark:text-slate-100">المفاهيم الأساسية والحدس الفيزيائي</h4>
                      </div>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                        {lesson.concepts.map((concept, idx) => (
                          <div key={idx} className="bg-slate-50 dark:bg-slate-800 rounded-xl p-4 border border-slate-100 dark:border-slate-800">
                            <h5 className="font-semibold text-sm text-slate-700 dark:text-slate-100 mb-2">{concept.title}</h5>
                            <p className="text-xs text-slate-600 dark:text-slate-300 leading-7">{concept.detail}</p>
                          </div>
                        ))}
                      </div>
                    </section>

                    <section>
                      <div className="flex items-center gap-2 mb-3">
                        <BookOpen className="w-5 h-5 text-primary-600 dark:text-primary-300" />
                        <h4 className="font-bold text-slate-700 dark:text-slate-100">المصطلحات وتعريفاتها كما وردت في الكتاب</h4>
                      </div>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                        {deepDive.terminology.map((entry, idx) => (
                          <div key={idx} className="bg-white dark:bg-slate-900 rounded-xl p-4 border border-primary-100 dark:border-primary-500/30">
                            <h5 className="font-bold text-xs text-primary-700 dark:text-primary-300 mb-1.5">{entry.term}</h5>
                            <p className="text-xs text-slate-600 dark:text-slate-300 leading-7">{entry.meaning}</p>
                          </div>
                        ))}
                      </div>
                    </section>

                    <section>
                      <div className="flex items-center gap-2 mb-3">
                        <ListChecks className="w-5 h-5 text-emerald-600 dark:text-emerald-300" />
                        <h4 className="font-bold text-slate-700 dark:text-slate-100">الملاحظات الهامة</h4>
                      </div>
                      <ul className="list-disc list-inside space-y-2 bg-emerald-50 dark:bg-emerald-500/15 rounded-xl p-4 text-xs text-slate-700 dark:text-slate-100 leading-7 border border-emerald-100 dark:border-emerald-500/30">
                        {deepDive.notes.map((note, idx) => <li key={idx}>{note}</li>)}
                      </ul>
                    </section>

                    <section>
                      <div className="flex items-center gap-2 mb-3">
                        <Lightbulb className="w-5 h-5 text-primary-600 dark:text-primary-300" />
                        <h4 className="font-bold text-slate-700 dark:text-slate-100">علل لما يأتي — بأسلوب الوزارة</h4>
                      </div>
                      <div className="space-y-3">
                        {deepDive.reasons.map((reason, idx) => (
                          <div key={idx} className="bg-slate-50 dark:bg-slate-800 rounded-xl p-4 border border-slate-100 dark:border-slate-800">
                            <p className="text-xs font-bold text-slate-700 dark:text-slate-100 leading-7 mb-2">{idx + 1}. {reason.question}</p>
                            <p className="text-xs text-slate-600 dark:text-slate-300 leading-7">الإجابة: {reason.answer}</p>
                          </div>
                        ))}
                      </div>
                    </section>

                    <section>
                      <div className="flex items-center gap-2 mb-3">
                        <Calculator className="w-5 h-5 text-emerald-600 dark:text-emerald-300" />
                        <h4 className="font-bold text-slate-700 dark:text-slate-100">الاستنتاجات والقوانين بالكامل</h4>
                      </div>
                      <div className="space-y-3">
                        {deepDive.derivations.map((derivation, idx) => (
                          <div key={idx} className="bg-emerald-50 dark:bg-emerald-500/15 rounded-xl p-4 border border-emerald-100 dark:border-emerald-500/30">
                            <h5 className="font-bold text-sm text-emerald-800 dark:text-emerald-200 mb-2">{derivation.title}</h5>
                            <ol className="list-decimal list-inside space-y-2 text-xs text-slate-700 dark:text-slate-100 leading-7">
                              {derivation.steps.map((step, stepIdx) => <li key={stepIdx}>{step}</li>)}
                            </ol>
                            <div className="mt-3 rounded-lg bg-white/70 dark:bg-slate-900/60 border border-emerald-100 dark:border-emerald-500/30 p-3">
                              <p className="text-xs font-bold text-emerald-800 dark:text-emerald-200 mb-1">النتائج المترتبة على القانون</p>
                              <ul className="list-disc list-inside space-y-1 text-xs text-slate-700 dark:text-slate-100 leading-7">
                                {derivation.results.map((result, resultIdx) => <li key={resultIdx}>{result}</li>)}
                              </ul>
                            </div>
                            <p className="text-xs text-emerald-800 dark:text-emerald-200 mt-3 leading-7">{derivation.note}</p>
                          </div>
                        ))}
                      </div>
                    </section>

                    <section className="bg-amber-50 dark:bg-amber-500/15 rounded-2xl p-5 border border-amber-100 dark:border-amber-500/30">
                      <div className="flex items-center gap-2 mb-3">
                        <TriangleAlert className="w-5 h-5 text-amber-600 dark:text-amber-300" />
                        <h4 className="font-bold text-slate-700 dark:text-slate-100">تريكات ونقاط خفية في الامتحان</h4>
                      </div>
                      <ul className="list-disc list-inside space-y-2 text-xs text-slate-700 dark:text-slate-100 leading-7">
                        {deepDive.pitfalls.map((pitfall, idx) => <li key={idx}>{pitfall}</li>)}
                      </ul>
                    </section>

                    <section>
                      <div className="flex items-center gap-2 mb-3">
                        <ListChecks className="w-5 h-5 text-blue-600 dark:text-blue-300" />
                        <h4 className="font-bold text-slate-700 dark:text-slate-100">إطار حل جميع أنواع المسائل</h4>
                      </div>
                      <ol className="list-decimal list-inside space-y-2 bg-blue-50 dark:bg-blue-500/15 rounded-xl p-4 text-xs text-slate-700 dark:text-slate-100 leading-7">
                        {deepDive.problemFramework.map((step, idx) => <li key={idx}>{step}</li>)}
                      </ol>
                    </section>

                    <section>
                      <div className="flex items-center gap-2 mb-3">
                        <FileText className="w-5 h-5 text-primary-600 dark:text-primary-300" />
                        <h4 className="font-bold text-slate-700 dark:text-slate-100">أمثلة محلولة بخطوات تفكير المدرس</h4>
                      </div>
                      <div className="space-y-3">
                        {lesson.questions.map((question, idx) => (
                          <div key={idx} className="bg-white dark:bg-slate-900 rounded-xl p-4 border border-slate-200 dark:border-slate-700 shadow-sm">
                            <p className="text-sm font-bold text-slate-700 dark:text-slate-100 leading-7">سؤال {idx + 1}: {question.q}</p>
                            <ol className="list-decimal list-inside space-y-1 mt-3 text-xs text-slate-600 dark:text-slate-300 leading-7">
                              {question.steps.map((step, stepIdx) => <li key={stepIdx}>{step}</li>)}
                            </ol>
                            <p className="text-sm font-bold text-primary-700 dark:text-primary-300 mt-3">الإجابة النهائية: {question.answer}</p>
                          </div>
                        ))}
                      </div>
                    </section>
                  </div>
                );
              })()}
            </div>
          );
        })}

        {chapterLessons.length === 0 && (
          <div className="text-center py-12 text-slate-400 dark:text-slate-500">
            <BookOpen className="w-12 h-12 mx-auto mb-3 opacity-40" />
            <p>لا توجد نتائج مطابقة لبحثك</p>
          </div>
        )}
      </div>
    </div>
  );
}
