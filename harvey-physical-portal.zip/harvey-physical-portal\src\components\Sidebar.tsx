import {
  BookOpen,
  Scale,
  Video,
  HelpCircle,
  MessageSquare,
  Atom,
  X,
  History,
  ClipboardList,
  Shield,
  FileText,
  ClipboardCheck,
  Layers,
  Target,
  Database,
} from 'lucide-react';
import { useAuth } from '@/context/AuthContext';

export type TabId =
  | 'lessons'
  | 'laws'
  | 'videos'
  | 'questions'
  | 'assistant'
  | 'saved-chats'
  | 'exams'
  | 'summaries'
  | 'quizzes'
  | 'flashcards'
  | 'weakness'
  | 'my-data';

interface SidebarProps {
  activeTab: TabId;
  onTabChange: (tab: TabId) => void;
  isOpen: boolean;
  onClose: () => void;
  onAdminClick: () => void;
}

const navItems: { id: TabId; label: string; icon: typeof BookOpen; description: string }[] = [
  { id: 'lessons', label: 'شرح الدروس وكتاب الوزارة', icon: BookOpen, description: 'النظريات والملخصات' },
  { id: 'summaries', label: 'الملخصات', icon: FileText, description: 'ملخصات منظمة لكل فصل' },
  { id: 'laws', label: 'شرح القوانين والمعادلات', icon: Scale, description: 'القوانين والوحدات' },
  { id: 'videos', label: 'فيديوهات الشرح', icon: Video, description: 'روابط يوتيوب مباشرة' },
  { id: 'questions', label: 'بنك الأسئلة والحلول المفصلة', icon: HelpCircle, description: 'أسئلة وحلول خطوة بخطوة' },
  { id: 'quizzes', label: 'الاختبارات التفاعلية', icon: ClipboardCheck, description: 'كويزات مع تصحيح فوري' },
  { id: 'flashcards', label: 'فلاش كاردز', icon: Layers, description: 'مراجعة سريعة للقوانين' },
  { id: 'assistant', label: 'المساعد الذكي التفاعلي', icon: MessageSquare, description: 'اسأل المنصة' },
  { id: 'exams', label: 'المراجعات والامتحانات', icon: ClipboardList, description: 'مراجعات شهرية وامتحانات' },
  { id: 'saved-chats', label: 'سجل محادثاتي', icon: History, description: 'مراجعة الأسئلة السابقة' },
  { id: 'weakness', label: 'نقاط الضعف', icon: Target, description: 'تحليل أدائك ومراجعة' },
  { id: 'my-data', label: 'بياناتي ونسخة احتياطية', icon: Database, description: 'تصدير واستيراد تقدّمك' },
];

export function isTabId(value: string): value is TabId {
  return navItems.some((item) => item.id === value);
}

export default function Sidebar({
  activeTab,
  onTabChange,
  isOpen,
  onClose,
  onAdminClick,
}: SidebarProps) {
  const { profile, isAdmin, roleLabel } = useAuth();

  const renderItem = (item: (typeof navItems)[number]) => {
    const Icon = item.icon;
    const isActive = activeTab === item.id;
    return (
      <button
        key={item.id}
        onClick={() => {
          onTabChange(item.id);
          onClose();
        }}
        className={`w-full flex items-center gap-3 p-3.5 rounded-xl transition-all duration-200 text-right group ${
          isActive
            ? 'bg-gradient-to-l from-primary-600 to-primary-500 shadow-lg shadow-primary-600/30'
            : 'hover:bg-white/10'
        }`}
      >
        <div
          className={`w-10 h-10 rounded-lg flex items-center justify-center transition-colors ${
            isActive ? 'bg-white/20' : 'bg-white/5 group-hover:bg-white/15'
          }`}
        >
          <Icon className={`w-5 h-5 ${isActive ? 'text-white' : 'text-primary-300'}`} />
        </div>
        <div className="flex-1 min-w-0">
          <p className={`text-sm font-semibold ${isActive ? 'text-white' : 'text-gray-200'}`}>
            {item.label}
          </p>
          <p className={`text-xs ${isActive ? 'text-primary-100' : 'text-gray-400'}`}>
            {item.description}
          </p>
        </div>
      </button>
    );
  };

  return (
    <>
      {isOpen && (
        <div
          className="fixed inset-0 bg-black/50 z-30 lg:hidden animate-fade-in"
          onClick={onClose}
        />
      )}
      <aside
        className={`fixed lg:static top-0 right-0 h-full w-80 bg-gradient-to-b from-slate-900 to-slate-800 text-white z-40 transform transition-transform duration-300 flex flex-col ${
          isOpen ? 'translate-x-0' : 'translate-x-full lg:translate-x-0'
        }`}
      >
        <div className="flex items-center justify-between p-6 border-b border-white/10">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 bg-gradient-to-br from-primary-500 to-primary-700 rounded-xl flex items-center justify-center shadow-lg">
              <Atom className="w-7 h-7 text-white" />
            </div>
            <div>
              <h1 className="text-xl font-bold">هارفي فيزيكال</h1>
              <p className="text-xs text-primary-300">منصة الفيزياء للثانوية</p>
            </div>
          </div>
          <button onClick={onClose} className="lg:hidden text-white/70 hover:text-white">
            <X className="w-6 h-6" />
          </button>
        </div>

        <div className="px-4 pt-4">
          <div className="bg-white/5 rounded-xl p-3 space-y-2">
            <div className="flex items-center gap-2">
              <div className="w-9 h-9 bg-gradient-to-br from-primary-500 to-primary-700 rounded-full flex items-center justify-center text-sm font-bold">
                {profile.full_name?.charAt(0) || 'ط'}
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-semibold truncate">
                  {profile.full_name || 'طالب زائر'}
                </p>
                <div className="flex items-center gap-1.5">
                  {isAdmin ? (
                    <span className="text-[10px] px-1.5 py-0.5 bg-amber-500/20 text-amber-300 rounded font-bold flex items-center gap-1">
                      <Shield className="w-2.5 h-2.5" />
                      {roleLabel}
                    </span>
                  ) : (
                    <span className="text-[10px] px-1.5 py-0.5 bg-white/10 text-gray-300 rounded font-semibold">
                      {roleLabel}
                    </span>
                  )}
                </div>
              </div>
            </div>
            {isAdmin && (
              <button
                onClick={() => {
                  onAdminClick();
                  onClose();
                }}
                className="w-full flex items-center justify-center gap-1.5 py-2 bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 rounded-lg text-xs font-semibold transition-all"
              >
                <Shield className="w-3.5 h-3.5" />
                لوحة الإدارة
              </button>
            )}
          </div>
        </div>

        <nav className="flex-1 overflow-y-auto p-4 space-y-2">
          {navItems.map(renderItem)}
          {isAdmin && (
            <button
              onClick={() => {
                onAdminClick();
                onClose();
              }}
              className="w-full flex items-center gap-3 p-3.5 rounded-xl transition-all duration-200 text-right group bg-amber-500/10 hover:bg-amber-500/20 border border-amber-500/20"
            >
              <div className="w-10 h-10 rounded-lg flex items-center justify-center bg-amber-500/20">
                <Shield className="w-5 h-5 text-amber-400" />
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-semibold text-amber-300">لوحة الإدارة</p>
                <p className="text-xs text-amber-400/60">إدارة الطلاب والتحليلات</p>
              </div>
            </button>
          )}
        </nav>

        <div className="px-4 pb-4">
          <div className="rounded-xl border border-white/10 bg-white/5 p-3 space-y-2">
            <p className="text-xs font-bold text-slate-300">روابط سريعة</p>
            <button
              onClick={() => { onTabChange('exams'); onClose(); }}
              className="w-full text-right text-xs text-slate-300 hover:text-white transition-colors"
            >
              المراجعات والامتحانات السابقة
            </button>
            <button
              onClick={() => { onTabChange('weakness'); onClose(); }}
              className="w-full text-right text-xs text-slate-300 hover:text-white transition-colors"
            >
              إحصائيات الأداء ونقاط الضعف
            </button>
            <a
              href="https://moe.gov.eg/"
              target="_blank"
              rel="noreferrer"
              className="block text-xs text-primary-300 hover:text-primary-200 transition-colors"
            >
              بوابة وزارة التربية والتعليم
            </a>
          </div>
        </div>

        <div className="p-4 border-t border-white/10">
          <div className="bg-white/5 rounded-xl p-3.5 text-center">
            <p className="text-xs text-gray-300 leading-relaxed">
              تم إنشاء هذا الموقع بواسطة
            </p>
            <p className="text-sm font-bold text-primary-300 mt-1">محمد علي الدفراوي</p>
          </div>
        </div>
      </aside>
    </>
  );
}
