/*
# Quiz results, flashcard progress, and weakness tracking tables

## New Tables

1. `quiz_results`
   - `id` uuid PK
   - `user_id` uuid NOT NULL DEFAULT auth.uid()
   - `quiz_id` text NOT NULL — identifies which quiz (e.g. "mechanics-1")
   - `score` int NOT NULL — number correct
   - `total` int NOT NULL — total questions
   - `wrong_topics` text[] DEFAULT '{}' — topic ids the student got wrong
   - `created_at` timestamptz DEFAULT now()

2. `flashcard_progress`
   - `id` uuid PK
   - `user_id` uuid NOT NULL DEFAULT auth.uid()
   - `card_id` text NOT NULL — identifies the flashcard
   - `status` text NOT NULL DEFAULT 'new' — 'new' | 'learning' | 'mastered'
   - `updated_at` timestamptz DEFAULT now()
   - UNIQUE(user_id, card_id)

## RLS
- quiz_results: full CRUD scoped to auth.uid() = user_id
- flashcard_progress: full CRUD scoped to auth.uid() = user_id
- Admins can read all (for analytics)
*/

CREATE TABLE IF NOT EXISTS quiz_results (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  quiz_id text NOT NULL,
  score int NOT NULL DEFAULT 0,
  total int NOT NULL DEFAULT 0,
  wrong_topics text[] NOT NULL DEFAULT '{}',
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE quiz_results ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_own_quiz_results" ON quiz_results;
CREATE POLICY "select_own_quiz_results"
ON quiz_results FOR SELECT
TO authenticated
USING (auth.uid() = user_id OR EXISTS (
  SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.is_admin = true
));

DROP POLICY IF EXISTS "insert_own_quiz_results" ON quiz_results;
CREATE POLICY "insert_own_quiz_results"
ON quiz_results FOR INSERT
TO authenticated
WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "delete_own_quiz_results" ON quiz_results;
CREATE POLICY "delete_own_quiz_results"
ON quiz_results FOR DELETE
TO authenticated
USING (auth.uid() = user_id);

CREATE INDEX IF NOT EXISTS idx_quiz_results_user_id ON quiz_results(user_id);

-- ==================== FLASHCARD_PROGRESS ====================
CREATE TABLE IF NOT EXISTS flashcard_progress (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  card_id text NOT NULL,
  status text NOT NULL DEFAULT 'new' CHECK (status IN ('new', 'learning', 'mastered')),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(user_id, card_id)
);

ALTER TABLE flashcard_progress ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_own_flashcard_progress" ON flashcard_progress;
CREATE POLICY "select_own_flashcard_progress"
ON flashcard_progress FOR SELECT
TO authenticated
USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "upsert_own_flashcard_progress" ON flashcard_progress;
CREATE POLICY "upsert_own_flashcard_progress"
ON flashcard_progress FOR INSERT
TO authenticated
WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "update_own_flashcard_progress" ON flashcard_progress;
CREATE POLICY "update_own_flashcard_progress"
ON flashcard_progress FOR UPDATE
TO authenticated
USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "delete_own_flashcard_progress" ON flashcard_progress;
CREATE POLICY "delete_own_flashcard_progress"
ON flashcard_progress FOR DELETE
TO authenticated
USING (auth.uid() = user_id);

CREATE INDEX IF NOT EXISTS idx_flashcard_progress_user_id ON flashcard_progress(user_id);
