/*
# Create profiles, chat_sessions, chat_messages, and ai_queries tables

## Purpose
Support the Harvey Physical (هارفي فيزيكال) platform upgrade:
- Student authentication with Google Sign-In and email/password
- Saving AI tutor chat history per student
- Tracking AI queries for admin analytics
- Admin dashboard for the platform owner (Mohamed Ali El-Defrawy)

## New Tables

1. `profiles`
   - `id` (uuid, PK, references auth.users) — one row per registered user
   - `full_name` (text) — student's display name
   - `email` (text) — student's email (denormalized from auth.users for admin listing)
   - `is_admin` (boolean, default false) — flag for admin access; only the owner has this set to true
   - `created_at` (timestamptz) — join date

2. `chat_sessions`
   - `id` (uuid, PK) — unique session ID
   - `user_id` (uuid, NOT NULL, DEFAULT auth.uid(), references auth.users) — owner
   - `title` (text) — first question or auto-generated title
   - `created_at` (timestamptz) — when session started

3. `chat_messages`
   - `id` (uuid, PK) — unique message ID
   - `session_id` (uuid, NOT NULL, references chat_sessions ON DELETE CASCADE) — parent session
   - `role` (text, NOT NULL) — 'user' or 'bot'
   - `content` (text, NOT NULL) — message text
   - `steps` (jsonb) — array of step strings for bot solutions
   - `created_at` (timestamptz) — when message was sent

4. `ai_queries`
   - `id` (uuid, PK) — unique query ID
   - `user_id` (uuid, NOT NULL, DEFAULT auth.uid(), references auth.users) — who asked
   - `query_text` (text, NOT NULL) — the question asked
   - `created_at` (timestamptz) — when asked
   - This table powers the admin analytics "total AI queries" counter

## Security (RLS)

### profiles
- SELECT: authenticated users can read only their own profile. Admins can read all.
- INSERT: a user can insert only their own profile row (triggered on signup).
- UPDATE: a user can update only their own profile.

### chat_sessions
- Full CRUD scoped to owner via auth.uid() = user_id.

### chat_messages
- SELECT/INSERT/UPDATE/DELETE scoped through parent session ownership:
  EXISTS (SELECT 1 FROM chat_sessions WHERE chat_sessions.id = chat_messages.session_id AND chat_sessions.user_id = auth.uid())

### ai_queries
- INSERT: authenticated users can insert only their own query (auth.uid() = user_id).
- SELECT: only admin users can read (for analytics). Regular users cannot see other users' queries.

## Important Notes
1. user_id columns default to auth.uid() so frontend inserts that omit user_id still pass RLS.
2. The admin email (mohamed.ali.eldefrawi@gmail.com) will have is_admin = true set manually or via a trigger.
3. A trigger function `handle_new_user` auto-creates a profile row when a new auth user signs up.
*/

-- ==================== PROFILES ====================
CREATE TABLE IF NOT EXISTS profiles (
  id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  full_name text DEFAULT '',
  email text DEFAULT '',
  is_admin boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_own_profile" ON profiles;
CREATE POLICY "select_own_profile"
ON profiles FOR SELECT
TO authenticated
USING (auth.uid() = id OR EXISTS (
  SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.is_admin = true
));

DROP POLICY IF EXISTS "insert_own_profile" ON profiles;
CREATE POLICY "insert_own_profile"
ON profiles FOR INSERT
TO authenticated
WITH CHECK (auth.uid() = id);

DROP POLICY IF EXISTS "update_own_profile" ON profiles;
CREATE POLICY "update_own_profile"
ON profiles FOR UPDATE
TO authenticated
USING (auth.uid() = id)
WITH CHECK (auth.uid() = id);

-- ==================== CHAT_SESSIONS ====================
CREATE TABLE IF NOT EXISTS chat_sessions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  title text NOT NULL DEFAULT 'محادثة جديدة',
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE chat_sessions ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_own_sessions" ON chat_sessions;
CREATE POLICY "select_own_sessions"
ON chat_sessions FOR SELECT
TO authenticated
USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "insert_own_sessions" ON chat_sessions;
CREATE POLICY "insert_own_sessions"
ON chat_sessions FOR INSERT
TO authenticated
WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "update_own_sessions" ON chat_sessions;
CREATE POLICY "update_own_sessions"
ON chat_sessions FOR UPDATE
TO authenticated
USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "delete_own_sessions" ON chat_sessions;
CREATE POLICY "delete_own_sessions"
ON chat_sessions FOR DELETE
TO authenticated
USING (auth.uid() = user_id);

-- ==================== CHAT_MESSAGES ====================
CREATE TABLE IF NOT EXISTS chat_messages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  session_id uuid NOT NULL REFERENCES chat_sessions(id) ON DELETE CASCADE,
  role text NOT NULL CHECK (role IN ('user', 'bot')),
  content text NOT NULL,
  steps jsonb DEFAULT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE chat_messages ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_own_messages" ON chat_messages;
CREATE POLICY "select_own_messages"
ON chat_messages FOR SELECT
TO authenticated
USING (EXISTS (
  SELECT 1 FROM chat_sessions
  WHERE chat_sessions.id = chat_messages.session_id
  AND chat_sessions.user_id = auth.uid()
));

DROP POLICY IF EXISTS "insert_own_messages" ON chat_messages;
CREATE POLICY "insert_own_messages"
ON chat_messages FOR INSERT
TO authenticated
WITH CHECK (EXISTS (
  SELECT 1 FROM chat_sessions
  WHERE chat_sessions.id = chat_messages.session_id
  AND chat_sessions.user_id = auth.uid()
));

DROP POLICY IF EXISTS "delete_own_messages" ON chat_messages;
CREATE POLICY "delete_own_messages"
ON chat_messages FOR DELETE
TO authenticated
USING (EXISTS (
  SELECT 1 FROM chat_sessions
  WHERE chat_sessions.id = chat_messages.session_id
  AND chat_sessions.user_id = auth.uid()
));

-- ==================== AI_QUERIES ====================
CREATE TABLE IF NOT EXISTS ai_queries (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  query_text text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE ai_queries ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "insert_own_query" ON ai_queries;
CREATE POLICY "insert_own_query"
ON ai_queries FOR INSERT
TO authenticated
WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "select_admin_queries" ON ai_queries;
CREATE POLICY "select_admin_queries"
ON ai_queries FOR SELECT
TO authenticated
USING (EXISTS (
  SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.is_admin = true
));

-- ==================== INDEXES ====================
CREATE INDEX IF NOT EXISTS idx_chat_sessions_user_id ON chat_sessions(user_id);
CREATE INDEX IF NOT EXISTS idx_chat_messages_session_id ON chat_messages(session_id);
CREATE INDEX IF NOT EXISTS idx_ai_queries_user_id ON ai_queries(user_id);

-- ==================== TRIGGER: auto-create profile on signup ====================
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  INSERT INTO public.profiles (id, email, full_name)
  VALUES (
    NEW.id,
    NEW.email,
    COALESCE(NEW.raw_user_meta_data->>'full_name', NEW.raw_user_meta_data->>'name', '')
  );
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();
