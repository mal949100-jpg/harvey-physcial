/*
# Create Super Admin account for mal949100@gmail.com

Full Name: MOHAMED ALY ELDAFRAWY
Email: mal949100@gmail.com
Role: admin (is_admin = true)
*/

-- Insert the auth user with bcrypt-hashed password
INSERT INTO auth.users (
  instance_id,
  id,
  aud,
  role,
  email,
  encrypted_password,
  email_confirmed_at,
  raw_app_meta_data,
  raw_user_meta_data,
  created_at,
  updated_at,
  confirmation_token,
  email_change,
  email_change_token_new,
  email_change_token_current,
  recovery_token,
  is_sso_user,
  is_anonymous
)
SELECT
  '00000000-0000-0000-0000-000000000000',
  gen_random_uuid(),
  'authenticated',
  'authenticated',
  'mal949100@gmail.com',
  crypt('4111430MO*/', gen_salt('bf', 10)),
  now(),
  '{"provider":"email","providers":["email"]}'::jsonb,
  '{"full_name":"MOHAMED ALY ELDAFRAWY","name":"MOHAMED ALY ELDAFRAWY","role":"admin"}'::jsonb,
  now(),
  now(),
  '',
  '',
  '',
  '',
  '',
  false,
  false
WHERE NOT EXISTS (SELECT 1 FROM auth.users WHERE email = 'mal949100@gmail.com');

-- Insert the identities row (required by Supabase auth)
INSERT INTO auth.identities (
  id,
  user_id,
  identity_data,
  provider_id,
  provider,
  last_sign_in_at,
  created_at,
  updated_at
)
SELECT
  gen_random_uuid(),
  u.id,
  jsonb_build_object('sub', u.id::text, 'email', 'mal949100@gmail.com', 'full_name', 'MOHAMED ALY ELDAFRAWY'),
  u.id::text,
  'email',
  now(),
  now(),
  now()
FROM auth.users u
WHERE u.email = 'mal949100@gmail.com'
AND NOT EXISTS (
  SELECT 1 FROM auth.identities i WHERE i.user_id = u.id AND i.provider = 'email'
);

-- Insert or update the profile row with is_admin = true
INSERT INTO public.profiles (id, email, full_name, is_admin, created_at)
SELECT u.id, 'mal949100@gmail.com', 'MOHAMED ALY ELDAFRAWY', true, u.created_at
FROM auth.users u
WHERE u.email = 'mal949100@gmail.com'
ON CONFLICT (id) DO UPDATE
SET is_admin = true,
    full_name = 'MOHAMED ALY ELDAFRAWY',
    email = 'mal949100@gmail.com';
