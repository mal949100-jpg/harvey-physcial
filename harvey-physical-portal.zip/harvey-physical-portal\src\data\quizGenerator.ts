import type { Lesson } from './lessons';
import type { QuizQuestion } from './studyContent';
import { GRAVITY_MOON, gravityNote } from './physicsConstants';
import {
  generateWrongNumeric,
  gravity,
  makeNumericChoices,
  pick,
  randBetween,
  randFloat,
  randInt,
  round,
  seedDraw,
  shuffle,
  type Difficulty,
  type ProblemTemplate,
} from './questionFactory';
import { electricityProblemTemplates } from './problemTemplatesElectricity';
import { modernProblemTemplates } from './problemTemplatesModern';

const rand = randBetween;

function makeQuestionId(lessonId: number, difficulty: Difficulty, index: number): string {
  return `l${lessonId}-${difficulty}-q${index}`;
}

/* ============================================================
   CONCEPTUAL QUESTIONS (from lesson concepts & laws)
   ============================================================ */

function generateConceptualQuestions(lesson: Lesson, difficulty: Difficulty, count: number): QuizQuestion[] {
  const questions: QuizQuestion[] = [];
  const conceptPool = [...lesson.concepts];
  const lawPool = [...lesson.laws];

  for (let i = 0; i < count && (conceptPool.length > 0 || lawPool.length > 0); i++) {
    seedDraw(lesson.id, difficulty, i + 1);
    const useConcept = i % 2 === 0 && conceptPool.length > 0;

    if (useConcept) {
      const concept = conceptPool[i % conceptPool.length];
      const correctDetail = concept.detail;
      const wrongDetails = lesson.concepts
        .filter((c) => c.title !== concept.title)
        .map((c) => c.detail);

      const { choices, correctIndex } = makeNumericChoices(correctDetail, wrongDetails);

      const questionText = difficulty === 'easy'
        ? `ما المقصود بـ«${concept.title}» في درس «${lesson.title}»؟`
        : difficulty === 'medium'
          ? `اختر التعريف الصحيح لـ«${concept.title}» مع تبرير اختيارك:`
          : `في موقف فيزيائي يتعلق بـ«${concept.title}»، أي العبارات الآتية تصف المفهوم بدقة وتنطبق على الحالة؟`;

      questions.push({
        id: makeQuestionId(lesson.id, difficulty, i + 1),
        topic: lesson.title,
        question: questionText,
        choices,
        correctIndex,
        explanation: `${concept.title}: ${correctDetail}`,
        steps: [
          `المطلوب: تعريف «${concept.title}» وتحديد إجابته الصحيحة.`,
          `المفهوم ينتمي إلى درس «${lesson.title}».`,
          `التعريف الصحيح: ${correctDetail}`,
          `الإجابات الأخرى تصف مفاهيم أخرى أو تخلط بين المصطلحات.`,
        ],
      });
    } else if (lawPool.length > 0) {
      const law = lawPool[i % lawPool.length];
      const correctFormula = `${law.formula} — ${law.units}`;
      const wrongFormulas = lesson.laws
        .filter((l) => l.name !== law.name)
        .map((l) => `${l.formula} — ${l.units}`);

      const { choices, correctIndex } = makeNumericChoices(correctFormula, wrongFormulas);

      const questionText = difficulty === 'easy'
        ? `ما الصيغة الصحيحة لقانون «${law.name}» ووحدة قياسه؟`
        : difficulty === 'medium'
          ? `في تطبيق يتطلب استخدام «${law.name}»، ما القانون الصحيح ووحداته؟`
          : `مسألة تتطلب اختيار القانون المناسب — أي الصيغ الآتية تمثل «${law.name}» بشكل صحيح مع وحداتها؟`;

      questions.push({
        id: makeQuestionId(lesson.id, difficulty, i + 1),
        topic: lesson.title,
        question: questionText,
        choices,
        correctIndex,
        explanation: `${law.name}: ${law.formula}، الوحدة: ${law.units}. ${law.explanation}`,
        steps: [
          `المطلوب: تحديد الصيغة الصحيحة لقانون «${law.name}».`,
          `القانون: ${law.formula}، الوحدة: ${law.units}.`,
          `المعنى الفيزيائي: ${law.explanation}`,
          `تأكد من تطابق الوحدات مع نوع الكمية المطلوبة.`,
        ],
      });
    }
  }

  return questions;
}

/* ============================================================
   NUMERIC PROBLEM GENERATORS (per topic type)
   ============================================================ */

// Lesson-specific problem templates keyed by lesson id
const problemTemplates: Record<number, ProblemTemplate[]> = {
  // Lesson 1: Velocity vectors & relative velocity
  1: [
    {
      generate: (d) => {
        const v1 = randInt(40, 120);
        const v2 = randInt(30, 100);
        const sameDir = rand() > 0.4;
        const ans = sameDir ? Math.abs(v1 - v2) : v1 + v2;
        const correct = `${ans} km/h`;
        const wrongs = generateWrongNumeric(ans, 'km/h');
        const dir = sameDir ? 'في نفس الاتجاه' : 'في اتجاهين متضادين';
        const calc = sameDir
          ? [`v₁ = ${v1} km/h، v₂ = ${v2} km/h (${dir})`, `السرعة النسبية = |v₁ - v₂| = |${v1} - ${v2}|`, `= ${ans} km/h`]
          : [`v₁ = +${v1} km/h، v₂ = -${v2} km/h (${dir})`, `السرعة النسبية = v₁ - v₂ = ${v1} - (-${v2})`, `= ${v1} + ${v2} = ${ans} km/h`];
        return {
          question: d === 'easy'
            ? `سيارتان تتحركان بسرعتين ${v1} km/h و${v2} km/h ${dir}. احسب السرعة النسبية.`
            : `سيارتان تتحركان ${dir} بسرعتين ${v1} km/h و${v2} km/h. احسب السرعة النسبية للأولى بالنسبة للثانية واذكر اتجاهها.`,
          ...makeNumericChoices(correct, wrongs),
          explanation: `السرعة النسبية = فرق المتجهين. ${correct}`,
          steps: calc,
        };
      },
    },
    {
      generate: () => {
        const vx = randInt(3, 12);
        const vy = randInt(2, 10);
        const mag = round(Math.sqrt(vx * vx + vy * vy), 2);
        const angle = round(Math.atan(vy / vx) * 180 / Math.PI, 1);
        const correct = `${mag} m/s بزاوية ${angle}°`;
        const wrongs = [`${round(mag * 1.4, 2)} m/s`, `${round(mag * 0.7, 2)} m/s`, `${vx + vy} m/s`];
        return {
          question: `قارب يتحرك بسرعة ${vx} m/s شمالاً في نهر يجرى بسرعة ${vy} m/s شرقاً. احسب سرعة القارب الناتجة بالنسبة للأرض.`,
          ...makeNumericChoices(correct, wrongs),
          explanation: `المتجهات متعامدة، المحصلة = √(vx² + vy²) = ${mag} m/s، الزاوية = tan⁻¹(vy/vx) = ${angle}°`,
          steps: [
            `المركبة الشمالية: ${vx} m/s، المركبة الشرقية: ${vy} m/s`,
            `المقدار = √(${vx}² + ${vy}²) = √${vx*vx + vy*vy} = ${mag} m/s`,
            `الزاوية: θ = tan⁻¹(${vy}/${vx}) = ${angle}°`,
            `السرعة الناتجة = ${mag} m/s بزاوية ${angle}° شرق الشمال`,
          ],
        };
      },
    },
    {
      generate: () => {
        const v = randInt(100, 300);
        const angle = pick([30, 37, 45, 53, 60]);
        const rad = angle * Math.PI / 180;
        const vx = round(v * Math.cos(rad), 1);
        const vy = round(v * Math.sin(rad), 1);
        const correct = `الأفقية = ${vx} m/s، الرأسية = ${vy} m/s`;
        const wrongs = [`الأفقية = ${vy} m/s، الرأسية = ${vx} m/s`, `الأفقية = ${v} m/s، الرأسية = ${v} m/s`, `الأفقية = ${round(vx/2,1)} m/s، الرأسية = ${round(vy/2,1)} m/s`];
        return {
          question: `طائرة تسير بسرعة ${v} m/s بزاوية ${angle}° فوق الأفق. أوجد المركبتين الأفقية والرأسية.`,
          ...makeNumericChoices(correct, wrongs),
          explanation: `vₓ = v cos θ = ${v} × cos ${angle}° = ${vx} m/s، vᵧ = v sin θ = ${v} × sin ${angle}° = ${vy} m/s`,
          steps: [
            `المركبة الأفقية: vₓ = v cos θ = ${v} × cos ${angle}° = ${vx} m/s`,
            `المركبة الرأسية: vᵧ = v sin θ = ${v} × sin ${angle}° = ${vy} m/s`,
          ],
        };
      },
    },
  ],
  // Lesson 2: Horizontal projectile
  2: [
    {
      generate: () => {
        const { value: g, context } = gravity();
        const v = randInt(10, 30);
        const h = randInt(5, 80);
        const t = round(Math.sqrt(2 * h / g), 2);
        const R = round(v * t, 2);
        const correct = `t = ${t} s، R = ${R} m`;
        const wrongs = [`t = ${round(t*2,2)} s، R = ${round(R*2,2)} m`, `t = ${round(t/2,2)} s، R = ${round(R/2,2)} m`, `t = ${round(t*1.5,2)} s، R = ${round(R*1.5,2)} m`];
        return {
          question: `كرة تُقذف أفقياً بسرعة ${v} m/s من ارتفاع ${h} m ${context}. احسب زمن الوصول للأرض والمدى. ${gravityNote(g, context)}`,
          ...makeNumericChoices(correct, wrongs),
          explanation: `t = √(2h/g) = √(2×${h}/${g}) = ${t} s، R = v×t = ${v}×${t} = ${R} m`,
          steps: [
            `المعطيات: vₓ = ${v} m/s، y = ${h} m، g = ${g} m/s²`,
            `زمن الوصول: t = √(2y/g) = √(2×${h}/${g}) = √${round(2*h/g,3)} = ${t} s`,
            `المدى الأفقي: R = vₓ × t = ${v} × ${t} = ${R} m`,
          ],
        };
      },
    },
    {
      generate: () => {
        const { value: g, context } = gravity();
        const v = randInt(10, 25);
        const h = randInt(20, 80);
        const t = round(Math.sqrt(2 * h / g), 2);
        const vy = round(g * t, 1);
        const vres = round(Math.sqrt(v*v + vy*vy), 2);
        const correct = `${vres} m/s`;
        const wrongs = generateWrongNumeric(vres, 'm/s');
        return {
          question: `قذيفة تُقذف أفقياً بسرعة ${v} m/s من ارتفاع ${h} m ${context}. أوجد السرعة المحصلة عند الارتطام. ${gravityNote(g, context)}`,
          ...makeNumericChoices(correct, wrongs),
          explanation: `vₓ = ${v} m/s (ثابتة)، vᵧ = g×t = ${vy} m/s، v = √(vₓ² + vᵧ²) = ${vres} m/s`,
          steps: [
            `الزمن: t = √(2×${h}/${g}) = ${t} s`,
            `المركبة الأفقية ثابتة: vₓ = ${v} m/s`,
            `المركبة الرأسية: vᵧ = g×t = ${g}×${t} = ${vy} m/s`,
            `السرعة المحصلة: v = √(${v}² + ${vy}²) = √${round(v*v + vy*vy, 2)} = ${vres} m/s`,
          ],
        };
      },
    },
  ],
  // Lesson 3: Angular projectile
  3: [
    {
      generate: () => {
        const { value: g, context } = gravity();
        const v0 = randInt(20, 60);
        const angle = pick([30, 37, 45, 53, 60]);
        const rad = angle * Math.PI / 180;
        const sinT = round(Math.sin(rad), 3);
        const H = round(v0 * v0 * sinT * sinT / (2 * g), 2);
        const correct = `${H} m`;
        const wrongs = generateWrongNumeric(H, 'm');
        return {
          question: `قذيفة تُقذف بسرعة ${v0} m/s بزاوية ${angle}° ${context}. احسب أقصى ارتفاع. ${gravityNote(g, context)}`,
          ...makeNumericChoices(correct, wrongs),
          explanation: `H = v₀²sin²θ / 2g = ${v0}²×${sinT}² / ${(2 * g).toFixed(1)} = ${H} m`,
          steps: [
            `المعطيات: v₀ = ${v0} m/s، θ = ${angle}°، g = ${g} m/s²`,
            `sin ${angle}° = ${sinT}`,
            `H = (v₀² sin²θ) / (2g) = (${v0}² × ${sinT}²) / (2×${g})`,
            `H = ${round(v0 * v0 * sinT * sinT, 2)} / ${2 * g} = ${H} m`,
          ],
        };
      },
    },
    {
      generate: () => {
        const { value: g, context } = gravity();
        const v0 = randInt(20, 60);
        const angle = pick([30, 37, 45, 53, 60]);
        const rad = angle * Math.PI / 180;
        const sin2T = round(Math.sin(2 * rad), 3);
        const R = round(v0 * v0 * sin2T / g, 2);
        const correct = `${R} m`;
        const wrongs = generateWrongNumeric(R, 'm');
        return {
          question: `قذيفة تُقذف بسرعة ${v0} m/s بزاوية ${angle}° ${context}. احسب المدى الأفقي. ${gravityNote(g, context)}`,
          ...makeNumericChoices(correct, wrongs),
          explanation: `R = v₀²sin2θ / g = ${v0}²×${sin2T} / ${g} = ${R} m`,
          steps: [
            `المعطيات: v₀ = ${v0} m/s، θ = ${angle}°، g = ${g} m/s²`,
            `sin(2×${angle}°) = sin ${2*angle}° = ${sin2T}`,
            `R = (v₀² sin 2θ) / g = (${v0}² × ${sin2T}) / ${g}`,
            `R = ${round(v0 * v0 * sin2T, 2)} / ${g} = ${R} m`,
          ],
        };
      },
    },
    {
      generate: () => {
        const { value: g, context } = gravity();
        const v0 = randInt(20, 60);
        const angle = pick([30, 37, 45, 53, 60]);
        const rad = angle * Math.PI / 180;
        const sinT = round(Math.sin(rad), 3);
        const T = round(2 * v0 * sinT / g, 2);
        const correct = `${T} s`;
        const wrongs = generateWrongNumeric(T, 's');
        return {
          question: `قذيفة تُقذف بسرعة ${v0} m/s بزاوية ${angle}° ${context}. احسب زمن الطيران. ${gravityNote(g, context)}`,
          ...makeNumericChoices(correct, wrongs),
          explanation: `T = 2v₀sinθ / g = 2×${v0}×${sinT} / ${g} = ${T} s`,
          steps: [
            `المعطيات: v₀ = ${v0} m/s، θ = ${angle}°، g = ${g} m/s²`,
            `sin ${angle}° = ${sinT}`,
            `T = (2 × v₀ × sin θ) / g = (2 × ${v0} × ${sinT}) / ${g}`,
            `T = ${round(2 * v0 * sinT, 3)} / ${g} = ${T} s`,
          ],
        };
      },
    },
  ],
  // Lesson 4: Torque
  4: [
    {
      generate: () => {
        const F = randInt(20, 100);
        const d = randFloat(0.1, 0.5, 2);
        const tau = round(F * d, 2);
        const correct = `${tau} N·m`;
        const wrongs = generateWrongNumeric(tau, 'N·m');
        return {
          question: `مفتاح طوله ${d} m تؤثر عليه قوة ${F} N عمودية عليه. احسب عزم القوة.`,
          ...makeNumericChoices(correct, wrongs),
          explanation: `τ = F × d = ${F} × ${d} = ${tau} N·m`,
          steps: [`القوة عمودية على الذراع: τ = F × d = ${F} × ${d} = ${tau} N·m`],
        };
      },
    },
    {
      generate: () => {
        const F = randInt(20, 80);
        const r = randFloat(0.2, 0.8, 2);
        const angle = pick([30, 45, 60]);
        const rad = angle * Math.PI / 180;
        const sinT = round(Math.sin(rad), 3);
        const tau = round(F * r * sinT, 2);
        const correct = `${tau} N·m`;
        const wrongs = generateWrongNumeric(tau, 'N·m');
        return {
          question: `قوة ${F} N تؤثر على ذراع طوله ${r} m بزاوية ${angle}° مع الذراع. احسب عزم القوة.`,
          ...makeNumericChoices(correct, wrongs),
          explanation: `τ = F × r × sin θ = ${F} × ${r} × sin ${angle}° = ${tau} N·m`,
          steps: [
            `τ = F × r × sin θ`,
            `sin ${angle}° = ${sinT}`,
            `τ = ${F} × ${r} × ${sinT} = ${tau} N·m`,
          ],
        };
      },
    },
  ],
  // Lesson 5: Equilibrium
  5: [
    {
      generate: () => {
        const w = randInt(30, 100);
        const L = randFloat(2, 5, 1);
        const d = randFloat(0.5, 2, 1);
        const T = round((w * d) / L, 2);
        const correct = `${T} N`;
        const wrongs = generateWrongNumeric(T, 'N');
        return {
          question: `قضيب وزنه مهمل طوله ${L} m، مثبت بمفصلة ومدعوم بخيط رأسي عند الطرف الآخر. جسم وزنه ${w} N موضوع على بعد ${d} m من المفصلة. احسب شد الخيط.`,
          ...makeNumericChoices(correct, wrongs),
          explanation: `اتزان دوراني حول المفصلة: T × ${L} = ${w} × ${d} → T = ${T} N`,
          steps: [
            `اتزان دوراني حول المفصلة:`,
            `T × L = w × d`,
            `T × ${L} = ${w} × ${d}`,
            `T = ${w * d} / ${L} = ${T} N`,
          ],
        };
      },
    },
  ],
  // Lesson 6: Power & Efficiency
  6: [
    {
      generate: () => {
        const F = randInt(500, 5000);
        const d = randInt(5, 20);
        const t = randInt(2, 10);
        const P = round(F * d / t, 1);
        const correct = `${P} W`;
        const wrongs = generateWrongNumeric(P, 'W');
        return {
          question: `محرك يرفع حملاً وزنه ${F} N إلى ارتفاع ${d} m في ${t} s. احسب القدرة الناتجة.`,
          ...makeNumericChoices(correct, wrongs),
          explanation: `W = F×d = ${F}×${d} = ${F*d} J، P = W/t = ${F*d}/${t} = ${P} W`,
          steps: [
            `الشغل: W = F × d = ${F} × ${d} = ${F*d} J`,
            `القدرة: P = W / t = ${F*d} / ${t} = ${P} W`,
          ],
        };
      },
    },
    {
      generate: () => {
        const F = randInt(500, 3000);
        const v = randInt(10, 30);
        const P = F * v;
        const correct = `${P} W`;
        const wrongs = generateWrongNumeric(P, 'W');
        return {
          question: `سيارة تتحرك بسرعة ثابتة ${v} m/s وقوة المحرك ${F} N. احسب القدرة.`,
          ...makeNumericChoices(correct, wrongs),
          explanation: `P = F × v = ${F} × ${v} = ${P} W`,
          steps: [`P = F × v = ${F} × ${v} = ${P} W`],
        };
      },
    },
    {
      generate: () => {
        const Pin = randInt(2000, 10000);
        const eff = pick([60, 70, 75, 80, 85, 90]);
        const Pout = round(Pin * eff / 100, 1);
        const correct = `${Pout} W`;
        const wrongs = generateWrongNumeric(Pout, 'W');
        return {
          question: `محرك قدرة داخله ${Pin} W وكفاءته ${eff}%. احسب القدرة الناتجة.`,
          ...makeNumericChoices(correct, wrongs),
          explanation: `P_out = η × P_in = ${eff}% × ${Pin} = ${Pout} W`,
          steps: [
            `η = ${eff}% = ${eff/100}`,
            `P_out = η × P_in = ${eff/100} × ${Pin} = ${Pout} W`,
          ],
        };
      },
    },
  ],
  // Lesson 7: Momentum & Impulse
  7: [
    {
      generate: () => {
        const m = randFloat(0.1, 5, 2);
        const v = randInt(5, 20);
        const p = round(m * v, 2);
        const correct = `${p} kg·m/s`;
        const wrongs = generateWrongNumeric(p, 'kg·m/s');
        return {
          question: `جسم كتلته ${m} kg يتحرك بسرعة ${v} m/s. احسب كمية التحرك.`,
          ...makeNumericChoices(correct, wrongs),
          explanation: `p = m × v = ${m} × ${v} = ${p} kg·m/s`,
          steps: [`p = m × v = ${m} × ${v} = ${p} kg·m/s`],
        };
      },
    },
    {
      generate: () => {
        const m = randFloat(0.1, 2, 2);
        const v1 = randInt(5, 15);
        const v2 = randInt(3, 10);
        const dt = randFloat(0.01, 0.05, 3);
        const dp = round(m * (v1 + v2), 2);
        const F = round(dp / dt, 1);
        const correct = `${F} N`;
        const wrongs = generateWrongNumeric(F, 'N');
        return {
          question: `كرة كتلتها ${m} kg تتحرك بسرعة ${v1} m/s ارتطمت بحائط وارتدت بسرعة ${v2} m/s. زمن الاصطدام ${dt} s. احسب قوة الاصطدام.`,
          ...makeNumericChoices(correct, wrongs),
          explanation: `Δp = m(v₂-v₁) = ${m}×(-${v2}-${v1}) = -${dp}، F = Δp/Δt = ${F} N`,
          steps: [
            `p₁ = m×v₁ = ${m}×${v1} = ${round(m*v1,2)} kg·m/s (موجب)`,
            `p₂ = m×(-v₂) = ${m}×(-${v2}) = ${round(-m*v2,2)} kg·m/s (سالب)`,
            `Δp = p₂ - p₁ = ${round(-m*v2,2)} - ${round(m*v1,2)} = -${dp} kg·m/s`,
            `F = Δp/Δt = -${dp}/${dt} = -${F} N → مقدارها ${F} N`,
          ],
        };
      },
    },
  ],
  // Lesson 8: Conservation of momentum
  8: [
    {
      generate: () => {
        const m1 = randInt(1, 5);
        const m2 = randInt(1, 5);
        const v1 = randInt(2, 10);
        const v = round((m1 * v1) / (m1 + m2), 2);
        const correct = `${v} m/s`;
        const wrongs = generateWrongNumeric(v, 'm/s');
        return {
          question: `عربة كتلتها ${m1} kg تتحرك بسرعة ${v1} m/s تلتصق بعربة كتلتها ${m2} kg ساكنة. احسب السرعة المشتركة.`,
          ...makeNumericChoices(correct, wrongs),
          explanation: `m₁v₁ = (m₁+m₂)v → ${m1}×${v1} = ${m1+m2}×v → v = ${v} m/s`,
          steps: [
            `حفظ الزخم: m₁v₁ + m₂v₂ = (m₁+m₂)v`,
            `${m1}×${v1} + ${m2}×0 = (${m1}+${m2})×v`,
            `${m1*v1} = ${m1+m2}×v`,
            `v = ${m1*v1}/${m1+m2} = ${v} m/s`,
          ],
        };
      },
    },
  ],
  // Lesson 9: Momentum & Mechanical Energy
  9: [
    {
      generate: () => {
        const m1 = randInt(2, 6);
        const m2 = randInt(1, 4);
        const v1 = randInt(4, 10);
        const v = round((m1 * v1) / (m1 + m2), 2);
        const KEbefore = round(0.5 * m1 * v1 * v1, 2);
        const KEafter = round(0.5 * (m1 + m2) * v * v, 2);
        const loss = round(KEbefore - KEafter, 2);
        const correct = `v = ${v} m/s، ΔKE = ${loss} J`;
        const wrongs = [`v = ${round(v*1.5,2)} m/s، ΔKE = ${round(loss*2,2)} J`, `v = ${round(v*0.7,2)} m/s، ΔKE = ${round(loss*0.5,2)} J`, `v = ${v1} m/s، ΔKE = 0 J`];
        return {
          question: `عربة كتلتها ${m1} kg بسرعة ${v1} m/s تلتصق بعربة كتلتها ${m2} kg ساكنة. احسب السرعة المشتركة وفقد الطاقة.`,
          ...makeNumericChoices(correct, wrongs),
          explanation: `v = ${m1*v1}/${m1+m2} = ${v} m/s، ΔKE = ${KEbefore} - ${KEafter} = ${loss} J`,
          steps: [
            `حفظ الزخم: v = ${m1}×${v1}/(${m1}+${m2}) = ${v} m/s`,
            `KE قبل = ½×${m1}×${v1}² = ${KEbefore} J`,
            `KE بعد = ½×${m1+m2}×${v}² = ${KEafter} J`,
            `فقد الطاقة = ${KEbefore} - ${KEafter} = ${loss} J`,
          ],
        };
      },
    },
  ],
  // Lesson 10: Uniform circular motion
  10: [
    {
      generate: () => {
        const m = randInt(500, 2000);
        const r = randInt(20, 80);
        const v = randInt(10, 30);
        const F = round(m * v * v / r, 0);
        const correct = `${F} N`;
        const wrongs = generateWrongNumeric(F, 'N');
        return {
          question: `سيارة كتلتها ${m} kg تتحرك في منحنى نصف قطره ${r} m بسرعة ${v} m/s. احسب القوة المركزية.`,
          ...makeNumericChoices(correct, wrongs),
          explanation: `F = mv²/r = ${m}×${v}²/${r} = ${F} N`,
          steps: [
            `F = mv²/r = ${m} × ${v}² / ${r}`,
            `F = ${m * v * v} / ${r} = ${F} N`,
          ],
        };
      },
    },
    {
      generate: () => {
        const r = randInt(20, 100);
        const v = randInt(10, 30);
        const a = round(v * v / r, 2);
        const correct = `${a} m/s²`;
        const wrongs = generateWrongNumeric(a, 'm/s²');
        return {
          question: `جسم يتحرك في مسار دائري نصف قطره ${r} m بسرعة ${v} m/s. احسب التسارع المركزي.`,
          ...makeNumericChoices(correct, wrongs),
          explanation: `a = v²/r = ${v}²/${r} = ${a} m/s²`,
          steps: [`a = v²/r = ${v}²/${r} = ${a} m/s²`],
        };
      },
    },
  ],
  // Lesson 11: Vertical & horizontal circular motion
  11: [
    {
      generate: () => {
        const { value: g, context } = gravity();
        const m = randFloat(0.2, 2, 2);
        const r = randFloat(0.5, 2, 1);
        const vMin = round(Math.sqrt(g * r), 2);
        const v = round(vMin + randFloat(0.5, 4, 1), 1);
        const Fc = round(m * v * v / r, 2);
        const mg = round(m * g, 2);
        const Ftop = round(Fc - mg, 2);
        const correct = `${Ftop} N`;
        const wrongs = generateWrongNumeric(Ftop, 'N');
        return {
          question: `كرة كتلتها ${m} kg مربوطة بخيط طول ${r} m تدور في مستوى رأسي ${context}. عند أعلى نقطة سرعتها ${v} m/s. احسب شد الخيط. ${gravityNote(g, context)}`,
          ...makeNumericChoices(correct, wrongs),
          explanation: `F = mv²/r - mg = ${Fc} - ${mg} = ${Ftop} N`,
          steps: [
            `المعطيات: m = ${m} kg، r = ${r} m، v = ${v} m/s، g = ${g} m/s²`,
            `القوة المركزية: mv²/r = ${m}×${v}²/${r} = ${Fc} N`,
            `الوزن: mg = ${m}×${g} = ${mg} N`,
            `شد الخيط = mv²/r - mg = ${Fc} - ${mg} = ${Ftop} N`,
          ],
        };
      },
    },
    {
      generate: () => {
        const { value: g, context } = gravity();
        const r = randFloat(0.5, 3, 1);
        const vmin = round(Math.sqrt(g * r), 2);
        const correct = `${vmin} m/s`;
        const wrongs = generateWrongNumeric(vmin, 'm/s');
        return {
          question: `احسب أقل سرعة لجسم يدور في مسار دائري رأسي نصف قطره ${r} m ${context} كي يظل الخيط مشدوداً في الأعلى. ${gravityNote(g, context)}`,
          ...makeNumericChoices(correct, wrongs),
          explanation: `v_min = √(gr) = √(${g}×${r}) = ${vmin} m/s`,
          steps: [
            `الشرط: شد الخيط ≥ 0 → mv²/r ≥ mg`,
            `v_min = √(gr) = √(${g} × ${r}) = √${round(g * r, 3)} = ${vmin} m/s`,
          ],
        };
      },
    },
  ],
  // Lesson 12: Kepler & Gravitation
  12: [
    {
      generate: () => {
        const r = randFloat(6, 8, 1);
        const rexp = r * 1e6;
        const M = 6e24;
        const G = 6.67e-11;
        const v = round(Math.sqrt(G * M / rexp), 0);
        const correct = `${v} m/s`;
        const wrongs = generateWrongNumeric(v, 'm/s');
        return {
          question: `قمر صناعي يدور حول الأرض على بعد ${r}×10⁶ m من مركزها. كتلة الأرض 6×10²⁴ kg. احسب سرعته. (G = 6.67×10⁻¹¹)`,
          ...makeNumericChoices(correct, wrongs),
          explanation: `v = √(GM/r) = √(6.67×10⁻¹¹×6×10²⁴/${r}×10⁶) = ${v} m/s`,
          steps: [
            `v = √(GM/r)`,
            `GM/r = 6.67×10⁻¹¹ × 6×10²⁴ / ${r}×10⁶ = ${round(G*M/rexp/1e7,1)}×10⁷`,
            `v = √(${round(G*M/rexp/1e7,1)}×10⁷) ≈ ${v} m/s`,
          ],
        };
      },
    },
    {
      generate: () => {
        const F = randInt(100, 500);
        const d = randFloat(0.2, 2, 1);
        const tau = round(F * d, 1);
        const correct = `${tau} N·m`;
        const wrongs = generateWrongNumeric(tau, 'N·m');
        return {
          question: `في توازن دوراني: قوة ${F} N تؤثر على ذراع ${d} m. ما العزم المطلوب معادلته؟`,
          ...makeNumericChoices(correct, wrongs),
          explanation: `τ = F × d = ${F} × ${d} = ${tau} N·m`,
          steps: [`τ = F × d = ${F} × ${d} = ${tau} N·m`],
        };
      },
    },
  ],
  // Lesson 13: SHM
  13: [
    {
      generate: () => {
        const A = randFloat(0.02, 0.1, 3);
        const omega = randInt(5, 20);
        const vmax = round(A * omega, 3);
        const correct = `${vmax} m/s`;
        const wrongs = generateWrongNumeric(vmax, 'm/s');
        return {
          question: `جسم يهتز بسعة ${A} m وω = ${omega} rad/s. احسب السرعة القصوى.`,
          ...makeNumericChoices(correct, wrongs),
          explanation: `v_max = Aω = ${A} × ${omega} = ${vmax} m/s`,
          steps: [`v_max = Aω = ${A} × ${omega} = ${vmax} m/s`],
        };
      },
    },
    {
      generate: () => {
        const A = randFloat(0.02, 0.1, 3);
        const omega = randInt(5, 20);
        const amax = round(A * omega * omega, 3);
        const correct = `${amax} m/s²`;
        const wrongs = generateWrongNumeric(amax, 'm/s²');
        return {
          question: `جسم يهتز بسعة ${A} m وω = ${omega} rad/s. احسب التسارع الأقصى.`,
          ...makeNumericChoices(correct, wrongs),
          explanation: `a_max = Aω² = ${A} × ${omega}² = ${amax} m/s²`,
          steps: [`a_max = Aω² = ${A} × ${omega}² = ${A * omega * omega} = ${amax} m/s²`],
        };
      },
    },
  ],
  // Lesson 14: Spring pendulum
  14: [
    {
      generate: () => {
        const m = randFloat(0.1, 1, 2);
        const k = randInt(50, 200);
        const T = round(2 * Math.PI * Math.sqrt(m / k), 3);
        const correct = `${T} s`;
        const wrongs = generateWrongNumeric(T, 's');
        return {
          question: `جسم كتلته ${m} kg على نابض k = ${k} N/m. احسب الزمن الدوري.`,
          ...makeNumericChoices(correct, wrongs),
          explanation: `T = 2π√(m/k) = 2π√(${m}/${k}) = ${T} s`,
          steps: [
            `T = 2π√(m/k) = 2π√(${m}/${k})`,
            `√(${m}/${k}) = √${round(m/k, 5)} = ${round(Math.sqrt(m/k), 4)}`,
            `T = 2π × ${round(Math.sqrt(m/k), 4)} = ${T} s`,
          ],
        };
      },
    },
  ],
  // Lesson 15: Simple pendulum
  15: [
    {
      generate: () => {
        const L = randFloat(0.2, 2, 2);
        const { value: g, context } = rand() > 0.25 ? gravity() : GRAVITY_MOON;
        const T = round(2 * Math.PI * Math.sqrt(L / g), 3);
        const correct = `${T} s`;
        const wrongs = generateWrongNumeric(T, 's');
        return {
          question: `بندول بسيط طوله ${L} m ${context}. احسب زمنه الدوري. ${gravityNote(g, context)}`,
          ...makeNumericChoices(correct, wrongs),
          explanation: `T = 2π√(L/g) = 2π√(${L}/${g}) = ${T} s`,
          steps: [
            `المعطيات: L = ${L} m، g = ${g} m/s² (${context})`,
            `T = 2π√(L/g) = 2π√(${L}/${g})`,
            `√(${L}/${g}) = √${round(L/g, 4)} = ${round(Math.sqrt(L/g), 4)}`,
            `T = 2π × ${round(Math.sqrt(L/g), 4)} = ${T} s`,
            `ملاحظة: الزمن الدوري للبندول يعتمد على g، بعكس البندول الزنبركي.`,
          ],
        };
      },
    },
  ],
  // Lesson 16: Sine waves
  16: [
    {
      generate: () => {
        const f = randInt(50, 500);
        const v = randInt(300, 400);
        const lambda = round(v / f, 3);
        const correct = `${lambda} m`;
        const wrongs = generateWrongNumeric(lambda, 'm');
        return {
          question: `موجة ترددها ${f} Hz وسرعتها ${v} m/s. احسب الطول الموجي.`,
          ...makeNumericChoices(correct, wrongs),
          explanation: `λ = v/f = ${v}/${f} = ${lambda} m`,
          steps: [`λ = v/f = ${v}/${f} = ${lambda} m`],
        };
      },
    },
    {
      generate: () => {
        const lambda = randFloat(0.1, 2, 2);
        const f = randInt(100, 500);
        const v = round(lambda * f, 1);
        const correct = `${v} m/s`;
        const wrongs = generateWrongNumeric(v, 'm/s');
        return {
          question: `موجة طولها الموجي ${lambda} m وترددها ${f} Hz. احسب سرعة الموجة.`,
          ...makeNumericChoices(correct, wrongs),
          explanation: `v = λ × f = ${lambda} × ${f} = ${v} m/s`,
          steps: [`v = λ × f = ${lambda} × ${f} = ${v} m/s`],
        };
      },
    },
  ],
  // Lesson 17: Interference & standing waves
  17: [
    {
      generate: () => {
        const n = randInt(1, 5);
        const lambda = randFloat(0.1, 0.5, 2);
        const dx = round(n * lambda, 2);
        const correct = `${dx} m`;
        const wrongs = generateWrongNumeric(dx, 'm');
        return {
          question: `في تداخل بناء، إذا كان n = ${n} والطول الموجي ${lambda} m، احسب فرق المسار.`,
          ...makeNumericChoices(correct, wrongs),
          explanation: `Δx = nλ = ${n} × ${lambda} = ${dx} m`,
          steps: [`تداخل بناء: Δx = nλ = ${n} × ${lambda} = ${dx} m`],
        };
      },
    },
    {
      generate: () => {
        const L = randFloat(0.1, 0.5, 2);
        const v = 340;
        const f = round(v / (4 * L), 0);
        const correct = `${f} Hz`;
        const wrongs = generateWrongNumeric(f, 'Hz');
        return {
          question: `أنبوب مغلق طوله ${L} m، سرعة الصوت 340 m/s. احسب التردد الأساسي.`,
          ...makeNumericChoices(correct, wrongs),
          explanation: `f = v/4L = 340/(4×${L}) = ${f} Hz`,
          steps: [
            `أنبوب مغلق: L = λ/4 → λ = 4L = ${4*L}`,
            `f = v/λ = 340/${round(4*L,2)} = ${f} Hz`,
          ],
        };
      },
    },
  ],
  // Lesson 18: Wave refraction
  18: [
    {
      generate: () => {
        const n = pick([1.33, 1.5, 2.42, 1.6]);
        const v = round(3e8 / n / 1e8, 2);
        const correct = `${v}×10⁸ m/s`;
        const wrongs = [`${round(v*1.5,2)}×10⁸ m/s`, `${round(v*0.7,2)}×10⁸ m/s`, `${round(v*2,2)}×10⁸ m/s`];
        return {
          question: `إذا كان معامل انكسار وسط ${n}، احسب سرعة الضوء فيه. (سرعة الضوء في الفراغ = 3×10⁸ m/s)`,
          ...makeNumericChoices(correct, wrongs),
          explanation: `v = c/n = 3×10⁸/${n} = ${v}×10⁸ m/s`,
          steps: [`v = c/n = 3×10⁸ / ${n} = ${v}×10⁸ m/s`],
        };
      },
    },
  ],
  // Lesson 19: Sound wave interference
  19: [
    {
      generate: () => {
        const v = 340;
        const f = randInt(200, 1000);
        const lambda = round(v / f, 3);
        const correct = `${lambda} m`;
        const wrongs = generateWrongNumeric(lambda, 'm');
        return {
          question: `موجة صوتية ترددها ${f} Hz وسرعتها ${v} m/s. احسب الطول الموجي.`,
          ...makeNumericChoices(correct, wrongs),
          explanation: `λ = v/f = ${v}/${f} = ${lambda} m`,
          steps: [`λ = v/f = ${v}/${f} = ${lambda} m`],
        };
      },
    },
  ],
  // Lesson 20: Doppler effect
  20: [
    {
      generate: () => {
        const f0 = randInt(300, 800);
        const v = 340;
        const vs = randInt(10, 50);
        const f = round(f0 * v / (v - vs), 0);
        const correct = `${f} Hz`;
        const wrongs = generateWrongNumeric(f, 'Hz');
        return {
          question: `مصدر صوت تردده ${f0} Hz يقترب من مراقب ساكن بسرعة ${vs} m/s. سرعة الصوت 340 m/s. احسب التردد المسموع.`,
          ...makeNumericChoices(correct, wrongs),
          explanation: `f' = f₀ × v/(v-vs) = ${f0} × 340/(340-${vs}) = ${f} Hz`,
          steps: [
            `f' = f₀ × v / (v - vs)`,
            `f' = ${f0} × 340 / (340 - ${vs})`,
            `f' = ${f0} × 340 / ${340 - vs} = ${f} Hz`,
          ],
        };
      },
    },
  ],
  // Lesson 21: Light refraction & TIR
  21: [
    {
      generate: () => {
        const n1 = 1;
        const n2 = pick([1.33, 1.5, 2.42]);
        const thetaC = round(Math.asin(n1 / n2) * 180 / Math.PI, 1);
        const correct = `${thetaC}°`;
        const wrongs = [`${round(thetaC * 1.3, 1)}°`, `${round(thetaC * 0.7, 1)}°`, `45°`];
        return {
          question: `احسب الزاوية الحرجة للانعكاس الكلي الداخلي عند الانتقال من وسط معامل انكساره ${n2} إلى الهواء (n = 1).`,
          ...makeNumericChoices(correct, wrongs),
          explanation: `sin θc = n₁/n₂ = 1/${n2} → θc = sin⁻¹(${round(1/n2, 3)}) = ${thetaC}°`,
          steps: [
            `sin θc = n₁/n₂ = 1/${n2} = ${round(1/n2, 3)}`,
            `θc = sin⁻¹(${round(1/n2, 3)}) = ${thetaC}°`,
          ],
        };
      },
    },
  ],
  // Lesson 22: Lenses & images
  22: [
    {
      generate: () => {
        const f = randInt(5, 30);
        const dobj = randInt(10, 60);
        const di = round(1 / (1 / f - 1 / dobj), 1);
        const correct = `${di} cm`;
        const wrongs = generateWrongNumeric(di, 'cm');
        return {
          question: `عدسة بعد بؤري ${f} cm، وضع جسم على بعد ${dobj} cm منها. احسب بعد الصورة.`,
          ...makeNumericChoices(correct, wrongs),
          explanation: `1/f = 1/do + 1/di → 1/di = 1/${f} - 1/${dobj} → di = ${di} cm`,
          steps: [
            `1/f = 1/do + 1/di`,
            `1/di = 1/${f} - 1/${dobj} = ${round(1/f, 4)} - ${round(1/dobj, 4)} = ${round(1/f - 1/dobj, 5)}`,
            `di = 1/${round(1/f - 1/dobj, 5)} = ${di} cm`,
          ],
        };
      },
    },
  ],
  // Lesson 23: Young's double slit
  23: [
    {
      generate: () => {
        const lambda = randFloat(400, 700, 0);
        const d = randFloat(0.01, 0.05, 3);
        const L = randFloat(1, 3, 1);
        const y = round(lambda * 1e-9 * L / d * 1000, 2);
        const correct = `${y} mm`;
        const wrongs = generateWrongNumeric(y, 'mm');
        return {
          question: `في تجربة يونج، الطول الموجي ${lambda} nm، المسافة بين الشقين ${d} mm، المسافة للشاشة ${L} m. احسب موضع هدبته المركزية الأولى.`,
          ...makeNumericChoices(correct, wrongs),
          explanation: `y = λL/d = ${lambda}×10⁻⁹×${L}/(${d}×10⁻³) = ${y} mm`,
          steps: [
            `y = λL/d`,
            `λ = ${lambda} nm = ${lambda}×10⁻⁹ m، d = ${d} mm = ${d}×10⁻³ m`,
            `y = ${lambda}×10⁻⁹ × ${L} / (${d}×10⁻³) = ${round(lambda*1e-9*L/d, 6)} m = ${y} mm`,
          ],
        };
      },
    },
  ],
};

/**
 * Lessons 24-45 (الكهرباء والمغناطيسية والفيزياء الحديثة) keep their templates in their own
 * module so this file stays readable; the generator reads one merged map.
 */
const lessonTemplates: Record<number, ProblemTemplate[]> = {
  ...problemTemplates,
  ...electricityProblemTemplates,
  ...modernProblemTemplates,
};

/* ============================================================
   WORKED EXAMPLE QUESTIONS (from lesson.questions)
   ============================================================ */

function generateWorkedExampleQuestions(lesson: Lesson, difficulty: Difficulty, count: number): QuizQuestion[] {
  const questions: QuizQuestion[] = [];
  const pool = [...lesson.questions];

  for (let i = 0; i < count && pool.length > 0; i++) {
    seedDraw(lesson.id, difficulty, 500 + i);
    const source = pool[i % pool.length];
    const correctAnswer = source.answer;

    const wrongAnswers = [
      'نتيجة مختلفة بسبب خطأ في تحويل الوحدات',
      'تم استخدام قانون غير مناسب للظاهرة',
      'لم يُراعَ اتجاه المتجه أو إشارة الكمية',
    ];

    const { choices, correctIndex } = makeNumericChoices(correctAnswer, wrongAnswers);

    const questionText = difficulty === 'easy'
      ? source.q
      : difficulty === 'medium'
        ? `(تطبيقي) ${source.q}`
        : `(متقدم — تريك امتحاني) ${source.q}`;

    questions.push({
      id: makeQuestionId(lesson.id, difficulty, 100 + i + 1),
      topic: lesson.title,
      question: questionText,
      choices,
      correctIndex,
      explanation: correctAnswer,
      steps: source.steps,
    });
  }

  return questions;
}

/* ============================================================
   MAIN GENERATOR: exactly QUESTIONS_PER_MODEL questions per model
   ============================================================ */

export const QUESTIONS_PER_MODEL = 45;

/**
 * A question before finalizeQuestion() builds its option list: it may carry the
 * correct answer and its distractors separately instead of a pre-shuffled array.
 */
type DraftQuestion = QuizQuestion & {
  correctChoice?: string;
  wrongChoices?: string[];
};

/** Filler built straight from the lesson content when the pools run dry. */
function buildFillerQuestion(lesson: Lesson, difficulty: Difficulty, index: number): DraftQuestion {
  const useLaw = index % 2 === 0 && lesson.laws.length > 0;

  if (useLaw) {
    const law = lesson.laws[index % lesson.laws.length];
    return {
      id: makeQuestionId(lesson.id, difficulty, index + 1),
      topic: lesson.title,
      question: `أي العبارات الآتية صحيحة عن قانون «${law.name}» في درس «${lesson.title}»؟`,
      choices: [],
      correctIndex: 0,
      explanation: `${law.name}: ${law.formula}. ${law.explanation}`,
      steps: [
        `المطلوب: العبارة الصحيحة عن «${law.name}».`,
        `القانون: ${law.formula}، الوحدة: ${law.units}.`,
        `المعنى الفيزيائي: ${law.explanation}`,
      ],
      correctChoice: `${law.formula} — ${law.explanation}`,
      wrongChoices: lesson.laws
        .filter((l) => l.name !== law.name)
        .map((l) => `${l.formula} — ${l.explanation}`),
    };
  }

  const concept = lesson.concepts[index % Math.max(1, lesson.concepts.length)];
  return {
    id: makeQuestionId(lesson.id, difficulty, index + 1),
    topic: lesson.title,
    question: `أي العبارات الآتية تصف «${concept.title}» وصفاً صحيحاً؟`,
    choices: [],
    correctIndex: 0,
    explanation: `${concept.title}: ${concept.detail}`,
    steps: [
      `المفهوم: ${concept.title}`,
      `التعريف الصحيح: ${concept.detail}`,
    ],
    correctChoice: concept.detail,
    wrongChoices: lesson.concepts
      .filter((c) => c.title !== concept.title)
      .map((c) => c.detail),
  };
}

/**
 * Guarantees the five parts every question must carry: question, four distinct
 * choices, a correctIndex inside that range, an explanation and at least one step.
 */
function finalizeQuestion(raw: DraftQuestion, lesson: Lesson, difficulty: Difficulty, index: number): QuizQuestion {
  seedDraw(lesson.id, difficulty, 900 + index);

  const correct =
    raw.correctChoice ?? raw.choices[raw.correctIndex] ?? raw.choices[0] ?? raw.explanation;

  const distractors = raw.wrongChoices ?? raw.choices;
  const { choices, correctIndex } = makeNumericChoices(
    correct,
    (Array.isArray(distractors) ? distractors : []).filter((c) => c && c !== correct),
  );

  const steps = (raw.steps ?? []).filter((s) => s && s.trim().length > 0);
  const explanation = raw.explanation?.trim() || `الإجابة الصحيحة: ${correct}`;

  return {
    id: makeQuestionId(lesson.id, difficulty, index + 1),
    topic: raw.topic || lesson.title,
    question: raw.question,
    choices,
    correctIndex,
    explanation,
    steps: steps.length > 0 ? steps : [explanation, `التحقق: اختر الإجابة التي تطابق ${correct}`],
  };
}

export function generateQuizQuestions(
  lesson: Lesson,
  difficulty: Difficulty,
  targetCount: number = QUESTIONS_PER_MODEL,
): QuizQuestion[] {
  const questions: QuizQuestion[] = [];

  // 1. Conceptual questions (from the lesson's own concepts & laws).
  const conceptualCount = Math.round(targetCount * 0.36);
  questions.push(...generateConceptualQuestions(lesson, difficulty, conceptualCount));

  // 2. Worked examples straight from the textbook questions of the lesson.
  questions.push(...generateWorkedExampleQuestions(lesson, difficulty, Math.round(targetCount * 0.2)));

  // 3. Numeric problems from the lesson templates — the bulk of the paper.
  const templates = lessonTemplates[lesson.id] ?? [];
  for (let i = 0; questions.length < targetCount && templates.length > 0; i++) {
    seedDraw(lesson.id, difficulty, 200 + i);
    const problem = templates[i % templates.length].generate(difficulty);
    questions.push({
      id: makeQuestionId(lesson.id, difficulty, 200 + i + 1),
      topic: lesson.title,
      question: problem.question,
      choices: problem.choices,
      correctIndex: problem.correctIndex,
      explanation: problem.explanation,
      steps: problem.steps,
    });
  }

  // 4. Anything still missing comes from the lesson content, never a stub.
  while (questions.length < targetCount) {
    questions.push(buildFillerQuestion(lesson, difficulty, questions.length));
  }

  // Numbering stays stable (no re-shuffling) so saved results keep pointing at
  // the same question after a reload.
  return questions
    .slice(0, targetCount)
    .map((q, index) => finalizeQuestion(q, lesson, difficulty, index));
}
