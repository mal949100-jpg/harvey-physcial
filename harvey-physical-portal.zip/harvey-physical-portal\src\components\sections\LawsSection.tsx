import { useState, useMemo } from 'react';
import { Scale, Sigma, ChevronDown, BookOpen, ChartNoAxesCombined, Ruler, ShieldCheck } from 'lucide-react';
import { chapterLabel, lessons, chapters, getFormulaBreakdown } from '@/data/lessons';
import { chapterSoft } from '@/lib/chapterTheme';

interface LawsSectionProps {
  searchQuery: string;
}

export default function LawsSection({ searchQuery }: LawsSectionProps) {
  const [selectedChapter, setSelectedChapter] = useState<number>(0);
  const [expandedLaw, setExpandedLaw] = useState<number | null>(null);

  const filtered = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    const allLaws = lessons.flatMap((l) =>
      l.laws.map((law) => ({ ...law, lessonTitle: l.title, chapter: l.chapter }))
    );
    if (!q) return allLaws;
    return allLaws.filter(
      (law) =>
        law.name.toLowerCase().includes(q) ||
        law.formula.toLowerCase().includes(q) ||
        law.explanation.toLowerCase().includes(q) ||
        law.units.toLowerCase().includes(q)
    );
  }, [searchQuery]);

  const chapterLaws = filtered.filter(
    (law) => law.chapter === selectedChapter || selectedChapter === 0
  );

  return (
    <div className="space-y-6">
      <div className="bg-white dark:bg-slate-900 rounded-2xl p-6 shadow-sm border border-slate-100 dark:border-slate-800">
        <div className="flex items-center gap-3 mb-4">
          <div className="w-12 h-12 bg-primary-50 dark:bg-primary-500/15 rounded-xl flex items-center justify-center">
            <Scale className="w-6 h-6 text-primary-600 dark:text-primary-300" />
          </div>
          <div>
            <h2 className="text-xl font-bold text-slate-800 dark:text-slate-100">شرح القوانين والمعادلات</h2>
            <p className="text-sm text-slate-500 dark:text-slate-300">كل قانون، معادلته، وحدته، ومعناه الفيزيائي</p>
          </div>
        </div>

        <div className="flex gap-2 flex-wrap">
          <button
            onClick={() => setSelectedChapter(0)}
            className={`px-4 py-2 rounded-lg text-sm font-semibold transition-all ${
              selectedChapter === 0
                ? 'bg-primary-600 text-white shadow-md'
                : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700'
            }`}
          >
            جميع القوانين
          </button>
          {chapters.map((ch) => (
            <button
              key={ch.id}
              onClick={() => setSelectedChapter(ch.id)}
              className={`px-4 py-2 rounded-lg text-sm font-semibold transition-all text-right ${
                selectedChapter === ch.id
                  ? 'bg-primary-600 text-white shadow-md'
                  : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700'
              }`}
            >
              <span className="block">{ch.title}</span>
              <span className="block text-[11px] font-normal opacity-80">{ch.subtitle}</span>
            </button>
          ))}
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {chapterLaws.map((law, idx) => {
          const isExpanded = expandedLaw === idx;
          const breakdown = getFormulaBreakdown(law, law.lessonTitle);
          return (
          <div
            key={`${law.lessonTitle}-${law.name}-${idx}`}
            className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-100 dark:border-slate-800 shadow-sm p-5 hover:shadow-md transition-all"
          >
            <div className="flex items-start justify-between gap-3 mb-3">
              <div className="flex items-center gap-2">
                <div className="w-9 h-9 bg-gradient-to-br from-primary-500 to-primary-700 rounded-lg flex items-center justify-center">
                  <Sigma className="w-5 h-5 text-white" />
                </div>
                <div>
                  <h3 className="font-bold text-slate-800 dark:text-slate-100 text-sm">{law.name}</h3>
                  <span className={`inline-block mt-1 text-[10px] px-2 py-0.5 rounded-full font-semibold ${chapterSoft[law.chapter]}`}>
                    {chapterLabel(law.chapter)}
                  </span>
                </div>
              </div>
              <span className="text-xs px-2.5 py-1 bg-amber-50 dark:bg-amber-500/15 text-amber-700 dark:text-amber-300 rounded-lg font-semibold whitespace-nowrap">
                {law.units}
              </span>
            </div>

            <div className="bg-gradient-to-l from-primary-50 to-slate-50 rounded-xl p-4 mb-3 border border-primary-100 dark:border-primary-500/30">
              <p className="text-lg font-bold text-primary-700 dark:text-primary-300 text-center" dir="ltr">
                {law.formula}
              </p>
            </div>

            <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed mb-3">{law.explanation}</p>

            <button
              onClick={() => setExpandedLaw(isExpanded ? null : idx)}
              className="w-full flex items-center justify-between gap-2 py-2 text-primary-700 dark:text-primary-300 text-xs font-bold border-t border-slate-100 dark:border-slate-800"
            >
              <span>فتح التحليل الشامل للقانون</span>
              <ChevronDown className={`w-4 h-4 transition-transform ${isExpanded ? 'rotate-180' : ''}`} />
            </button>

            {isExpanded && (
              <div className="mt-3 space-y-4 animate-slide-down">
                <section className="bg-primary-50 dark:bg-primary-500/15 rounded-xl p-4 border border-primary-100 dark:border-primary-500/30">
                  <div className="flex items-center gap-2 mb-2">
                    <BookOpen className="w-4 h-4 text-primary-600 dark:text-primary-300" />
                    <h4 className="text-xs font-bold text-slate-700 dark:text-slate-100">من أين جاء القانون؟ والاستنتاج العلمي</h4>
                  </div>
                  <p className="text-xs text-slate-700 dark:text-slate-100 leading-7">{breakdown.origin}</p>
                </section>

                <section>
                  <div className="flex items-center gap-2 mb-2">
                    <Ruler className="w-4 h-4 text-emerald-600 dark:text-emerald-300" />
                    <h4 className="text-xs font-bold text-slate-700 dark:text-slate-100">المتغيرات والوحدات والمعنى الحدسي</h4>
                  </div>
                  <div className="space-y-2">
                    {breakdown.variables.map((variable) => (
                      <div key={variable.symbol} className="grid grid-cols-[auto_1fr_auto] items-start gap-3 bg-slate-50 dark:bg-slate-800 rounded-lg p-3 border border-slate-100 dark:border-slate-800">
                        <span className="font-bold text-primary-700 dark:text-primary-300" dir="ltr">{variable.symbol}</span>
                        <p className="text-xs text-slate-600 dark:text-slate-300 leading-6">{variable.meaning}</p>
                        <span className="text-[10px] bg-white dark:bg-slate-900 text-slate-500 dark:text-slate-300 rounded px-2 py-1 whitespace-nowrap">{variable.unit}</span>
                      </div>
                    ))}
                  </div>
                </section>

                <section className="bg-blue-50 dark:bg-blue-500/15 rounded-xl p-4 border border-blue-100 dark:border-blue-500/30">
                  <div className="flex items-center gap-2 mb-2">
                    <ChartNoAxesCombined className="w-4 h-4 text-blue-600 dark:text-blue-300" />
                    <h4 className="text-xs font-bold text-slate-700 dark:text-slate-100">العلاقة البيانية والرسم</h4>
                  </div>
                  <p className="text-xs text-slate-700 dark:text-slate-100 leading-7">{breakdown.graph}</p>
                </section>

                <section className="bg-emerald-50 dark:bg-emerald-500/15 rounded-xl p-4 border border-emerald-100 dark:border-emerald-500/30">
                  <div className="flex items-center gap-2 mb-2">
                    <Sigma className="w-4 h-4 text-emerald-600 dark:text-emerald-300" />
                    <h4 className="text-xs font-bold text-slate-700 dark:text-slate-100">النتائج المترتبة على القانون</h4>
                  </div>
                  <ul className="list-disc list-inside space-y-1 text-xs text-slate-700 dark:text-slate-100 leading-7">
                    {breakdown.results.map((result, resultIdx) => <li key={resultIdx}>{result}</li>)}
                  </ul>
                </section>

                <section className="bg-amber-50 dark:bg-amber-500/15 rounded-xl p-4 border border-amber-100 dark:border-amber-500/30">
                  <div className="flex items-center gap-2 mb-2">
                    <ShieldCheck className="w-4 h-4 text-amber-600 dark:text-amber-300" />
                    <h4 className="text-xs font-bold text-slate-700 dark:text-slate-100">شروط التطبيق والحدود</h4>
                  </div>
                  <ul className="list-disc list-inside space-y-1 text-xs text-slate-700 dark:text-slate-100 leading-7">
                    {breakdown.conditions.map((condition, conditionIdx) => <li key={conditionIdx}>{condition}</li>)}
                  </ul>
                </section>
              </div>
            )}

            <div className="text-xs text-slate-400 dark:text-slate-500 pt-2 border-t border-slate-100 dark:border-slate-800">
              من درس: <span className="font-semibold text-slate-500 dark:text-slate-300">{law.lessonTitle}</span>
            </div>
          </div>
          );
        })}
      </div>

      {chapterLaws.length === 0 && (
        <div className="text-center py-12 text-slate-400 dark:text-slate-500">
          <Scale className="w-12 h-12 mx-auto mb-3 opacity-40" />
          <p>لا توجد قوانين مطابقة لبحثك</p>
        </div>
      )}
    </div>
  );
}
