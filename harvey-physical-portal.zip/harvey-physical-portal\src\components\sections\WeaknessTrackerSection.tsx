import { useState, useEffect } from 'react';
import { Target, TrendingDown, AlertCircle, CheckCircle2, RotateCcw, BookOpen } from 'lucide-react';
import { getQuizResults, type StoredQuizResult } from '@/lib/guestStorage';
import { ministryQuizzes as quizzes } from '@/data/studyContent';
import { getExamPlan } from '@/data/examPlans';
import { chapterLabel, lessonByTopic, type ChapterId } from '@/data/lessons';

function attemptTitle(quizId: string): string {
  return (
    quizzes.find((q) => q.id === quizId)?.title ??
    getExamPlan(quizId)?.title ??
    quizId
  );
}

export default function WeaknessTrackerSection() {
  const [results, setResults] = useState<StoredQuizResult[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    setResults(getQuizResults());
    setLoading(false);
  }, []);

  const topicStats: Record<string, { wrong: number; total: number }> = {};
  results.forEach((r) => {
    r.wrong_topics.forEach((topic) => {
      if (!topicStats[topic]) topicStats[topic] = { wrong: 0, total: 0 };
      topicStats[topic].wrong++;
    });
  });

  quizzes.forEach((quiz) => {
    quiz.questions.forEach((q) => {
      if (!topicStats[q.topic]) topicStats[q.topic] = { wrong: 0, total: 0 };
      topicStats[q.topic].total++;
    });
  });

  const sortedTopics = Object.entries(topicStats).sort((a, b) => b[1].wrong - a[1].wrong);
  const totalAttempts = results.length;
  const avgScore =
    results.length > 0
      ? Math.round((results.reduce((sum, r) => sum + r.score / r.total, 0) / results.length) * 100)
      : 0;

  // Wrong topics are lesson titles, so they map back to the exact lesson and chapter
  // the student lost marks in — that is what turns a flat topic list into a study plan.
  interface WeakLesson {
    wrong: number;
    lessonId: number;
    chapter: ChapterId;
    title: string;
  }
  const weakLessons: WeakLesson[] = [];
  sortedTopics.forEach(([topic, stats]) => {
    if (stats.wrong === 0) return;
    const lesson = lessonByTopic(topic);
    if (!lesson) return;
    weakLessons.push({ wrong: stats.wrong, lessonId: lesson.id, chapter: lesson.chapter, title: lesson.title });
  });
  weakLessons.sort((a, b) => b.wrong - a.wrong);

  const chapterRows = ([1, 2, 3, 4] as ChapterId[])
    .map((chapter) => ({ chapter, lessons: weakLessons.filter((entry) => entry.chapter === chapter) }))
    .filter((row) => row.lessons.length > 0)
    .map((row) => ({ ...row, wrong: row.lessons.reduce((sum, entry) => sum + entry.wrong, 0) }))
    .sort((a, b) => b.wrong - a.wrong);

  return (
    <div className="space-y-6">
      <div className="bg-white dark:bg-slate-900 rounded-2xl p-6 shadow-sm border border-slate-100 dark:border-slate-800">
        <div className="flex items-center gap-3 mb-4">
          <div className="w-12 h-12 bg-orange-50 dark:bg-orange-500/15 rounded-xl flex items-center justify-center">
            <Target className="w-6 h-6 text-orange-600 dark:text-orange-300" />
          </div>
          <div>
            <h2 className="text-xl font-bold text-slate-800 dark:text-slate-100">نقاط الضعف</h2>
            <p className="text-sm text-slate-500 dark:text-slate-300">تحليل أدائك وتحديد المواضيع التي تحتاج مراجعة</p>
          </div>
        </div>
      </div>

      {loading ? (
        <div className="text-center py-12 text-slate-400 dark:text-slate-500">
          <Target className="w-12 h-12 mx-auto mb-3 opacity-40 animate-pulse" />
          <p>جاري التحميل...</p>
        </div>
      ) : results.length === 0 ? (
        <div className="bg-white dark:bg-slate-900 rounded-2xl p-12 shadow-sm border border-slate-100 dark:border-slate-800 text-center">
          <div className="w-16 h-16 bg-slate-50 dark:bg-slate-800 rounded-full flex items-center justify-center mx-auto mb-4">
            <RotateCcw className="w-8 h-8 text-slate-400 dark:text-slate-500" />
          </div>
          <h3 className="font-bold text-slate-700 dark:text-slate-100 mb-2">لا توجد بيانات بعد</h3>
          <p className="text-sm text-slate-400 dark:text-slate-500">
            أكمل بعض الكويزات أو الامتحانات الموقّتة أولاً ليتم تحليل أدائك وتحديد نقاط ضعفك
          </p>
        </div>
      ) : (
        <>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div className="bg-white dark:bg-slate-900 rounded-2xl p-5 shadow-sm border border-slate-100 dark:border-slate-800">
              <div className="flex items-center gap-3 mb-2">
                <div className="w-10 h-10 bg-blue-50 dark:bg-blue-500/15 rounded-lg flex items-center justify-center">
                  <RotateCcw className="w-5 h-5 text-blue-600 dark:text-blue-300" />
                </div>
                <p className="text-sm text-slate-500 dark:text-slate-300">المحاولات</p>
              </div>
              <p className="text-3xl font-bold text-slate-800 dark:text-slate-100">{totalAttempts}</p>
            </div>
            <div className="bg-white dark:bg-slate-900 rounded-2xl p-5 shadow-sm border border-slate-100 dark:border-slate-800">
              <div className="flex items-center gap-3 mb-2">
                <div className="w-10 h-10 bg-emerald-50 dark:bg-emerald-500/15 rounded-lg flex items-center justify-center">
                  <CheckCircle2 className="w-5 h-5 text-emerald-600 dark:text-emerald-300" />
                </div>
                <p className="text-sm text-slate-500 dark:text-slate-300">متوسط الدرجات</p>
              </div>
              <p className="text-3xl font-bold text-slate-800 dark:text-slate-100">{avgScore}%</p>
            </div>
            <div className="bg-white dark:bg-slate-900 rounded-2xl p-5 shadow-sm border border-slate-100 dark:border-slate-800">
              <div className="flex items-center gap-3 mb-2">
                <div className="w-10 h-10 bg-error-50 rounded-lg flex items-center justify-center">
                  <TrendingDown className="w-5 h-5 text-error-500" />
                </div>
                <p className="text-sm text-slate-500 dark:text-slate-300">مواضيع تحتاج مراجعة</p>
              </div>
              <p className="text-3xl font-bold text-slate-800 dark:text-slate-100">
                {sortedTopics.filter(([, s]) => s.wrong > 0).length}
              </p>
            </div>
          </div>

          <div className="bg-white dark:bg-slate-900 rounded-2xl shadow-sm border border-slate-100 dark:border-slate-800 overflow-hidden">
            <div className="p-5 border-b border-slate-100 dark:border-slate-800">
              <h3 className="font-bold text-slate-800 dark:text-slate-100 flex items-center gap-2">
                <BookOpen className="w-5 h-5 text-blue-500 dark:text-blue-300" />
                الفصول والدروس التي تحتاج مراجعة
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-300 mt-1">
                كل إجابة خاطئة في الكويزات أو الامتحانات تُنسَب تلقائياً إلى درسها وفصلها
              </p>
            </div>
            {chapterRows.length === 0 ? (
              <p className="text-center text-sm text-slate-400 dark:text-slate-500 py-8">
                لا توجد دروس تحتاج مراجعة — استمر!
              </p>
            ) : (
              <div className="divide-y divide-slate-50 dark:divide-slate-800">
                {chapterRows.map((row) => (
                  <div key={row.chapter} className="p-4">
                    <div className="flex items-center justify-between gap-3 mb-3">
                      <p className="text-sm font-bold text-slate-700 dark:text-slate-100">{chapterLabel(row.chapter)}</p>
                      <span className="text-xs px-2.5 py-1 rounded-lg font-bold bg-error-50 text-error-600 dark:bg-error-500/15 dark:text-error-300">
                        {row.wrong} خطأ
                      </span>
                    </div>
                    <div className="flex flex-wrap gap-2">
                      {row.lessons.map((entry) => (
                        <span
                          key={entry.lessonId}
                          className="text-xs px-2.5 py-1.5 rounded-lg border border-slate-100 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-600 dark:text-slate-300"
                        >
                          {entry.title}
                          <span className="font-bold text-error-600 dark:text-error-300"> — {entry.wrong}</span>
                        </span>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          <div className="bg-white dark:bg-slate-900 rounded-2xl shadow-sm border border-slate-100 dark:border-slate-800 overflow-hidden">
            <div className="p-5 border-b border-slate-100 dark:border-slate-800">
              <h3 className="font-bold text-slate-800 dark:text-slate-100 flex items-center gap-2">
                <AlertCircle className="w-5 h-5 text-orange-500 dark:text-orange-300" />
                تحليل المواضيع
              </h3>
            </div>
            <div className="p-4 space-y-2">
              {sortedTopics.length === 0 ? (
                <p className="text-center text-sm text-slate-400 dark:text-slate-500 py-6">
                  لم تُسجل أخطاء بعد — أحسنت!
                </p>
              ) : (
                sortedTopics.map(([topic, stats]) => {
                  const isWeak = stats.wrong > 0;
                  const severity = stats.wrong >= 2 ? 'high' : stats.wrong === 1 ? 'medium' : 'none';

                  return (
                    <div
                      key={topic}
                      className={`flex items-center gap-3 p-3 rounded-xl border ${
                        severity === 'high'
                          ? 'bg-error-50 border-error-100'
                          : severity === 'medium'
                          ? 'bg-amber-50 dark:bg-amber-500/15 border-amber-100 dark:border-amber-500/30'
                          : 'bg-emerald-50 dark:bg-emerald-500/15 border-emerald-100 dark:border-emerald-500/30'
                      }`}
                    >
                      <div
                        className={`flex-shrink-0 w-10 h-10 rounded-lg flex items-center justify-center ${
                          severity === 'high'
                            ? 'bg-error-100 text-error-600'
                            : severity === 'medium'
                            ? 'bg-amber-100 dark:bg-amber-500/25 text-amber-600 dark:text-amber-300'
                            : 'bg-emerald-100 dark:bg-emerald-500/25 text-emerald-600 dark:text-emerald-300'
                        }`}
                      >
                        {isWeak ? (
                          <AlertCircle className="w-5 h-5" />
                        ) : (
                          <CheckCircle2 className="w-5 h-5" />
                        )}
                      </div>
                      <div className="flex-1">
                        <p className="text-sm font-bold text-slate-700 dark:text-slate-100">{topic}</p>
                        <p className="text-xs text-slate-500 dark:text-slate-300">
                          {isWeak
                            ? `${stats.wrong} خطأ — يحتاج مراجعة`
                            : 'لا توجد أخطاء'}
                        </p>
                      </div>
                      {isWeak && (
                        <span
                          className={`text-xs px-2.5 py-1 rounded-lg font-bold ${
                            severity === 'high'
                              ? 'bg-error-500 text-white'
                              : 'bg-amber-500 text-white'
                          }`}
                        >
                          {severity === 'high' ? 'ذات أولوية' : 'راقب'}
                        </span>
                      )}
                    </div>
                  );
                })
              )}
            </div>
          </div>

          <div className="bg-white dark:bg-slate-900 rounded-2xl shadow-sm border border-slate-100 dark:border-slate-800 overflow-hidden">
            <div className="p-5 border-b border-slate-100 dark:border-slate-800">
              <h3 className="font-bold text-slate-800 dark:text-slate-100">آخر المحاولات</h3>
            </div>
            <div className="divide-y divide-slate-50">
              {results.slice(0, 5).map((r) => {
                const percentage = Math.round((r.score / r.total) * 100);
                return (
                  <div key={r.id} className="flex items-center gap-3 p-4">
                    <div
                      className={`flex-shrink-0 w-10 h-10 rounded-lg flex items-center justify-center ${
                        percentage >= 70
                          ? 'bg-emerald-50 dark:bg-emerald-500/15 text-emerald-600 dark:text-emerald-300'
                          : percentage >= 50
                          ? 'bg-amber-50 dark:bg-amber-500/15 text-amber-600 dark:text-amber-300'
                          : 'bg-error-50 text-error-600'
                      }`}
                    >
                      <span className="text-sm font-bold">{percentage}%</span>
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-semibold text-slate-700 dark:text-slate-100 truncate">
                        {attemptTitle(r.quiz_id)}
                      </p>
                      <p className="text-xs text-slate-400 dark:text-slate-500">
                        {r.score} / {r.total} — {new Date(r.created_at).toLocaleDateString('ar-EG')}
                      </p>
                    </div>
                    {r.wrong_topics.length > 0 && (
                      <div className="flex gap-1 flex-wrap justify-end max-w-[40%]">
                        {r.wrong_topics.slice(0, 2).map((t) => (
                          <span
                            key={t}
                            className="text-[10px] px-2 py-0.5 bg-error-50 text-error-600 rounded-full font-semibold"
                          >
                            {t}
                          </span>
                        ))}
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        </>
      )}
    </div>
  );
}
