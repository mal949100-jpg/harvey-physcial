/*
# Update admin email to mal949100@gmail.com

Replaces the old owner email (mohamed.ali.eldefrawi@gmail.com) with the new
owner email (mal949100@gmail.com) in the auto-promote trigger.

Also promotes the new email if a profile already exists for it.
*/

CREATE OR REPLACE FUNCTION public.promote_owner_admin()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF NEW.email = 'mal949100@gmail.com' THEN
    NEW.is_admin := true;
  END IF;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS on_profile_owner_promote ON profiles;
CREATE TRIGGER on_profile_owner_promote
  BEFORE INSERT OR UPDATE ON profiles
  FOR EACH ROW EXECUTE FUNCTION public.promote_owner_admin();

-- Promote existing profile if the new admin email already has an account
UPDATE profiles SET is_admin = true WHERE email = 'mal949100@gmail.com';
