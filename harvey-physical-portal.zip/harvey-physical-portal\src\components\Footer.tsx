import { Atom, Heart } from 'lucide-react';
import { chapters, lessons, lessonsOfChapter, lessonsOfTerm } from '@/data/lessons';

export default function Footer() {
  return (
    <footer className="bg-slate-900 text-white mt-auto">
      <div className="px-4 lg:px-8 py-8">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
          <div className="space-y-3">
            <div className="flex items-center gap-2">
              <div className="w-10 h-10 bg-gradient-to-br from-primary-500 to-primary-700 rounded-lg flex items-center justify-center">
                <Atom className="w-6 h-6 text-white" />
              </div>
              <div>
                <h3 className="font-bold text-lg">هارفي فيزيكال</h3>
                <p className="text-xs text-primary-300">منصة الفيزياء للثانوية العامة</p>
              </div>
            </div>
            <p className="text-sm text-gray-400 leading-relaxed">
              منصة تعليمية متكاملة تغطي منهج الفيزياء للصف الثاني الثانوي 2026، شاملة الشرح والقوانين والفيديوهات وبنك الأسئلة.
            </p>
          </div>

          <div className="space-y-2">
            <h4 className="font-semibold text-sm text-gray-300 mb-3">أقسام المنصة</h4>
            <ul className="space-y-1.5 text-sm text-gray-400">
              <li>شرح الدروس وكتاب الوزارة</li>
              <li>شرح القوانين والمعادلات</li>
              <li>فيديوهات الشرح</li>
              <li>بنك الأسئلة والحلول المفصلة</li>
              <li>المساعد الذكي التفاعلي</li>
              <li>المراجعات والامتحانات</li>
              <li>سجل محادثاتي</li>
            </ul>
          </div>

          <div className="space-y-2">
            <h4 className="font-semibold text-sm text-gray-300 mb-3">المنهج الدراسي</h4>
            <ul className="space-y-1.5 text-sm text-gray-400">
              {chapters.map((chapter) => (
                <li key={chapter.id}>
                  {chapter.title} ({lessonsOfChapter(chapter.id).length} درساً)
                </li>
              ))}
              <li>
                الترم الأول {lessonsOfTerm(1).length} درساً + الترم الثاني {lessonsOfTerm(2).length} درساً
              </li>
              <li>إجمالي: {lessons.length} درساً كاملاً</li>
              <li>منهج 2026 الجديد</li>
            </ul>
          </div>
        </div>

        <div className="border-t border-white/10 pt-6 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2 text-sm text-gray-400">
            <span>صُنع بـ</span>
            <Heart className="w-4 h-4 text-error-500 fill-current" />
            <span>تم إنشاء هذا الموقع بواسطة</span>
            <span className="font-bold text-primary-300">محمد علي الدفراوي</span>
          </div>
          <p className="text-xs text-gray-500 dark:text-slate-400">
            © 2026 هارفي فيزيكال — جميع الحقوق محفوظة
          </p>
        </div>
      </div>
    </footer>
  );
}
