export interface Question {
  q: string;
  steps: string[];
  answer: string;
}

export interface MinistrySymbol {
  symbol: string;
  meaning: string;
  unit: string;
}

/** «علل لما يأتي»: نص السؤال كما ورد في صياغات الوزارة وإجابته النموذجية. */
export interface MinistryReason {
  question: string;
  answer: string;
}

export interface LawItem {
  name: string;
  formula: string;
  units: string;
  explanation: string;
  /** شرح كل رمز في القانون بوحدته، كما يورده الكتاب. */
  symbols?: MinistrySymbol[];
  /** شروط وافتراضات تطبيق القانون. */
  conditions?: string[];
  /** النتائج المترتبة على القانون: التناسبات وحالات المضاعفة. */
  results?: string[];
  /** العلاقة البيانية الصحيحة بين كميات القانون. */
  graphNote?: string;
}

export interface DeepDiveContent {
  introduction: string;
  lectureScript: string[];
  derivations: { title: string; steps: string[]; note: string; results: string[] }[];
  pitfalls: string[];
  problemFramework: string[];
  terminology: { term: string; meaning: string }[];
  notes: string[];
  reasons: MinistryReason[];
  capsule: string[];
}

export interface FormulaBreakdown {
  origin: string;
  variables: MinistrySymbol[];
  graph: string;
  conditions: string[];
  results: string[];
}

/** 1 الميكانيكا — 2 الحركة الاهتزازية والموجات — 3 الكهرباء والمغناطيسية — 4 الفيزياء الحديثة. */
export type ChapterId = 1 | 2 | 3 | 4;

/** الترم لا يُخزَّن على الدرس: الفصلان 1 و2 في الترم الأول، والفصلان 3 و4 في الترم الثاني. */
export type TermId = 1 | 2;

export interface Lesson {
  id: number;
  chapter: ChapterId;
  title: string;
  summary: string;
  concepts: { title: string; detail: string }[];
  laws: LawItem[];
  youtubeSearch: string;
  questions: Question[];
  /** المصطلحات والتعريفات الواردة في كتاب الوزارة للدرس. */
  terms?: { term: string; meaning: string }[];
  /** الملاحظات الهامة التي تُسأل بصيغة «صح وخطأ» أو «أكمل». */
  notes?: string[];
  /** أسئلة «علل لما يأتي» وإجاباتها النموذجية. */
  reasons?: MinistryReason[];
  /** كبسولة المراجعة السريعة قبل حل أسئلة الدرس. */
  capsule?: string[];
}
