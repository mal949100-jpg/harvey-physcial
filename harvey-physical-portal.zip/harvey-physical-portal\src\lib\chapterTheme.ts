import type { ChapterId, TermId } from '@/data/lessonTypes';

/**
 * Chapter/term colour classes live here instead of being interpolated from the `color`
 * metadata: Tailwind only generates utility strings it can see literally in the source,
 * so `bg-${color}-50` would silently produce no styles.
 */
export const chapterSoft: Record<ChapterId, string> = {
  1: 'bg-blue-50 dark:bg-blue-500/15 text-blue-600 dark:text-blue-300',
  2: 'bg-emerald-50 dark:bg-emerald-500/15 text-emerald-600 dark:text-emerald-300',
  3: 'bg-violet-50 dark:bg-violet-500/15 text-violet-600 dark:text-violet-300',
  4: 'bg-amber-50 dark:bg-amber-500/15 text-amber-600 dark:text-amber-300',
};

/** Strong fill for chips that sit on top of an image or a coloured card. */
export const chapterSolid: Record<ChapterId, string> = {
  1: 'bg-blue-500/80 text-white',
  2: 'bg-emerald-500/80 text-white',
  3: 'bg-violet-500/80 text-white',
  4: 'bg-amber-500/80 text-white',
};

export const termSoft: Record<TermId, string> = {
  1: 'bg-sky-50 dark:bg-sky-500/15 text-sky-600 dark:text-sky-300',
  2: 'bg-rose-50 dark:bg-rose-500/15 text-rose-600 dark:text-rose-300',
};

export const termSolid: Record<TermId, string> = {
  1: 'bg-sky-600 text-white',
  2: 'bg-rose-600 text-white',
};
