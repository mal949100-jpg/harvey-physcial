import { lessons, type Lesson } from './lessons';
import { lessonKeywordHints } from './assistantKeywords';

const SPLIT = /[\s؟?.,:;()ـ\-–—\/+=*[\]{}،]+/;
const STOPWORDS = new Set([
  'في', 'من', 'على', 'عن', 'مع', 'هذا', 'هذه', 'التي', 'الذي', 'كيف', 'ما', 'هو', 'هي',
  'عند', 'كان', 'لكن', 'حتى', 'بين', 'كل', 'به', 'عنه', 'مطلوب', 'مسألة', 'سؤال',
]);

/**
 * العربية تُكتب بصيغ متعددة لنفس الجذر (الإشعاعات/إشعاع/إشعاعي)، والمقارنة الحرفية تُفشل
 * المساعد أمام 45 درساً. لذلك تُوحَّد الحروف وتُجرَّد السوابق واللاحقات على الطرفين.
 */
export function stem(word: string): string {
  let w = word
    .toLowerCase()
    .replace(/[ًٌٍَُِّْـ]/g, '')
    .replace(/[أإآ]/g, 'ا')
    .replace(/ى/g, 'ي')
    .replace(/ة/g, 'ه');
  if (w.length > 4) w = w.replace(/^(وال|فال|بال|كال|لل|ال)/, '');
  if (w.length > 5) w = w.replace(/(ات|ين|ية|اتي)$/, '');
  if (w.length > 4) w = w.replace(/ي$/, '');
  return w;
}

export function tokens(text: string): string[] {
  return text
    .split(SPLIT)
    .filter((word) => word.length > 3 && !STOPWORDS.has(word.toLowerCase()))
    .map(stem)
    .filter((word) => word.length > 2);
}

function hits(query: Set<string>, words: string[]): number {
  let count = 0;
  for (const word of words) if (query.has(word)) count++;
  return count;
}

/**
 * مرشّح مثل "درجة حرارة اللون" لا يُحتسب إلا إذا جاءت كل كلماته في السؤال، وإلا كان
 * مجرد كلمة شائعة بين فصول كثيرة وتُخطئ توجيه الطالب.
 */
function phraseHits(query: Set<string>, phrases: string[]): number {
  let count = 0;
  for (const phrase of phrases) {
    const parts = tokens(phrase);
    if (parts.length > 0 && parts.every((word) => query.has(word))) count++;
  }
  return count;
}

/**
 * The syllabus is 45 lessons across 4 chapters, so title words alone misroute a question that
 * shares a generic word with chapter 1. Titles, concepts, laws, worked questions and the
 * unit/synonym hints all vote; a question with no real vote returns null so the assistant asks
 * for clarification instead of dumping the student on lesson 1.
 */
export function findRelevantLesson(query: string): Lesson | null {
  const normalized = query.toLowerCase();
  const queryTokens = new Set(tokens(query));
  let best: { lesson: Lesson; score: number } | null = null;

  for (const lesson of lessons) {
    let score = 0;
    if (normalized.includes(lesson.title.toLowerCase())) score += 24;
    score += Math.min(9, 3 * hits(queryTokens, tokens(lesson.title)));
    for (const concept of lesson.concepts) {
      score += Math.min(4, 2 * hits(queryTokens, tokens(concept.title)));
    }
    for (const law of lesson.laws) {
      if (normalized.includes(law.name.toLowerCase())) score += 6;
      score += Math.min(4, 2 * hits(queryTokens, tokens(law.name)));
      score += Math.min(2, hits(queryTokens, tokens(law.units)));
    }
    for (const question of lesson.questions) {
      score += Math.min(4, 2 * hits(queryTokens, tokens(question.q)));
    }
    score += Math.min(12, 6 * phraseHits(queryTokens, lessonKeywordHints[lesson.id] ?? []));

    if (!best || score > best.score) best = { lesson, score };
  }

  return best && best.score >= 3 ? best.lesson : null;
}
