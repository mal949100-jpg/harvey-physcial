import {
  generateWrongNumeric, gravity, makeNumericChoices, pick, randFloat, randInt, round,
  type ProblemTemplate,
} from './questionFactory';

/**
 * الفصل الثالث: الكهرباء والمغناطيسية — قوالب المسائل الحسابية للدروس 24 إلى 34.
 *
 * كل قالب يشتق الناتج بالحساب في الكود (لا ثابت مكتوب يدوياً)، ثم يعرض نفس
 * الأرقام في الخطوات والتوضيح حتى يتطابق الحل المطبوع مع الاختيار الصحيح.
 * الثوابت المستخدمة: k = 9×10⁹ N·m²/C²، ε₀ = 8.85×10⁻¹² F/m، e = 1.6×10⁻¹⁹ C،
 * m_e = 9×10⁻³¹ kg، √2 ≈ 1.414.
 */
export const electricityProblemTemplates: Record<number, ProblemTemplate[]> = {
  // ============================ 24: الشحنة وقانون كولوم ============================
  24: [
    {
      generate: (d) => {
        const q1 = randInt(2, 9);
        const q2 = randInt(3, 12);
        const r = randFloat(0.2, 0.6, 2);
        const product = round(q1 * q2, 1);
        const numerator = round(9e9 * q1 * 1e-6 * (q2 * 1e-6), 4);
        const r2 = round(r * r, 4);
        const ans = round(9e9 * q1 * 1e-6 * (q2 * 1e-6) / (r * r), 2);
        const correct = `${ans} N`;
        return {
          question: d === 'easy'
            ? `شحنتان q₁ = ${q1} μC و q₂ = ${q2} μC تفصل بينهما مسافة ${r} m في الهواء. احسب القوة بينهما.`
            : `شحنتان نقطيتان متماثلتان في الإشارة q₁ = ${q1} μC و q₂ = ${q2} μC ثابتتان في الهواء على بُعد ${r} m بين مركزيهما. احسب مقدار القوة الكهربائية المؤثرة على كل منهما. (k = 9×10⁹ N·m²/C²)`,
          ...makeNumericChoices(correct, generateWrongNumeric(ans, 'N')),
          explanation: `قانون كولوم: F = k q₁q₂/r² = ${numerator} / ${r2} = ${ans} N، وهي قوة تنافر لأن الشحنتين متماثلتان في الإشارة.`,
          steps: [
            `المعطيات: q₁ = ${q1}×10⁻⁶ C، q₂ = ${q2}×10⁻⁶ C، r = ${r} m`,
            `q₁ × q₂ = ${product}×10⁻¹² C²`,
            `k q₁q₂ = 9×10⁹ × ${product}×10⁻¹² = ${numerator} N·m²`,
            `r² = (${r})² = ${r2} m²`,
            `F = ${numerator} / ${r2} = ${ans} N`,
          ],
        };
      },
    },
    {
      generate: (d) => {
        const count = randInt(2, 9);
        const qMicro = round(count * 1.6, 1);
        const ans = round(qMicro * 1e-6 / 1.6e-19 / 1e13, 2);
        const correct = `${ans} ×10¹³ إلكترون`;
        return {
          question: d === 'easy'
            ? `جسم شحنته +${qMicro} μC. احسب عدد الإلكترونات التي فقدها. (e = 1.6×10⁻¹⁹ C)`
            : `كرة معدنية اكتسبت شحنة موجبة مقدارها +${qMicro} μC بعد دلكها بقطعة قماش. احسب عدد الإلكترونات التي فقدتها فعلاً، وبيّن لماذا تعتبر الشحنة مكمّاة.`,
          ...makeNumericChoices(correct, generateWrongNumeric(ans, '×10¹³ إلكترون')),
          explanation: `Q = n e → n = Q/e = ${qMicro}×10⁻⁶ / 1.6×10⁻¹⁹ = ${ans}×10¹³ إلكترون.`,
          steps: [
            `Q = ${qMicro} μC = ${qMicro}×10⁻⁶ C`,
            `n = Q / e = ${qMicro}×10⁻⁶ / 1.6×10⁻¹⁹`,
            `n = ${round(qMicro / 1.6, 2)} × 10¹³`,
            `n = ${ans} ×10¹³ إلكترون`,
          ],
        };
      },
    },
    {
      generate: () => {
        const q1 = randInt(2, 10);
        const q2 = randInt(2, 10);
        const each = round((q1 + q2) / 2, 2);
        const r = randFloat(0.2, 0.5, 2);
        const numerator = round(9e9 * each * 1e-6 * (each * 1e-6), 4);
        const r2 = round(r * r, 4);
        const ans = round(9e9 * (each * 1e-6) * (each * 1e-6) / (r * r), 2);
        const correct = `${ans} N`;
        return {
          question: `كرويتان معدنيتان متماثلتان شحنتاهما +${q1} μC و +${q2} μC؛ لامست إحداهما الأخرى ثم أبعدتا حتى صار بُعد مركزيهما ${r} m. احسب قوة التنافر بينهما بعد التلامس.`,
          ...makeNumericChoices(correct, generateWrongNumeric(ans, 'N')),
          explanation: `عند التلامس تتوزع الشحنة الكلية بالتساوي: q = (${q1} + ${q2})/2 = ${each} μC لكل كرة، ثم F = ${numerator}/${r2} = ${ans} N.`,
          steps: [
            `الشحنة الكلية = ${q1} + ${q2} = ${q1 + q2} μC`,
            `شحنة كل كرة بعد التلامس = ${q1 + q2} / 2 = ${each} μC`,
            `F = k q² / r² = 9×10⁹ × (${each}×10⁻⁶)² / (${r})²`,
            `k q² = ${numerator}، r² = ${r2}`,
            `F = ${numerator} / ${r2} = ${ans} N`,
          ],
        };
      },
    },
    {
      generate: (d) => {
        const f1 = randFloat(4, 36, 1);
        const ratio = pick([2, 3]);
        const ans = round(f1 / (ratio * ratio), 2);
        const correct = `${ans} N`;
        return {
          question: d === 'easy'
            ? `قوة التنافر بين شحنتين ${f1} N عندما كانت المسافة بينهما 20 cm. ما القوة لو أصبحت المسافة ${20 * ratio} cm مع بقاء الشحنتين؟`
            : `شحنتان نقطيتان في الهواء تتنافان بقوة ${f1} N. إذا زادت المسافة بينهما إلى ${ratio} ضعف دون تغيير الشحنتين، فكم تصبح قوة التنافر الجديدة؟ علّل باستخدام التناسب العكسي مع مربع المسافة.`,
          ...makeNumericChoices(correct, generateWrongNumeric(ans, 'N')),
          explanation: `القوة تتناسب عكسياً مع مربع المسافة، فزيادتها ${ratio} أضعاف تجعلها ${round(1 / (ratio * ratio), 4)} من قيمتها الأصلية: ${f1} / ${ratio * ratio} = ${ans} N.`,
          steps: [
            `F ∝ 1 / r² → F₂ = F₁ × (r₁/r₂)²`,
            `r₂ = ${ratio} r₁ → (r₁/r₂)² = 1/${ratio * ratio}`,
            `F₂ = ${f1} × 1/${ratio * ratio}`,
            `F₂ = ${f1} / ${ratio * ratio} = ${ans} N`,
          ],
        };
      },
    },
    {
      generate: () => {
        const f1 = randFloat(2, 20, 1);
        const er = pick([2, 4, 5]);
        const ans = round(f1 / er, 2);
        const correct = `${ans} N`;
        return {
          question: `قوة التجاذب بين شحنتين في الهواء ${f1} N. أبقيت الشحنتان والمسافة كما هما وغمرتا في وسط مادي ثابت عزله النسبي ${er}. احسب القوة في الوسط.`,
          ...makeNumericChoices(correct, generateWrongNumeric(ans, 'N')),
          explanation: `F_وسيط = F_هواء / εᵣ = ${f1} / ${er} = ${ans} N، فالوسط يُضعف القوة الكهربائية.`,
          steps: [
            `القوة في الوسط = القوة في الهواء ÷ ثابت العزل النسبي`,
            `F = k q₁q₂ / (εᵣ r²) = F_هواء / εᵣ`,
            `F = ${f1} / ${er}`,
            `F = ${ans} N`,
          ],
        };
      },
    },
  ],

  // ============================ 25: المجال الكهربائي ============================
  25: [
    {
      generate: (d) => {
        const q = randInt(2, 20);
        const fMn = randFloat(2, 40, 1);
        const ans = round(fMn / q, 2);
        const correct = `${ans} ×10³ N/C`;
        return {
          question: d === 'easy'
            ? `شحنة اختبار مقدارها ${q} μC تؤثر عليها قوة ${fMn} mN في مجال كهربائي. احسب شدة المجال.`
            : `شحنة اختبار موجبة مقدارها ${q} μC عُلّقت في نقطة ما من مجال كهربائي فأثرت عليها قوة مقدارها ${fMn} mN. احسب شدة المجال عند تلك النقطة وحدد اتجاهه. (1 mN = 10⁻³ N)`,
          ...makeNumericChoices(correct, generateWrongNumeric(ans, '×10³ N/C')),
          explanation: `E = F/q = (${fMn}×10⁻³) / (${q}×10⁻⁶) = ${ans}×10³ N/C، واتجاهه في اتجاه القوة على الشحنة الموجبة.`,
          steps: [
            `F = ${fMn} mN = ${fMn}×10⁻³ N، q = ${q}×10⁻⁶ C`,
            `E = F / q = (${fMn}×10⁻³) / (${q}×10⁻⁶)`,
            `E = (${round(fMn, 1)} / ${q}) × 10³`,
            `E = ${ans} ×10³ N/C`,
          ],
        };
      },
    },
    {
      generate: () => {
        const Q = randInt(2, 10);
        const r = pick([0.3, 0.4, 0.5, 0.6]);
        const raw = 9e9 * Q * 1e-6 / (r * r);
        const ans = round(raw / 1e5, 2);
        const correct = `${ans} ×10⁵ N/C`;
        return {
          question: `احسب شدة المجال الكهربائي عند نقطة بعدها ${r} m عن شحنة نقطية مقدارها ${Q} μC في الهواء. (k = 9×10⁹ N·m²/C²)`,
          ...makeNumericChoices(correct, generateWrongNumeric(ans, '×10⁵ N/C')),
          explanation: `E = kQ/r² = 9×10⁹ × ${Q}×10⁻⁶ / ${round(r * r, 4)} = ${round(raw, 1)} N/C = ${ans}×10⁵ N/C.`,
          steps: [
            `E = k Q / r²`,
            `k Q = 9×10⁹ × ${Q}×10⁻⁶ = ${round(9e9 * Q * 1e-6, 1)}`,
            `r² = (${r})² = ${round(r * r, 4)} m²`,
            `E = ${round(9e9 * Q * 1e-6, 1)} / ${round(r * r, 4)} = ${round(raw, 1)} N/C`,
            `E = ${ans} ×10⁵ N/C (بعيداً عن الشحنة لأنها موجبة)`,
          ],
        };
      },
    },
    {
      generate: (d) => {
        const q = randInt(2, 25);
        const eK = randInt(2, 9);
        const ans = round(q * eK, 1);
        const correct = `${ans} ×10⁻³ N`;
        return {
          question: d === 'easy'
            ? `شحنة ${q} μC وُضعت في مجال شدته ${eK} ×10³ N/C. احسب القوة المؤثرة عليها.`
            : `جسيم شحنته ${q} μC أُطلق داخل مجال كهربائي منتظم شدته ${eK}×10³ N/C بحيث كان اتجاه حركته موازياً لخطوط المجال. احسب مقدار القوة الكهربائية المؤثرة عليه.`,
          ...makeNumericChoices(correct, generateWrongNumeric(ans, '×10⁻³ N')),
          explanation: `F = qE = ${q}×10⁻⁶ × ${eK}×10³ = ${ans}×10⁻³ N.`,
          steps: [
            `F = q × E`,
            `q = ${q}×10⁻⁶ C، E = ${eK}×10³ N/C`,
            `F = ${q} × ${eK} × 10⁻³`,
            `F = ${ans} ×10⁻³ N`,
          ],
        };
      },
    },
    {
      generate: () => {
        const dCm = pick([30, 60, 90, 120]);
        const ratio = pick([4, 9]);
        const root = Math.round(Math.sqrt(ratio));
        const ans = round(dCm / (1 + root), 1);
        const correct = `${ans} cm`;
        return {
          question: `شحنتان موجبتان مقداراهما q و ${ratio}q تفصل بينهما مسافة ${dCm} cm على خط مستقيم. حدد موضع النقطة التي تنعدم عندها شدة محصلة المجال على الخط الواصل بينهما (المسافة من الشحنة الأصغر).`,
          ...makeNumericChoices(correct, generateWrongNumeric(ans, 'cm')),
          explanation: `بين شحنتين متماثلتين في الإشارة يوجد موضع محصلة المجال صفراً، وهو الأقرب للشحنة الأصغر: q/x² = ${ratio}q/(${dCm} - x)² → x = ${dCm}/(1 + ${root}) = ${ans} cm.`,
          steps: [
            `المجالان متضادان في الاتجاه بين الشحنتين، فالموضع المطلوب بينهما`,
            `k q / x² = k (${ratio}q) / (${dCm} - x)²`,
            `بأخذ الجذر: (${dCm} - x) / x = ${root}`,
            `${dCm} = ${1 + root} x → x = ${dCm} / ${1 + root}`,
            `x = ${ans} cm من الشحنة q`,
          ],
        };
      },
    },
    {
      generate: () => {
        const v = randInt(4, 40) * 10;
        const dist = pick([0.02, 0.04, 0.05, 0.1]);
        const raw = v / dist;
        const ans = round(raw / 1000, 2);
        const correct = `${ans} ×10³ N/C`;
        return {
          question: `لوحان معدنيان متوازيان المسافة بينهما ${dist} m وفرق الجهد بينهما ${v} V. احسب شدة المجال الكهربائي المنتظم بينهما.`,
          ...makeNumericChoices(correct, generateWrongNumeric(ans, '×10³ N/C')),
          explanation: `المجال بين لوحين منتظم: E = V/d = ${v}/${dist} = ${round(raw, 1)} N/C = ${ans}×10³ N/C.`,
          steps: [
            `E = V / d (مجال منتظم بين لوحين)`,
            `E = ${v} / ${dist}`,
            `E = ${round(raw, 1)} N/C`,
            `E = ${ans} ×10³ N/C`,
          ],
        };
      },
    },
  ],

  // ============================ 26: الجهد وفرق الجهد ============================
  26: [
    {
      generate: (d) => {
        const q = randInt(2, 10);
        const dv = randInt(4, 60);
        const work = q * dv;
        const ans = round(work / q, 1);
        const correct = `${ans} V`;
        return {
          question: d === 'easy'
            ? `بذل شغل مقداره ${work} μJ لنقل شحنة ${q} μC بين نقطتين. احسب فرق الجهد بينهما.`
            : `أثّر مؤثر خارجي بشغل مقداره ${work} μJ لنقل شحنة موجبة ${q} μC ببطء من نقطة إلى أخرى داخل مجال كهربائي. احسب فرق الجهد بين النقطتين. (1 μJ = 10⁻⁶ J)`,
          ...makeNumericChoices(correct, generateWrongNumeric(ans, 'V')),
          explanation: `ΔV = W/q = ${round(work, 1)}×10⁻⁶ / (${q}×10⁻⁶) = ${ans} V.`,
          steps: [
            `W = ${work} μJ = ${work}×10⁻⁶ J، q = ${q}×10⁻⁶ C`,
            `ΔV = W / q`,
            `ΔV = ${work} / ${q}`,
            `ΔV = ${ans} V`,
          ],
        };
      },
    },
    {
      generate: () => {
        const Q = randInt(2, 10);
        const r = pick([0.2, 0.3, 0.5, 0.9]);
        const raw = 9e9 * Q * 1e-6 / r;
        const ans = round(raw / 1e4, 2);
        const correct = `${ans} ×10⁴ V`;
        return {
          question: `احسب الجهد الكهربائي عند نقطة على بُعد ${r} m من شحنة نقطية مقدارها ${Q} μC في الهواء، مع اعتبار الجهد عند اللانهاية صفراً. (k = 9×10⁹ N·m²/C²)`,
          ...makeNumericChoices(correct, generateWrongNumeric(ans, '×10⁴ V')),
          explanation: `V = kQ/r = 9×10⁹ × ${Q}×10⁻⁶ / ${r} = ${round(raw, 1)} V = ${ans}×10⁴ V، والجهد كمية قياسية.`,
          steps: [
            `V = k Q / r`,
            `k Q = 9×10⁹ × ${Q}×10⁻⁶ = ${round(9e9 * Q * 1e-6, 1)}`,
            `V = ${round(9e9 * Q * 1e-6, 1)} / ${r} = ${round(raw, 1)} V`,
            `V = ${ans} ×10⁴ V`,
          ],
        };
      },
    },
    {
      generate: (d) => {
        const q = randInt(2, 10);
        const dv = randInt(5, 120);
        const ans = round(q * dv, 1);
        const correct = `${ans} ×10⁻⁶ J`;
        return {
          question: d === 'easy'
            ? `شحنة ${q} μC انتقلت بين نقطتين فرق الجهد بينهما ${dv} V. احسب الشغل.`
            : `شحنة موجبة مقدارها ${q} μC تحرّرت من نقطة جهداها الأعلى إلى نقطة أقل منها بفرق جهد ${dv} V. احسب الشغل الذي تبذله القوة الكهربائية، وبيّن كيف تتحول هذه الطاقة.`,
          ...makeNumericChoices(correct, generateWrongNumeric(ans, '×10⁻⁶ J')),
          explanation: `W = q ΔV = ${q}×10⁻⁶ × ${dv} = ${ans}×10⁻⁶ J.`,
          steps: [
            `W = q × ΔV`,
            `q = ${q}×10⁻⁶ C، ΔV = ${dv} V`,
            `W = ${q} × ${dv} × 10⁻⁶`,
            `W = ${ans} ×10⁻⁶ J`,
          ],
        };
      },
    },
    {
      generate: () => {
        const q1 = randInt(2, 8);
        const q2 = randInt(2, 8);
        const sep = pick([0.2, 0.4]);
        const r = round(sep / 2, 2);
        const sum = q1 + q2;
        const raw = 9e9 * sum * 1e-6 / r;
        const ans = round(raw / 1e5, 2);
        const correct = `${ans} ×10⁵ V`;
        return {
          question: `شحنتان موجبتان ${q1} μC و ${q2} μC ثابتتان على بُعد ${sep} m. احسب محصلة الجهد عند منتصف الخط الواصل بينهما.`,
          ...makeNumericChoices(correct, generateWrongNumeric(ans, '×10⁵ V')),
          explanation: `الجهد كمية قياسية فيُجمع جبرياً: V = k(q₁+q₂)/r = 9×10⁹ × ${sum}×10⁻⁶ / ${r} = ${round(raw, 1)} V = ${ans}×10⁵ V.`,
          steps: [
            `المسافة من كل شحنة إلى المنتصف r = ${sep}/2 = ${r} m`,
            `V = k q₁/r + k q₂/r = k (q₁ + q₂)/r`,
            `q₁ + q₂ = ${sum} μC = ${sum}×10⁻⁶ C`,
            `V = ${round(9e9 * sum * 1e-6, 1)} / ${r} = ${round(raw, 1)} V`,
            `V = ${ans} ×10⁵ V`,
          ],
        };
      },
    },
  ],

  // ============================ 27: المكثفات ============================
  27: [
    {
      generate: (d) => {
        const c = randInt(2, 20);
        const v = randInt(5, 60);
        const ans = round(c * v, 1);
        const correct = `${ans} ×10⁻⁶ C`;
        return {
          question: d === 'easy'
            ? `مكثف سعته ${c} μF وُصل بفرق جهد ${v} V. احسب شحنته.`
            : `مكثف سعته ${c} μF شُحن بفرق جهد ${v} V حتى اكتمل الشحن. احسب مقدار الشحنة على كل لوح، واذكر ما الذي يحدث لو تضاعف فرق الجهد.`,
          ...makeNumericChoices(correct, generateWrongNumeric(ans, '×10⁻⁶ C')),
          explanation: `Q = C V = ${c}×10⁻⁶ × ${v} = ${ans}×10⁻⁶ C، والشحنة تتناسب طردياً مع الجهد عند ثبوت السعة.`,
          steps: [
            `C = ${c} μF = ${c}×10⁻⁶ F، V = ${v} V`,
            `Q = C × V`,
            `Q = ${c} × ${v} × 10⁻⁶`,
            `Q = ${ans} ×10⁻⁶ C`,
          ],
        };
      },
    },
    {
      generate: () => {
        const q = randInt(50, 600);
        const v = randInt(5, 60);
        const ans = round(q / v, 2);
        const correct = `${ans} μF`;
        return {
          question: `مكثف خُزّنت عليه شحنة ${q} μC عند فرق جهد ${v} V بين لوحية. احسب سعته الكهربائية.`,
          ...makeNumericChoices(correct, generateWrongNumeric(ans, 'μF')),
          explanation: `C = Q/V = ${q}×10⁻⁶ / ${v} = ${ans}×10⁻⁶ F = ${ans} μF.`,
          steps: [
            `C = Q / V`,
            `Q = ${q}×10⁻⁶ C، V = ${v} V`,
            `C = ${q} / ${v} × 10⁻⁶`,
            `C = ${ans} ×10⁻⁶ F = ${ans} μF`,
          ],
        };
      },
    },
    {
      generate: (d) => {
        const c = randInt(2, 20);
        const v = randInt(20, 200);
        const uMicro = round(0.5 * c * v * v, 1);
        const ans = round(uMicro / 1000, 2);
        const correct = `${ans} ×10⁻³ J`;
        return {
          question: d === 'easy'
            ? `مكثف سعته ${c} μF على فرق جهد ${v} V. احسب الطاقة المختزنة فيه.`
            : `مكثف سعته ${c} μF شُحن بفرق جهد ${v} V ثم فُصل عن المصدر. احسب الطاقة المختزنة في مجاله الكهربائي، وبيّن أين تذهب هذه الطاقة عند تفريغ المكثف.`,
          ...makeNumericChoices(correct, generateWrongNumeric(ans, '×10⁻³ J')),
          explanation: `U = ½CV² = 0.5 × ${c}×10⁻⁶ × ${v}² = ${uMicro}×10⁻⁶ J = ${ans}×10⁻³ J.`,
          steps: [
            `U = ½ C V²`,
            `V² = ${v}² = ${v * v}`,
            `U = 0.5 × ${c}×10⁻⁶ × ${v * v} = ${uMicro}×10⁻⁶ J`,
            `U = ${ans} ×10⁻³ J`,
          ],
        };
      },
    },
    {
      generate: (d) => {
        const c1 = randInt(2, 12);
        const c2 = randInt(2, 12);
        const series = d === 'hard' ? true : pick([true, false]);
        const ans = series ? round((c1 * c2) / (c1 + c2), 2) : round(c1 + c2, 2);
        const mode = series ? 'على التوالي' : 'على التوازي';
        const correct = `${ans} μF`;
        return {
          question: `مكثفان سعتاهما ${c1} μF و ${c2} μF. احسب السعة المكافئة عند توصيلهما ${mode}.`,
          ...makeNumericChoices(correct, generateWrongNumeric(ans, 'μF')),
          explanation: series
            ? `في التوالي: 1/C = 1/C₁ + 1/C₂ → C = C₁C₂/(C₁+C₂) = (${c1}×${c2})/(${c1}+${c2}) = ${ans} μF (أقل من أصغر سعة).`
            : `في التوازي تُجمع السعات: C = C₁ + C₂ = ${c1} + ${c2} = ${ans} μF.`,
          steps: series
            ? [
                `توالي المكثفات: 1/C = 1/C₁ + 1/C₂`,
                `C = (C₁ × C₂)/(C₁ + C₂)`,
                `C = (${c1} × ${c2}) / (${c1} + ${c2})`,
                `C = ${round(c1 * c2, 1)} / ${c1 + c2} = ${ans} μF`,
              ]
            : [
                `توازي المكثفات: C = C₁ + C₂`,
                `C = ${c1} + ${c2}`,
                `C = ${ans} μF`,
                `الجهد واحد على المكثفين والشحنة تتقسيم`,
              ],
        };
      },
    },
    {
      generate: () => {
        const area = randFloat(0.05, 0.5, 2);
        const dMm = pick([0.5, 1, 2]);
        const raw = 8.85e-12 * area / (dMm * 1e-3);
        const ans = round(raw / 1e-9, 3);
        const correct = `${ans} nF`;
        return {
          question: `مكثف هوائي لوحاه متوازيان مساحة كل لوح ${area} m² والمسافة بينهما ${dMm} mm. احسب سعته. (ε₀ = 8.85×10⁻¹² F/m)`,
          ...makeNumericChoices(correct, generateWrongNumeric(ans, 'nF')),
          explanation: `C = ε₀A/d = 8.85×10⁻¹² × ${area} / (${dMm}×10⁻³) = ${round(8.85 * area / dMm, 3)}×10⁻⁹ F = ${ans} nF.`,
          steps: [
            `d = ${dMm} mm = ${dMm}×10⁻³ m`,
            `C = ε₀ A / d`,
            `ε₀ A = 8.85×10⁻¹² × ${area} = ${round(8.85 * area, 3)}×10⁻¹²`,
            `C = ${round(8.85 * area, 3)}×10⁻¹² / (${dMm}×10⁻³) = ${round(8.85 * area / dMm, 3)}×10⁻⁹ F`,
            `C = ${ans} nF`,
          ],
        };
      },
    },
  ],

  // ============================ 28: التيار وقانون أوم ============================
  28: [
    {
      generate: (d) => {
        const q = randInt(6, 90);
        const t = randInt(2, 15);
        const ans = round(q / t, 2);
        const correct = `${ans} A`;
        return {
          question: d === 'easy'
            ? `شحنة ${q} C عبرت مقطع سلك في ${t} s. احسب شدة التيار.`
            : `عبرت شحنة كهربائية مقدارها ${q} C مقطعاً عرضياً في سلك خلال ${t} ثانية. احسب شدة التيار الكهربائي في السلك.`,
          ...makeNumericChoices(correct, generateWrongNumeric(ans, 'A')),
          explanation: `I = Q/t = ${q}/${t} = ${ans} A.`,
          steps: [
            `I = Q / t`,
            `I = ${q} / ${t}`,
            `I = ${ans} A`,
          ],
        };
      },
    },
    {
      generate: (d) => {
        const v = randInt(6, 240);
        const r = randInt(2, 60);
        const ans = round(v / r, 2);
        const correct = `${ans} A`;
        return {
          question: d === 'easy'
            ? `مقاومة ${r} Ω طبق عليها فرق جهد ${v} V. احسب شدة التيار.`
            : `على مقاومة قيمتها ${r} Ω طُبّق فرق جهد ${v} V عند ثبوت درجة الحرارة. احسب شدة التيار المار فيها وفق قانون أوم.`,
          ...makeNumericChoices(correct, generateWrongNumeric(ans, 'A')),
          explanation: `قانون أوم: I = V/R = ${v}/${r} = ${ans} A.`,
          steps: [
            `V = I R → I = V / R`,
            `I = ${v} / ${r}`,
            `I = ${ans} A`,
            `التحقق: V = I × R = ${ans} × ${r} ≈ ${v} V`,
          ],
        };
      },
    },
    {
      generate: () => {
        const i = randFloat(0.2, 3.2, 2);
        const t = randInt(1, 10);
        const n = i * t / 1.6e-19;
        const ans = round(n / 1e18, 2);
        const correct = `${ans} ×10¹⁸ إلكترون`;
        return {
          question: `سلك يمر فيه تيار شدته ${i} A لمدة ${t} ثوانٍ. احسب عدد الإلكترونات التي تعبر مقطعه خلال هذه المدة. (e = 1.6×10⁻¹⁹ C)`,
          ...makeNumericChoices(correct, generateWrongNumeric(ans, '×10¹⁸ إلكترون')),
          explanation: `Q = It = ${i}×${t} = ${round(i * t, 3)} C، ثم n = Q/e = ${round(i * t, 3)}/1.6×10⁻¹⁹ = ${ans}×10¹⁸ إلكترون.`,
          steps: [
            `Q = I × t = ${i} × ${t} = ${round(i * t, 3)} C`,
            `n = Q / e = ${round(i * t, 3)} / 1.6×10⁻¹⁹`,
            `n = ${round(i * t / 1.6, 3)} × 10¹⁹`,
            `n = ${ans} ×10¹⁸ إلكترون`,
          ],
        };
      },
    },
    {
      generate: (d) => {
        const v = pick([110, 220]);
        const i = randFloat(0.5, 5, 1);
        const ans = round(v / i, 1);
        const correct = `${ans} Ω`;
        return {
          question: d === 'easy'
            ? `جهاز على ${v} V ويسحب تياراً شدته ${i} A. احسب مقاومته.`
            : `جهاز كهربائي يعمل على فرق جهد ${v} V وشدة تيار ${i} A. احسب مقاومته المكافئة أثناء التشغيل، وبيّن لماذا تختلف هذه القيمة عن مقاومة الجهاز وهو بارد.`,
          ...makeNumericChoices(correct, generateWrongNumeric(ans, 'Ω')),
          explanation: `R = V/I = ${v}/${i} = ${ans} Ω.`,
          steps: [
            `R = V / I`,
            `R = ${v} / ${i}`,
            `R = ${ans} Ω`,
          ],
        };
      },
    },
    {
      generate: () => {
        const i = randInt(2, 10);
        const mins = randInt(2, 15);
        const secs = mins * 60;
        const ans = i * secs;
        const correct = `${ans} C`;
        return {
          question: `مر تيار شدته ${i} A في سلك لمدة ${mins} دقائق. احسب كمية الشحنة المارة في مقطعه.`,
          ...makeNumericChoices(correct, generateWrongNumeric(ans, 'C')),
          explanation: `Q = I t، مع تحويل الدقائق إلى ثوانٍ: t = ${mins}×60 = ${secs} s، فتكون Q = ${i}×${secs} = ${ans} C.`,
          steps: [
            `تحويل الزمن: t = ${mins} min × 60 = ${secs} s`,
            `Q = I × t`,
            `Q = ${i} × ${secs}`,
            `Q = ${ans} C`,
          ],
        };
      },
    },
  ],

  // ============================ 29: المقاومة النوعية ============================
  29: [
    {
      generate: (d) => {
        const rho = randFloat(1.2, 3, 2);
        const L = randInt(5, 50);
        const aMm = pick([0.5, 1, 2, 4]);
        const raw = rho * 1e-8 * L / (aMm * 1e-6);
        const ans = round(raw, 3);
        const correct = `${ans} Ω`;
        return {
          question: d === 'easy'
            ? `سلك طوله ${L} m ومساحة مقطعه ${aMm} mm² ومقاومة مادته النوعية ${rho}×10⁻⁸ Ω·m. احسب مقاومته.`
            : `سلك معدني طوله ${L} m ومساحة مقطعه العرضية ${aMm} mm²، ومقاومة مادته النوعية ${rho}×10⁻⁸ Ω·m. احسب مقاومة السلك. (1 mm² = 10⁻⁶ m²)`,
          ...makeNumericChoices(correct, generateWrongNumeric(ans, 'Ω')),
          explanation: `R = ρL/A = (${rho}×10⁻⁸ × ${L}) / (${aMm}×10⁻⁶) = ${ans} Ω.`,
          steps: [
            `A = ${aMm} mm² = ${aMm}×10⁻⁶ m²`,
            `R = ρ L / A`,
            `ρL = ${rho}×10⁻⁸ × ${L} = ${round(rho * L, 3)}×10⁻⁸`,
            `R = ${round(rho * L, 3)}×10⁻⁸ / (${aMm}×10⁻⁶) = ${ans} Ω`,
          ],
        };
      },
    },
    {
      generate: () => {
        const R = randFloat(0.5, 10, 1);
        const aMm = pick([0.5, 1, 2]);
        const L = randInt(5, 50);
        const raw = R * aMm * 1e-6 / L;
        const ans = round(raw * 1e8, 2);
        const correct = `${ans} ×10⁻⁸ Ω·m`;
        return {
          question: `سلك طوله ${L} m ومساحة مقطعه ${aMm} mm² وقاست مقاومته ${R} Ω. احسب المقاومة النوعية لمادة السلك.`,
          ...makeNumericChoices(correct, generateWrongNumeric(ans, '×10⁻⁸ Ω·m')),
          explanation: `ρ = RA/L = ${R} × ${aMm}×10⁻⁶ / ${L} = ${ans}×10⁻⁸ Ω·m.`,
          steps: [
            `ρ = R A / L`,
            `R × A = ${R} × ${aMm}×10⁻⁶ = ${round(R * aMm, 3)}×10⁻⁶`,
            `ρ = ${round(R * aMm, 3)}×10⁻⁶ / ${L}`,
            `ρ = ${ans} ×10⁻⁸ Ω·m`,
          ],
        };
      },
    },
    {
      generate: (d) => {
        const R = randInt(4, 30);
        const n = pick([2, 3]);
        const ans = round(R * n * n, 1);
        const correct = `${ans} Ω`;
        return {
          question: d === 'easy'
            ? `سلك مقاومته ${R} Ω. طُوّل حتى صار طوله ${n} ضعف مع ثبات حجمه. احسب مقاومته الجديدة.`
            : `سلك معدني مقاومته ${R} Ω. سُحب (طُوّل) بحيث أصبح طوله ${n} ضعف طوله الأصلي مع بقاء حجمه ثابتاً. احسب مقاومته الجديدة وفسر السبب بدلالة الطول ومساحة المقطع.`,
          ...makeNumericChoices(correct, generateWrongNumeric(ans, 'Ω')),
          explanation: `ثبات الحجم مع مضاعفة الطول ${n} مرات يعني أن المساحة صارت 1/${n}، فتصبح R₂ = ${n}×${n} × R = ${ans} Ω.`,
          steps: [
            `الحجم ثابت: L₂ = ${n}L₁ → A₂ = A₁/${n}`,
            `R₂ = ρ L₂/A₂ = ρ (${n}L₁)/(A₁/${n}) = ${n * n} × ρL₁/A₁`,
            `R₂ = ${n * n} × R₁`,
            `R₂ = ${n * n} × ${R} = ${ans} Ω`,
          ],
        };
      },
    },
    {
      generate: () => {
        const i = randFloat(0.4, 6.4, 2);
        const aMm = randFloat(0.5, 4, 2);
        const ans = round(i / aMm, 2);
        const correct = `${ans} ×10⁶ A/m²`;
        return {
          question: `تيار شدته ${i} A يمر في موصل مساحة مقطعه ${aMm} mm². احسب كثافة التيار في الموصل.`,
          ...makeNumericChoices(correct, generateWrongNumeric(ans, '×10⁶ A/m²')),
          explanation: `J = I/A = ${i} / (${aMm}×10⁻⁶) = ${ans}×10⁶ A/m².`,
          steps: [
            `A = ${aMm} mm² = ${aMm}×10⁻⁶ m²`,
            `J = I / A = ${i} / (${aMm}×10⁻⁶)`,
            `J = (${i} / ${aMm}) × 10⁶`,
            `J = ${ans} ×10⁶ A/m²`,
          ],
        };
      },
    },
    {
      generate: (d) => {
        const R = randInt(2, 8);
        const aMm = pick([1, 2]);
        const rho = randFloat(1.7, 2.8, 1);
        const raw = R * aMm * 1e-6 / (rho * 1e-8);
        const ans = round(raw, 1);
        const correct = `${ans} m`;
        return {
          question: d === 'easy'
            ? `مادة مقاومتها النوعية ${rho}×10⁻⁸ Ω·m. ما طول سلك مساحة مقطعه ${aMm} mm² ليعطي مقاومة ${R} Ω؟`
            : `يلزمك صناعة مقاومة قيمتها ${R} Ω من سلك مادته ذات المقاومة النوعية ${rho}×10⁻⁸ Ω·m ومساحة مقطعه ${aMm} mm². احسب طول السلك اللازم.`,
          ...makeNumericChoices(correct, generateWrongNumeric(ans, 'm')),
          explanation: `L = RA/ρ = (${R} × ${aMm}×10⁻⁶) / (${rho}×10⁻⁸) = ${ans} m.`,
          steps: [
            `من R = ρL/A → L = R A / ρ`,
            `A = ${aMm} mm² = ${aMm}×10⁻⁶ m²`,
            `R × A = ${R} × ${aMm}×10⁻⁶ = ${round(R * aMm, 3)}×10⁻⁶`,
            `L = ${round(R * aMm, 3)}×10⁻⁶ / (${rho}×10⁻⁸) = ${ans} m`,
          ],
        };
      },
    },
  ],

  // ============================ 30: الطاقة والقدرة وتأثير جول ============================
  30: [
    {
      generate: (d) => {
        const v = pick([12, 24, 110, 220]);
        const i = randFloat(0.5, 5, 1);
        const ans = round(v * i, 1);
        const correct = `${ans} W`;
        return {
          question: d === 'easy'
            ? `جهاز على ${v} V ويسحب تياراً ${i} A. احسب قدرته.`
            : `جهاز كهربائي يعمل على فرق جهد ${v} V وشدّة تياره ${i} A. احسب القدرة الكهربائية المستهلكة، ثم بيّن كيف تتغير لو ضاعفت فرق الجهد مع ثبوت المقاومة.`,
          ...makeNumericChoices(correct, generateWrongNumeric(ans, 'W')),
          explanation: `P = V I = ${v} × ${i} = ${ans} W.`,
          steps: [
            `P = V × I`,
            `P = ${v} × ${i}`,
            `P = ${ans} W`,
            `= ${round(ans / 1000, 3)} kW`,
          ],
        };
      },
    },
    {
      generate: () => {
        const i = randFloat(1, 5, 1);
        const r = randInt(5, 50);
        const ans = round(i * i * r, 2);
        const correct = `${ans} W`;
        return {
          question: `مقاومة قيمتها ${r} Ω يمر فيها تيار شدته ${i} A. احسب القدرة المبددة فيها على صورة حرارة.`,
          ...makeNumericChoices(correct, generateWrongNumeric(ans, 'W')),
          explanation: `P = I²R = ${i}² × ${r} = ${round(i * i, 3)} × ${r} = ${ans} W.`,
          steps: [
            `P = I² × R`,
            `I² = (${i})² = ${round(i * i, 3)}`,
            `P = ${round(i * i, 3)} × ${r}`,
            `P = ${ans} W`,
          ],
        };
      },
    },
    {
      generate: (d) => {
        const p = randInt(100, 2000);
        const h = randInt(2, 12);
        const kwh = round(p * h / 1000, 2);
        const joule = round((kwh * 3.6e6) / 1e6, 2);
        const correct = `${kwh} kWh`;
        return {
          question: d === 'easy'
            ? `جهاز قدرته ${p} W عمل لمدة ${h} ساعات. احسب الطاقة المستهلكة بوحدة كيلوواط ساعة.`
            : `درجة إنارة قدرتها ${p} W أبقيت مضاءة ${h} ساعات يومياً. احسب الطاقة المستهلكة بوحدة الكيلوواط ساعة، وبالجول. (1 kWh = 3.6×10⁶ J)`,
          ...makeNumericChoices(correct, generateWrongNumeric(kwh, 'kWh')),
          explanation: `E = P × t = ${p}/1000 kW × ${h} h = ${kwh} kWh = ${joule}×10⁶ J.`,
          steps: [
            `تحويل القدرة: P = ${p} W = ${round(p / 1000, 3)} kW`,
            `E = P × t = ${round(p / 1000, 3)} × ${h}`,
            `E = ${kwh} kWh`,
            `بالجول: E = ${kwh} × 3.6×10⁶ = ${joule} ×10⁶ J`,
          ],
        };
      },
    },
    {
      generate: () => {
        const i = randInt(2, 6);
        const r = randInt(5, 30);
        const t = randInt(10, 120);
        const ans = i * i * r * t;
        const correct = `${ans} J`;
        return {
          question: `تيار شدته ${i} A مر في مقاومة ${r} Ω لمدة ${t} ثانية. احسب كمية الحرارة الناتجة وفق تأثير جول.`,
          ...makeNumericChoices(correct, generateWrongNumeric(ans, 'J')),
          explanation: `H = I²Rt = ${i}² × ${r} × ${t} = ${ans} J.`,
          steps: [
            `H = I² × R × t`,
            `I² = ${i}² = ${i * i}`,
            `I²R = ${i * i} × ${r} = ${i * i * r} W`,
            `H = ${i * i * r} × ${t} = ${ans} J`,
          ],
        };
      },
    },
    {
      generate: (d) => {
        const { value: g, context } = gravity();
        const m = randInt(2, 20);
        const h = randInt(2, 20);
        const t = randInt(5, 40);
        const v = pick([24, 110, 220]);
        const work = round(m * g * h, 2);
        const p = round(work / t, 2);
        const ans = round(p / v, 3);
        const correct = `${ans} A`;
        return {
          question: d === 'easy'
            ? `محرك كهربائي يعمل على ${v} V يرفع كتلة ${m} kg ارتفاع ${h} m في ${t} s ${context}. احسب شدة التيار بافتراض كفاءة 100%.`
            : `رافعة كهربائية قدرتها المثلى موصلة على فرق جهد ${v} V، ترفع حملاً كتلته ${m} kg إلى ارتفاع ${h} m في زمن ${t} s ${context} بافتراض أن الطاقة الكهربائية كلها تتحول إلى شغل ميكانيكي. احسب شدة التيار في المحرك. (خذ g = ${g} m/s²)`,
          ...makeNumericChoices(correct, generateWrongNumeric(ans, 'A')),
          explanation: `W = mgh = ${m}×${g}×${h} = ${work} J، P = W/t = ${work}/${t} = ${p} W، ثم I = P/V = ${p}/${v} = ${ans} A.`,
          steps: [
            `الشغل الميكانيكي: W = m × g × h = ${m} × ${g} × ${h} = ${work} J`,
            `القدرة: P = W / t = ${work} / ${t} = ${p} W`,
            `القدرة الكهربائية: P = V I → I = P / V`,
            `I = ${p} / ${v} = ${ans} A`,
          ],
        };
      },
    },
  ],

  // ============================ 31: دوائر التيار المستمر ============================
  31: [
    {
      generate: (d) => {
        const r1 = randInt(2, 20);
        const r2 = randInt(2, 20);
        const eq = r1 + r2;
        const v = pick([12, 20, 24, 40, 60, 120]);
        const ans = round(v / eq, 2);
        const correct = `${ans} A`;
        return {
          question: d === 'easy'
            ? `مقاومتان ${r1} Ω و ${r2} Ω على التوالي مع مصدر ${v} V. احسب التيار.`
            : `مقاومتان قيمتاهما ${r1} Ω و ${r2} Ω وُصلتا على التوالي مع مصدر فرق جهد ${v} V مهمل المقاومة الداخلية. احسب شدة التيار في الدائرة وفرق الجهد على كل مقاومة.`,
          ...makeNumericChoices(correct, generateWrongNumeric(ans, 'A')),
          explanation: `R_eq = ${r1} + ${r2} = ${eq} Ω، والتيار I = V/R = ${v}/${eq} = ${ans} A يمر في المقاومتين معاً.`,
          steps: [
            `التوالي: R_eq = R₁ + R₂ = ${r1} + ${r2} = ${eq} Ω`,
            `I = V / R_eq = ${v} / ${eq}`,
            `I = ${ans} A`,
            `V₁ = I R₁ = ${ans} × ${r1} = ${round(ans * r1, 2)} V`,
            `V₂ = I R₂ = ${ans} × ${r2} = ${round(ans * r2, 2)} V`,
          ],
        };
      },
    },
    {
      generate: () => {
        const r1 = randInt(3, 20);
        const r2 = randInt(3, 20);
        const eq = round((r1 * r2) / (r1 + r2), 2);
        const v = pick([12, 20, 24, 40]);
        const ans = round(v / eq, 1);
        const correct = `${ans} A`;
        return {
          question: `مقاومتان ${r1} Ω و ${r2} Ω على التوازي مع مصدر ${v} V. احسب شدة التيار الكلي المسحوب من المصدر.`,
          ...makeNumericChoices(correct, generateWrongNumeric(ans, 'A')),
          explanation: `R_eq = R₁R₂/(R₁+R₂) = (${r1}×${r2})/(${r1}+${r2}) = ${eq} Ω، إذن I = ${v}/${eq} = ${ans} A.`,
          steps: [
            `التوازي: R_eq = (R₁ × R₂)/(R₁ + R₂)`,
            `R_eq = (${r1} × ${r2}) / (${r1} + ${r2}) = ${round(r1 * r2, 1)} / ${r1 + r2} = ${eq} Ω`,
            `I = V / R_eq = ${v} / ${eq}`,
            `I = ${ans} A`,
            `تيار الفرعين: ${round(v / r1, 2)} A و ${round(v / r2, 2)} A`,
          ],
        };
      },
    },
    {
      generate: (d) => {
        const rp = pick([4, 6, 8, 10, 12]);
        const rs = randInt(2, 10);
        const eq = round(rp / 2 + rs, 2);
        const v = pick([12, 24, 40, 60]);
        const ans = round(v / eq, 2);
        const correct = `${ans} A`;
        return {
          question: `مقاومتان كلتاهما ${rp} Ω على التوازي، ووُصل هذا التركيب على التوالي مع مقاومة ${rs} Ω، ثم إلى مصدر ${v} V. احسب التيار الكلي.`,
          ...makeNumericChoices(correct, generateWrongNumeric(ans, 'A')),
          explanation: `التوازي يعطي ${rp}/2 = ${rp / 2} Ω، فالمكافئة الكلية ${rp / 2} + ${rs} = ${eq} Ω، والتيار I = ${v}/${eq} = ${ans} A.`,
          steps: [
            `متوازيتان متماثلتان: R_p = ${rp}/2 = ${rp / 2} Ω`,
            `المكافئة الكلية = R_p + R_s = ${rp / 2} + ${rs} = ${eq} Ω`,
            `I = V / R = ${v} / ${eq}`,
            `I = ${ans} A`,
            d === 'hard' ? `التيار يتقسم بالتساوي في الفرعين: ${round(ans / 2, 2)} A لكل فرع` : `الجهد على الجزء المتوازي = ${ans} × ${rp / 2} = ${round(ans * rp / 2, 2)} V`,
          ],
        };
      },
    },
    {
      generate: () => {
        const e = randInt(6, 24);
        const rIn = pick([0.5, 1, 2]);
        const rOut = randInt(2, 20);
        const current = round(e / (rOut + rIn), 3);
        const drop = round(current * rIn, 2);
        const ans = round(e - drop, 2);
        const correct = `${ans} V`;
        return {
          question: `بطارية قوتها الدافعة الكهربائية ${e} V ومقاومتها الداخلية ${rIn} Ω، وُصلت بمقاومة خارجية ${rOut} Ω. احسب فرق الجهد بين قطبيها عند سحب التيار.`,
          ...makeNumericChoices(correct, generateWrongNumeric(ans, 'V')),
          explanation: `I = E/(R + r) = ${e}/(${rOut} + ${rIn}) = ${current} A، ثم V = E - Ir = ${e} - ${drop} = ${ans} V.`,
          steps: [
            `I = E / (R + r) = ${e} / (${rOut} + ${rIn}) = ${current} A`,
            `الهبوط الداخلي = I r = ${current} × ${rIn} = ${drop} V`,
            `V = E - I r = ${e} - ${drop}`,
            `V = ${ans} V`,
          ],
        };
      },
    },
    {
      generate: (d) => {
        const r1 = randInt(5, 20);
        const r2 = randInt(5, 20);
        const r3 = randInt(5, 30);
        const eq = r1 + r2 + r3;
        const v = pick([12, 24, 30, 60, 120]);
        const current = round(v / eq, 3);
        const ans = round(current * r3, 2);
        const correct = `${ans} V`;
        return {
          question: d === 'easy'
            ? `ثلاث مقاومات ${r1} Ω و ${r2} Ω و ${r3} Ω على التوالي مع مصدر ${v} V. احسب فرق الجهد على المقاومة الثالثة.`
            : `دائرة التيار المستمر تحتوي على ثلاث مقاومات على التوالي قيمها ${r1} Ω و ${r2} Ω و ${r3} Ω موصولة بمصدر ${v} V. احسب فرق الجهد على المقاومة ${r3} Ω وبيّن لماذا تكون أكبرها جهداً.`,
          ...makeNumericChoices(correct, generateWrongNumeric(ans, 'V')),
          explanation: `R_eq = ${r1} + ${r2} + ${r3} = ${eq} Ω، I = ${v}/${eq} = ${current} A، إذن V₃ = I × ${r3} = ${ans} V.`,
          steps: [
            `R_eq = ${r1} + ${r2} + ${r3} = ${eq} Ω`,
            `I = V / R_eq = ${v} / ${eq} = ${current} A`,
            `V₃ = I × R₃ = ${current} × ${r3}`,
            `V₃ = ${ans} V`,
          ],
        };
      },
    },
  ],

  // ============================ 32: المجال المغناطيسي وقوة لورنتز ============================
  32: [
    {
      generate: (d) => {
        const b = randFloat(0.1, 0.9, 2);
        const i = randInt(2, 10);
        const len = randFloat(0.1, 0.6, 2);
        const ans = round(b * i * len, 3);
        const correct = `${ans} N`;
        return {
          question: d === 'easy'
            ? `موصل طوله ${len} m يمر فيه تيار ${i} A عمودياً على مجال ${b} T. احسب القوة.`
            : `موصل مستقيم طوله ${len} m يمر فيه تيار ${i} A وُضع عمودياً على خطوط مجال مغناطيسي منتظم شدته ${b} T. احسب مقدار القوة المغناطيسية المؤثرة عليه وحدد اتجاهها بقاعدة اليد.`,
          ...makeNumericChoices(correct, generateWrongNumeric(ans, 'N')),
          explanation: `F = B I L sin 90° = ${b} × ${i} × ${len} = ${ans} N.`,
          steps: [
            `الموصل عمودي على المجال → sin θ = 1`,
            `F = B × I × L`,
            `F = ${b} × ${i} × ${len}`,
            `F = ${ans} N`,
          ],
        };
      },
    },
    {
      generate: () => {
        const b = randFloat(0.2, 0.8, 2);
        const i = randInt(2, 8);
        const len = randFloat(0.2, 0.5, 2);
        const angle = pick([30, 60, 90]);
        const sinV = round(Math.sin((angle * Math.PI) / 180), 3);
        const bil = round(b * i * len, 3);
        const ans = round(bil * sinV, 3);
        const correct = `${ans} N`;
        return {
          question: `موصل طوله ${len} m شدّة تياره ${i} A يصنع زاوية ${angle}° مع مجال مغناطيسي شدته ${b} T. احسب القوة المؤثرة على الموصل.`,
          ...makeNumericChoices(correct, generateWrongNumeric(ans, 'N')),
          explanation: `F = B I L sin θ = ${b} × ${i} × ${len} × ${sinV} = ${ans} N، لأن المركبة العمودية على المجال هي الفاعلة فقط.`,
          steps: [
            `sin ${angle}° = ${sinV}`,
            `F = B I L sin θ`,
            `F = ${b} × ${i} × ${len} × ${sinV}`,
            `B I L = ${b} × ${i} × ${len} = ${bil}`,
            `F = ${bil} × ${sinV} = ${ans} N`,
          ],
        };
      },
    },
    {
      generate: (d) => {
        const v = randInt(2, 9);
        const b = randFloat(0.2, 0.9, 2);
        const ans = round(1.6 * v * b, 2);
        const correct = `${ans} ×10⁻¹³ N`;
        return {
          question: d === 'easy'
            ? `إلكترون شحنته 1.6×10⁻¹⁹ C يتحرك بسرعة ${v}×10⁶ m/s عمودياً على مجال ${b} T. احسب القوة.`
            : `إلكترون (e = 1.6×10⁻¹⁹ C) يدخل مجالاً مغناطيسياً منتظماً شدته ${b} T بسرعة ${v}×10⁶ m/s في اتجاه عمودي على خطوط المجال. احسب قوة لورنتز المؤثرة عليه، وبيّن لماذا لا تتغير سرعته.`,
          ...makeNumericChoices(correct, generateWrongNumeric(ans, '×10⁻¹³ N')),
          explanation: `F = B e v = ${b} × 1.6×10⁻¹⁹ × ${v}×10⁶ = ${ans}×10⁻¹³ N، وهي عمودية على السرعة فلا تبذل شغلاً.`,
          steps: [
            `v = ${v}×10⁶ m/s، θ = 90° → sin θ = 1`,
            `F = B e v`,
            `F = ${b} × 1.6 × ${v} × 10⁻¹³`,
            `F = ${ans} ×10⁻¹³ N`,
          ],
        };
      },
    },
    {
      generate: () => {
        const v = randInt(2, 9);
        const b = pick([0.2, 0.4, 0.5, 0.8]);
        const raw = (9e-31 * v * 1e6) / (1.6e-19 * b);
        const ans = round(raw / 1e-6, 2);
        const correct = `${ans} μm`;
        return {
          question: `إلكترون (m = 9×10⁻³¹ kg، e = 1.6×10⁻¹⁹ C) يتحرك بسرعة ${v}×10⁶ m/s عمودياً على مجال مغناطيسي ${b} T. احسب نصف قطر المسار الدائري.`,
          ...makeNumericChoices(correct, generateWrongNumeric(ans, 'μm')),
          explanation: `القوة المغناطيسية توفر القوة المركزية: r = mv/(Be) = (9×10⁻³¹ × ${v}×10⁶)/(${b} × 1.6×10⁻¹⁹) = ${ans}×10⁻⁶ m = ${ans} μm.`,
          steps: [
            `r = m v / (B e)`,
            `m v = 9×10⁻³¹ × ${v}×10⁶ = ${round(9 * v, 2)}×10⁻²⁵`,
            `B e = ${b} × 1.6×10⁻¹⁹ = ${round(b * 1.6, 3)}×10⁻¹⁹`,
            `r = ${round(9 * v, 2)}×10⁻²⁵ / (${round(b * 1.6, 3)}×10⁻¹⁹) = ${ans} ×10⁻⁶ m`,
            `r = ${ans} μm`,
          ],
        };
      },
    },
    {
      generate: (d) => {
        const n = randInt(20, 200);
        const i = randFloat(0.2, 2, 1);
        const area = randFloat(0.01, 0.05, 3);
        const b = randFloat(0.1, 0.8, 2);
        const ni = round(n * i, 2);
        const ans = round(ni * area * b, 3);
        const correct = `${ans} N·m`;
        return {
          question: d === 'easy'
            ? `ملف من ${n} لفة مساحتها ${area} m² يحمل تيار ${i} A في مجال ${b} T. احسب أقصى عزم دوران.`
            : `ملف مستطيل من ${n} لفة، مساحة كل لفة ${area} m²، يمر فيه تيار ${i} A ووُضع في مجال مغناطيسي ${b} T بحيث يكون مستواه موازياً للمجال. احسب أقصى عزم دوران مؤثر على الملف.`,
          ...makeNumericChoices(correct, generateWrongNumeric(ans, 'N·m')),
          explanation: `τ = N I A B sin θ = ${n} × ${i} × ${area} × ${b} (و sin θ = 1 عند المستوى الموازي للمجال) = ${ans} N·m.`,
          steps: [
            `العزم أقصى عندما يكون مستوى الملف موازياً للمجال → sin θ = 1`,
            `τ = N I A B`,
            `N I = ${n} × ${i} = ${ni}`,
            `τ = ${ni} × ${area} × ${b}`,
            `τ = ${ans} N·m`,
          ],
        };
      },
    },
    {
      generate: () => {
        const eK = randInt(2, 9);
        const b = pick([0.2, 0.4, 0.5]);
        const ans = round(eK / b, 2);
        const correct = `${ans} ×10⁴ m/s`;
        return {
          question: `في مُنتقي السرعات يقَع مجال كهربائي شدته ${eK}×10⁴ V/m عمودياً على مجال مغناطيسي ${b} T. احسب سرعة الشحنة التي تعبر بلا انحراف.`,
          ...makeNumericChoices(correct, generateWrongNumeric(ans, '×10⁴ m/s')),
          explanation: `عند الانحراف المعدوم: qE = qvB → v = E/B = ${eK}×10⁴/${b} = ${ans}×10⁴ m/s.`,
          steps: [
            `القوة الكهربائية = القوة المغناطيسية: q E = q v B`,
            `v = E / B`,
            `v = ${eK}×10⁴ / ${b}`,
            `v = ${ans} ×10⁴ m/s`,
          ],
        };
      },
    },
  ],

  // ============================ 33: الحث الكهرومغناطيسي ============================
  33: [
    {
      generate: (d) => {
        const b = randFloat(0.1, 0.9, 2);
        const area = pick([0.01, 0.02, 0.05, 0.1]);
        const angle = pick([0, 30, 60]);
        const cosV = round(Math.cos((angle * Math.PI) / 180), 3);
        const ba = round(b * area, 5);
        const raw = ba * cosV;
        const ans = round(raw * 1000, 2);
        const correct = `${ans} ×10⁻³ Wb`;
        return {
          question: d === 'easy'
            ? `سطح مساحته ${area} m² في مجال ${b} T، والزاوية بين المجال والعمود على السطح ${angle}°. احسب الفيض المغناطيسي.`
            : `ملف مساحته ${area} m² مغمور في مجال مغناطيسي منتظم شدته ${b} T، ويصنع اتجاه المجال زاوية ${angle}° مع العمود على مستوى الملف. احسب الفيض المغناطيسي المار خلال الملف.`,
          ...makeNumericChoices(correct, generateWrongNumeric(ans, '×10⁻³ Wb')),
          explanation: `Φ = B A cos θ = ${b} × ${area} × ${cosV} = ${round(raw, 6)} Wb = ${ans}×10⁻³ Wb.`,
          steps: [
            `cos ${angle}° = ${cosV}`,
            `Φ = B A cos θ`,
            `B A = ${b} × ${area} = ${ba}`,
            `Φ = ${ba} × ${cosV} = ${round(raw, 6)} Wb`,
            `Φ = ${ans} ×10⁻³ Wb`,
          ],
        };
      },
    },
    {
      generate: (d) => {
        const n = randInt(50, 500);
        const dphi = randFloat(0.01, 0.1, 3);
        const t = randFloat(0.1, 0.5, 2);
        const nDelta = round(n * dphi, 2);
        const ans = round(nDelta / t, 2);
        const correct = `${ans} V`;
        return {
          question: d === 'easy'
            ? `ملف من ${n} لفة تغير الفيض خلاله بمقدار ${dphi} Wb في ${t} s. احسب القوة الدافعة المستحثة.`
            : `مغناطيس أُدخل في ملف مكوّن من ${n} لفة فتغير الفيض المغناطيسي المار خلاله بمقدار ${dphi} Wb خلال زمن ${t} s. احسب مقدار القوة الدافعة الكهربائية المستحثة، واذكر ما يحدده قانون لنتز.`,
          ...makeNumericChoices(correct, generateWrongNumeric(ans, 'V')),
          explanation: `ε = N ΔΦ/Δt = ${n} × ${dphi}/${t} = ${ans} V، ويحدد لنتز اتجاهها بأنها تعارض التغير المسبب.`,
          steps: [
            `قانون فاراديه: ε = N ΔΦ / Δt`,
            `N ΔΦ = ${n} × ${dphi} = ${nDelta} Wb`,
            `ε = ${nDelta} / ${t}`,
            `ε = ${ans} V`,
          ],
        };
      },
    },
    {
      generate: () => {
        const b = randFloat(0.2, 0.8, 2);
        const len = randFloat(0.2, 1, 2);
        const v = randInt(2, 20);
        const ans = round(b * len * v, 2);
        const correct = `${ans} V`;
        return {
          question: `موصل طوله ${len} m يتحرك بسرعة ${v} m/s في اتجاه عمودي على نفسه وعمودي على مجال مغناطيسي شدته ${b} T. احسب القوة الدافعة المستحثة بين طرفيه.`,
          ...makeNumericChoices(correct, generateWrongNumeric(ans, 'V')),
          explanation: `ε = B L v = ${b} × ${len} × ${v} = ${ans} V، وهي أقصى قيمة لأن الحركة عمودية على المجال.`,
          steps: [
            `الحركة عمودية على المجال → sin θ = 1`,
            `ε = B L v`,
            `ε = ${b} × ${len} × ${v}`,
            `ε = ${ans} V`,
          ],
        };
      },
    },
    {
      generate: (d) => {
        const n = randInt(20, 200);
        const b = randFloat(0.2, 0.8, 2);
        const area = pick([0.02, 0.05, 0.1]);
        const t = randFloat(0.1, 0.5, 2);
        const phi1 = round(b * area, 4);
        const phi2 = round(b * area * 0.5, 4);
        const dphi = round(phi1 - phi2, 4);
        const ans = round(n * dphi / t, 2);
        const correct = `${ans} V`;
        return {
          question: `ملف من ${n} لفة مساحة كل لفة ${area} m² في مجال ${b} T، دُوّر محوره من الوضع الذي يكون فيه مستوى الملف عمودياً على المجال (θ = 0°) إلى الوضع الذي يميل فيه العمود على مستوى الملف بزاوية 60° عن اتجاه المجال، وذلك خلال ${t} s. احسب القوة الدافعة المستحثة.`,
          ...makeNumericChoices(correct, generateWrongNumeric(ans, 'V')),
          explanation: `Φ₁ = BA cos 0° = ${phi1} Wb، و Φ₂ = BA cos 60° = ${phi2} Wb، فالقوة الدافعة ε = NΔΦ/Δt = ${n}×${dphi}/${t} = ${ans} V.`,
          steps: [
            `Φ₁ = B A cos 0° = ${b} × ${area} × 1 = ${phi1} Wb`,
            `Φ₂ = B A cos 60° = ${b} × ${area} × 0.5 = ${phi2} Wb`,
            `ΔΦ = ${phi1} - ${phi2} = ${dphi} Wb`,
            d === 'hard' ? `معدل تغير الفيض = ΔΦ/Δt = ${dphi}/${t} = ${round(dphi / t, 4)} Wb/s` : `ε = N ΔΦ / Δt = ${n} × ${dphi} / ${t}`,
            `ε = ${ans} V`,
          ],
        };
      },
    },
    {
      generate: () => {
        const n = randInt(50, 300);
        const b = randFloat(0.1, 0.6, 2);
        const area = pick([0.01, 0.02, 0.05]);
        const omega = randInt(10, 100);
        const nb = round(n * b, 2);
        const nba = round(nb * area, 4);
        const ans = round(nba * omega, 2);
        const correct = `${ans} V`;
        return {
          question: `دينامو بسيط: ملف من ${n} لفة مساحة ${area} m² يدور بتردد زاوي ${omega} rad/s داخل مجال مغناطيسي ${b} T. احسب أقصى قوة دافعة مستحثة.`,
          ...makeNumericChoices(correct, generateWrongNumeric(ans, 'V')),
          explanation: `ε_max = N B A ω = ${n} × ${b} × ${area} × ${omega} = ${ans} V، وتُعطى القيمة اللحظية بـ ε = ε_max sin ωt.`,
          steps: [
            `ε_max = N B A ω`,
            `N B = ${n} × ${b} = ${nb}`,
            `N B A = ${nb} × ${area} = ${nba}`,
            `ε_max = ${nba} × ${omega}`,
            `ε_max = ${ans} V`,
          ],
        };
      },
    },
  ],

  // ============================ 34: التيار المتردد والمحول ============================
  34: [
    {
      generate: (d) => {
        const vmax = randInt(150, 400);
        const ans = round(vmax / 1.414, 1);
        const correct = `${ans} V`;
        return {
          question: d === 'easy'
            ? `جهد متردد قيمته العظمى ${vmax} V. احسب قيمته الفعالة.`
            : `مصدر متردد يعطي جهداً قيمته العظمى ${vmax} V. احسب القيمة الفعالة للجهد التي يقرؤها فولتميتر عادي، وبيّن المعنى الفيزيائي للقيمة الفعالة. (√2 ≈ 1.414)`,
          ...makeNumericChoices(correct, generateWrongNumeric(ans, 'V')),
          explanation: `V_rms = V_max/√2 = ${vmax}/1.414 = ${ans} V، وهي القيمة التي تعطي الأثر الحراري نفسه لتيار مستمر.`,
          steps: [
            `V_rms = V_max / √2`,
            `V_rms = ${vmax} / 1.414`,
            `V_rms = ${ans} V`,
            `ملاحظة: القيمة الفعالة ≈ 0.707 من القيمة العظمى`,
          ],
        };
      },
    },
    {
      generate: (d) => {
        const np = randInt(4, 20) * 100;
        const ns = randInt(1, 3) * 100;
        const vp = pick([110, 220]);
        const ans = round(vp * ns / np, 1);
        const correct = `${ans} V`;
        return {
          question: `محول خافض ملفه الأولي ${np} لفة والثانوي ${ns} لفة، وُصل الأولي بجهد ${vp} V. احسب جهد الخرج بافتراض مثالية المحول.`,
          ...makeNumericChoices(correct, generateWrongNumeric(ans, 'V')),
          explanation: `V_s = V_p × (N_s/N_p) = ${vp} × (${ns}/${np}) = ${ans} V، فهو خافض لأن لفات الثانوي أقل.`,
          steps: [
            `V_p / V_s = N_p / N_s → V_s = V_p × N_s / N_p`,
            `V_s = ${vp} × ${ns} / ${np}`,
            `V_s = ${round(vp * ns, 1)} / ${np}`,
            `V_s = ${ans} V`,
            d === 'hard' ? `نسبة التحويل = N_s/N_p = ${round(ns / np, 3)}` : `النوع: خافض للجهد (N_s < N_p)`,
          ],
        };
      },
    },
    {
      generate: () => {
        const np = randInt(1, 5) * 100;
        const ns = randInt(6, 20) * 100;
        const vp = pick([110, 220]);
        const ans = round(vp * ns / np, 1);
        const correct = `${ans} V`;
        return {
          question: `محول رافع عدد لفات ملفيه ${np} و ${ns} بالترتيب (الأولي ثم الثانوي)، وجهد دخوله ${vp} V. احسب جهد الخرج.`,
          ...makeNumericChoices(correct, generateWrongNumeric(ans, 'V')),
          explanation: `V_s = V_p × (N_s/N_p) = ${vp} × (${ns}/${np}) = ${ans} V، ويزداد الجهد بزيادة لفات الثانوي.`,
          steps: [
            `V_s = V_p × N_s / N_p`,
            `V_s = ${vp} × ${ns} / ${np}`,
            `V_s = ${round(vp * ns, 1)} / ${np}`,
            `V_s = ${ans} V`,
          ],
        };
      },
    },
    {
      generate: (d) => {
        const vp = pick([110, 220]);
        const vs = pick([12, 24, 44, 110]);
        const is = randFloat(1, 10, 1);
        const ans = round(vs * is / vp, 2);
        const correct = `${ans} A`;
        return {
          question: d === 'easy'
            ? `محول جهده ${vp} V في الأولي و${vs} V في الثانوي، وشِدّة تيار الثانوي ${is} A. احسب تيار الملف الأولي.`
            : `في محول مثالي جهد الملف الأولي ${vp} V وجهد الثانوي ${vs} V، ويسحب الحمل من الثانوي تياراً شدته ${is} A. احسب شدة التيار في الملف الأولي، وفسر العلاقة بين الجهد والتيار.`,
          ...makeNumericChoices(correct, generateWrongNumeric(ans, 'A')),
          explanation: `في المحول المثالي القدرة الداخلة = الخارجة: V_p I_p = V_s I_s → I_p = ${vs}×${is}/${vp} = ${ans} A.`,
          steps: [
            `V_p I_p = V_s I_s`,
            `I_p = V_s × I_s / V_p`,
            `I_p = ${vs} × ${is} / ${vp} = ${round(vs * is, 2)} / ${vp}`,
            `I_p = ${ans} A`,
          ],
        };
      },
    },
    {
      generate: () => {
        const period = pick([0.02, 0.04, 0.05, 0.1]);
        const ans = round(1 / period, 1);
        const correct = `${ans} Hz`;
        return {
          question: `تيار متردد الزمن الدوري لدورته الكاملة ${period} s. احسب تردد التيار.`,
          ...makeNumericChoices(correct, generateWrongNumeric(ans, 'Hz')),
          explanation: `f = 1/T = 1/${period} = ${ans} Hz، فكلما قلّ الزمن الدوري زاد التردد.`,
          steps: [
            `f = 1 / T`,
            `f = 1 / ${period}`,
            `f = ${ans} Hz`,
            period === 0.02 ? `وهو تردد شبكة المنازل في مصر (50 Hz)` : `عدد الدورات الكاملة في الثانية = ${ans}`,
          ],
        };
      },
    },
    {
      generate: (d) => {
        const vp = pick([12, 24, 110, 220]);
        const imax = randFloat(2, 14, 1);
        const irms = round(imax / 1.414, 2);
        const ans = round(vp * irms, 2);
        const correct = `${ans} W`;
        return {
          question: `مصدر متردد جهده الفعال ${vp} V يغذي حملاً يمر فيه تيار قيمته العظمى ${imax} A. احسب القدرة المستهلكة. (√2 ≈ 1.414)`,
          ...makeNumericChoices(correct, generateWrongNumeric(ans, 'W')),
          explanation: `I_rms = I_max/√2 = ${imax}/1.414 = ${irms} A، ثم P = V_rms I_rms = ${vp} × ${irms} = ${ans} W.`,
          steps: [
            `I_rms = I_max / 1.414 = ${imax} / 1.414 = ${irms} A`,
            `P = V_rms × I_rms`,
            `P = ${vp} × ${irms}`,
            `P = ${ans} W`,
            d === 'hard' ? `الطاقة خلال ساعة = ${round(ans / 1000, 3)} kWh` : `استخدمنا القيمتين الفعاليتين لا العظميين`,
          ],
        };
      },
    },
  ],
};
