import {
  createContext,
  useContext,
  useEffect,
  useState,
  type ReactNode,
} from 'react';
import type { Session } from '@supabase/supabase-js';
import { supabase } from '@/lib/supabase';
import { getGuestId, getGuestName, setGuestName } from '@/lib/guestStorage';

export type ProfileRole = 'admin' | 'student';

export interface Profile {
  id: string;
  full_name: string;
  email: string;
  role: ProfileRole;
  is_admin: boolean;
}

interface AuthContextType {
  profile: Profile;
  isAdmin: boolean;
  roleLabel: string;
  session: Session | null;
  authReady: boolean;
  signIn: (email: string, password: string) => Promise<string | null>;
  signOut: () => Promise<void>;
  setProfileName: (name: string) => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

interface ProfileRow {
  id: string;
  full_name: string | null;
  email: string | null;
  role: string | null;
  is_admin: boolean | null;
}

// The role only ever comes from the database. A row that is missing, unreadable
// (RLS blocks it), or returns anything unexpected is a student.
function toProfile(row: ProfileRow | null, fallbackId: string, fallbackName: string): Profile {
  const role: ProfileRole = row?.role === 'admin' ? 'admin' : 'student';
  return {
    id: row?.id ?? fallbackId,
    full_name: row?.full_name || fallbackName,
    email: row?.email ?? '',
    role,
    is_admin: role === 'admin',
  };
}

const studentProfile = (name: string): Profile => ({
  id: getGuestId(),
  full_name: name,
  email: '',
  role: 'student',
  is_admin: false,
});

export function AuthProvider({ children }: { children: ReactNode }) {
  const [session, setSession] = useState<Session | null>(null);
  const [authReady, setAuthReady] = useState(false);
  const [profile, setProfile] = useState<Profile>(() => studentProfile(getGuestName()));

  useEffect(() => {
    let cancelled = false;

    async function loadProfile(active: Session | null) {
      if (!active?.user) {
        if (!cancelled) setProfile(studentProfile(getGuestName()));
        return;
      }
      const { data } = await supabase
        .from('profiles')
        .select('id, full_name, email, role, is_admin')
        .eq('id', active.user.id)
        .maybeSingle<ProfileRow>();
      if (!cancelled) {
        setProfile(toProfile(data, active.user.id, getGuestName()));
      }
    }

    supabase.auth
      .getSession()
      .then(({ data }) => {
        if (cancelled) return;
        setSession(data.session);
        return loadProfile(data.session);
      })
      .finally(() => {
        if (!cancelled) setAuthReady(true);
      });

    const { data: subscription } = supabase.auth.onAuthStateChange((_event, next) => {
      setSession(next);
      void loadProfile(next);
    });

    return () => {
      cancelled = true;
      subscription.subscription.unsubscribe();
    };
  }, []);

  const signIn = async (email: string, password: string): Promise<string | null> => {
    const { error } = await supabase.auth.signInWithPassword({ email, password });
    return error ? error.message : null;
  };

  const signOut = async () => {
    await supabase.auth.signOut();
    setSession(null);
    setProfile(studentProfile(getGuestName()));
  };

  const setProfileName = (name: string) => {
    setGuestName(name);
    setProfile((prev) => (prev.role === 'admin' ? prev : { ...prev, full_name: name }));
  };

  const value: AuthContextType = {
    profile,
    isAdmin: profile.is_admin,
    roleLabel: profile.is_admin ? 'مسؤول النظام' : 'طالب',
    session,
    authReady,
    signIn,
    signOut,
    setProfileName,
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used within AuthProvider');
  return ctx;
}
