import {
  generateWrongNumeric,
  makeNumericChoices,
  pick,
  randFloat,
  randInt,
  round,
  type ProblemTemplate,
} from './questionFactory';

/* الفيزياء الحديثة (الدروس 35..45).
   كل إجابة تُحسب بالحاسبة داخل الكود ثم تُدرج في الخطوات والتوضيح.
   الثوابت: h = 6.63×10⁻³⁴ J·s ، c = 3×10⁸ m/s ، 1 eV = 1.6×10⁻¹⁹ J ،
   mₑ = 9.1×10⁻³¹ kg ، λ_C = 2.43×10⁻¹² m ، R = 1.097×10⁷ m⁻¹ ،
   hc ≈ 1.989×10⁻²⁵ J·m ≈ 1240 eV·nm ، 1 u = 931.5 MeV ، 1 MeV = 1.6×10⁻¹³ J. */

export const modernProblemTemplates: Record<number, ProblemTemplate[]> = {
  // ============ 35: الإشعاع الحراري وجسم بلانك ============
  35: [
    {
      generate: () => {
        const T = randInt(2000, 8000);
        const nm = round((2.898e-3 / T) * 1e9, 0);
        const correct = `${nm} nm`;
        const wrongs = generateWrongNumeric(nm, 'nm');
        return {
          question: `جسم أسود درجة حرارته ${T} K. احسب الطول الموجي لذروة إشعاعه. (b = 2.898×10⁻³ m·K)`,
          ...makeNumericChoices(correct, wrongs),
          explanation: `قانون فين: λ_max = b/T = 2.898×10⁻³/${T} ≈ ${nm} nm`,
          steps: [
            'قانون فين للإزاحة: λ_max = b / T',
            `λ_max = 2.898×10⁻³ / ${T}`,
            `= ${nm} ×10⁻⁹ m`,
            `λ_max ≈ ${nm} nm`,
          ],
        };
      },
    },
    {
      generate: () => {
        const nm = pick([400, 500, 600, 700, 1000]);
        const T = round(2.898e-3 / (nm * 1e-9), 0);
        const correct = `${T} K`;
        const wrongs = generateWrongNumeric(T, 'K');
        return {
          question: `ذروة إشعاع جسم أسود عند طول موجي ${nm} nm. احسب درجة حرارته المطلقة. (b = 2.898×10⁻³ m·K)`,
          ...makeNumericChoices(correct, wrongs),
          explanation: `T = b/λ_max = 2.898×10⁻³ / (${nm}×10⁻⁹) ≈ ${T} K`,
          steps: [
            'من قانون فين: T = b / λ_max',
            `T = 2.898×10⁻³ / (${nm}×10⁻⁹)`,
            `T ≈ ${T} K`,
          ],
        };
      },
    },
    {
      generate: () => {
        const T = randInt(800, 1500);
        const A = randInt(1, 5);
        const P = round(5.67e-8 * A * Math.pow(T, 4), 0);
        const kW = round(P / 1000, 1);
        const correct = `${kW} kW`;
        const wrongs = generateWrongNumeric(kW, 'kW');
        return {
          question: `سطح جسم أسود مساحته ${A} m² عند درجة حرارة ${T} K. احسب قدرته الإشعاعية. (σ = 5.67×10⁻⁸ W/m²·K⁴)`,
          ...makeNumericChoices(correct, wrongs),
          explanation: `P = σ A T⁴ = 5.67×10⁻⁸ × ${A} × ${Math.pow(T, 4).toExponential(2)} = ${P} W = ${kW} kW`,
          steps: [
            'قانون ستيفان-بولتزمان: P = σ A T⁴',
            `T⁴ = (${T})⁴ = ${Math.pow(T, 4).toExponential(2)}`,
            `P = 5.67×10⁻⁸ × ${A} × ${Math.pow(T, 4).toExponential(2)}`,
            `P = ${P} W = ${kW} kW`,
          ],
        };
      },
    },
    {
      generate: () => {
        const T = randInt(300, 1200);
        const I = round(5.67e-8 * Math.pow(T, 4), 1);
        const correct = `${I} W/m²`;
        const wrongs = generateWrongNumeric(I, 'W/m²');
        return {
          question: `احسب الشدة الإشعاعية لجسم أسود درجة حرارته ${T} K. (σ = 5.67×10⁻⁸ W/m²·K⁴)`,
          ...makeNumericChoices(correct, wrongs),
          explanation: `I = σ T⁴ = 5.67×10⁻⁸ × ${Math.pow(T, 4).toExponential(2)} ≈ ${I} W/m²`,
          steps: [
            'الشدة الإشعاعية: I = σ T⁴',
            `T⁴ = (${T})⁴ = ${Math.pow(T, 4).toExponential(2)}`,
            `I = 5.67×10⁻⁸ × ${Math.pow(T, 4).toExponential(2)}`,
            `I ≈ ${I} W/m²`,
          ],
        };
      },
    },
    {
      generate: () => {
        const P1 = pick([10, 20, 40, 50]);
        const k = pick([2, 3]);
        const f4 = Math.pow(k, 4);
        const P2 = P1 * f4;
        const correct = `${P2} W`;
        const wrongs = generateWrongNumeric(P2, 'W');
        return {
          question: `إذا رفعت درجة حرارة جسم أسود إلى ${k} أضعافها وكانت قدرته ${P1} W، فاحسب القدرة الجديدة.`,
          ...makeNumericChoices(correct, wrongs),
          explanation: `P₂ = P₁×(T₂/T₁)⁴ = ${P1}×${k}⁴ = ${P1}×${f4} = ${P2} W`,
          steps: [
            `P₂/P₁ = (T₂/T₁)⁴ = ${k}⁴ = ${f4}`,
            `P₂ = ${P1} × ${f4}`,
            `P₂ = ${P2} W`,
          ],
        };
      },
    },
  ],

  // ============ 36: فرضية بلانك وكمّ الطاقة ============
  36: [
    {
      generate: () => {
        const f = randFloat(4, 9, 1);
        const E = 6.63e-34 * f * 1e14;
        const eV = round(E / 1.6e-19, 2);
        const correct = `${eV} eV`;
        const wrongs = generateWrongNumeric(eV, 'eV');
        return {
          question: `كمّ تردده ${f}×10¹⁴ Hz. احسب طاقته بالإلكترون-فولت. (h = 6.63×10⁻³⁴ J·s)`,
          ...makeNumericChoices(correct, wrongs),
          explanation: `E = h f = 6.63×10⁻³⁴ × ${f}×10¹⁴ = ${E.toExponential(3)} J = ${eV} eV`,
          steps: [
            'E = h f',
            `= 6.63×10⁻³⁴ × ${f}×10¹⁴ = ${E.toExponential(3)} J`,
            `= ${E.toExponential(3)} / 1.6×10⁻¹⁹`,
            `= ${eV} eV`,
          ],
        };
      },
    },
    {
      generate: () => {
        const nm = randInt(400, 700);
        const E = 1.989e-25 / (nm * 1e-9);
        const eV = round(E / 1.6e-19, 2);
        const correct = `${eV} eV`;
        const wrongs = generateWrongNumeric(eV, 'eV');
        return {
          question: `ضوء طوله الموجي ${nm} nm. احسب طاقة الكمّ الواحد بالإلكترون-فولت. (hc = 1.989×10⁻²⁵ J·m)`,
          ...makeNumericChoices(correct, wrongs),
          explanation: `E = hc/λ = 1.989×10⁻²⁵ / (${nm}×10⁻⁹) = ${E.toExponential(3)} J = ${eV} eV`,
          steps: [
            'E = h c / λ',
            `= 1.989×10⁻²⁵ / (${nm}×10⁻⁹)`,
            `= ${E.toExponential(3)} J`,
            `= ${eV} eV`,
          ],
        };
      },
    },
    {
      generate: () => {
        const P = randInt(50, 200);
        const f = randFloat(4, 8, 1);
        const E = 6.63e-34 * f * 1e14;
        const N = P / E;
        const mant = round(N / 1e20, 2);
        const correct = `${mant} ×10²⁰ كمّ/ثانية`;
        const wrongs = generateWrongNumeric(mant, '×10²⁰ كمّ/ثانية');
        return {
          question: `مصباح قدرته ${P} W يصدر ضوءاً تردده ${f}×10¹⁴ Hz. احسب عدد الكمّات المنبعثة في الثانية (تحويل كامل). (h = 6.63×10⁻³⁴)`,
          ...makeNumericChoices(correct, wrongs),
          explanation: `N/s = P/(hf) = ${P} / ${E.toExponential(3)} = ${mant}×10²⁰ كمّ/ثانية`,
          steps: [
            `طاقة الكمّ E = h f = ${E.toExponential(3)} J`,
            `N/s = P / E = ${P} / ${E.toExponential(3)}`,
            `N/s = ${mant} ×10²⁰ كمّ/ثانية`,
          ],
        };
      },
    },
    {
      generate: () => {
        const eV = randFloat(2, 4, 2);
        const E = eV * 1.6e-19;
        const f = E / 6.63e-34;
        const mant = round(f / 1e14, 2);
        const correct = `${mant} ×10¹⁴ Hz`;
        const wrongs = generateWrongNumeric(mant, '×10¹⁴ Hz');
        return {
          question: `كمّ طاقته ${eV} eV. احسب تردد الموجة المقابلة. (h = 6.63×10⁻³⁴ J·s ، 1 eV = 1.6×10⁻¹⁹ J)`,
          ...makeNumericChoices(correct, wrongs),
          explanation: `f = E/h = (${eV}×1.6×10⁻¹⁹)/6.63×10⁻³⁴ = ${mant}×10¹⁴ Hz`,
          steps: [
            `E = ${eV} × 1.6×10⁻¹⁹ = ${E.toExponential(3)} J`,
            'f = E / h',
            `= ${E.toExponential(3)} / 6.63×10⁻³⁴`,
            `= ${mant} ×10¹⁴ Hz`,
          ],
        };
      },
    },
    {
      generate: () => {
        const N = pick([100, 500, 1000]);
        const eV = randFloat(2, 3, 2);
        const Etot = round(N * eV, 1);
        const correct = `${Etot} eV`;
        const wrongs = generateWrongNumeric(Etot, 'eV');
        return {
          question: `حزمة تحتوي ${N} كمّاً، طاقة كلٍّ منها ${eV} eV. احسب الطاقة الكلية للحزمة بالإلكترون-فولت.`,
          ...makeNumericChoices(correct, wrongs),
          explanation: `E_كلي = N × E = ${N} × ${eV} = ${Etot} eV`,
          steps: [
            'E_كلي = N × (h f) = عدد الكمّات × طاقة الكمّ',
            `= ${N} × ${eV} eV`,
            `= ${Etot} eV`,
          ],
        };
      },
    },
  ],

  // ============ 37: التأثير الكهروضوئي ============
  37: [
    {
      generate: () => {
        const nm = randInt(300, 450);
        const phi = randFloat(1.5, 2.3, 1);
        const EeV = round(1.989e-25 / (nm * 1e-9) / 1.6e-19, 2);
        const K = round(EeV - phi, 2);
        const correct = `${K} eV`;
        const wrongs = generateWrongNumeric(K, 'eV');
        return {
          question: `ضوء طوله الموجي ${nm} nm يسقط على معدن دالة شغله ${phi} eV. احسب الطاقة الحركية العظمى للإلكترونات. (hc = 1.989×10⁻²⁵ J·m)`,
          ...makeNumericChoices(correct, wrongs),
          explanation: `K_max = hc/λ − Φ = ${EeV} − ${phi} = ${K} eV`,
          steps: [
            `طاقة الكمّ E = hc/λ = ${EeV} eV`,
            'K_max = E − Φ',
            `= ${EeV} − ${phi}`,
            `= ${K} eV`,
          ],
        };
      },
    },
    {
      generate: () => {
        const phi = randFloat(2, 3, 2);
        const f0 = (phi * 1.6e-19) / 6.63e-34;
        const mant = round(f0 / 1e14, 2);
        const correct = `${mant} ×10¹⁴ Hz`;
        const wrongs = generateWrongNumeric(mant, '×10¹⁴ Hz');
        return {
          question: `معدن دالة شغله ${phi} eV. احسب تردد العتبة. (h = 6.63×10⁻³⁴ J·s ، 1 eV = 1.6×10⁻¹⁹ J)`,
          ...makeNumericChoices(correct, wrongs),
          explanation: `f₀ = Φ/h = (${phi}×1.6×10⁻¹⁹)/6.63×10⁻³⁴ = ${mant}×10¹⁴ Hz`,
          steps: [
            `Φ = ${phi} × 1.6×10⁻¹⁹ = ${(phi * 1.6e-19).toExponential(3)} J`,
            'f₀ = Φ / h',
            `= ${(phi * 1.6e-19).toExponential(3)} / 6.63×10⁻³⁴`,
            `= ${mant} ×10¹⁴ Hz`,
          ],
        };
      },
    },
    {
      generate: () => {
        const f = randFloat(7, 9, 1);
        const phi = randFloat(1.8, 2.4, 1);
        const EeV = round(6.63e-34 * f * 1e14 / 1.6e-19, 3);
        const K = round(EeV - phi, 2);
        const correct = `${K} V`;
        const wrongs = generateWrongNumeric(K, 'V');
        return {
          question: `ضوء تردده ${f}×10¹⁴ Hz يسقط على معدن دالة شغله ${phi} eV. احسب جهد الإيقاف. (h = 6.63×10⁻³⁴)`,
          ...makeNumericChoices(correct, wrongs),
          explanation: `K_max = ${EeV} − ${phi} = ${K} eV، وجهد الإيقاف عددياً = ${K} V`,
          steps: [
            `E = h f = ${EeV} eV`,
            `K_max = E − Φ = ${EeV} − ${phi} = ${K} eV`,
            'V_s = K_max / e (بالفولت يساوي القيمة بالإلكترون-فولت)',
            `V_s = ${K} V`,
          ],
        };
      },
    },
    {
      generate: () => {
        const f = randFloat(7, 9, 1);
        const phi = randFloat(2, 2.5, 1);
        const E = 6.63e-34 * f * 1e14;
        const K = E - phi * 1.6e-19;
        const mant = round(K / 1e-20, 2);
        const correct = `${mant} ×10⁻²⁰ J`;
        const wrongs = generateWrongNumeric(mant, '×10⁻²⁰ J');
        return {
          question: `ضوء تردده ${f}×10¹⁴ Hz على معدن دالة شغله ${phi} eV. احسب K_max بالجول. (h = 6.63×10⁻³⁴)`,
          ...makeNumericChoices(correct, wrongs),
          explanation: `K_max = hf − Φ = ${E.toExponential(3)} − ${(phi * 1.6e-19).toExponential(3)} = ${mant}×10⁻²⁰ J`,
          steps: [
            `E = h f = ${E.toExponential(3)} J`,
            `Φ = ${phi} × 1.6×10⁻¹⁹ = ${(phi * 1.6e-19).toExponential(3)} J`,
            `K_max = ${E.toExponential(3)} − ${(phi * 1.6e-19).toExponential(3)}`,
            `= ${mant} ×10⁻²⁰ J`,
          ],
        };
      },
    },
    {
      generate: () => {
        const phi = randFloat(2, 3, 2);
        const lam0 = round((1.989e-25 / (phi * 1.6e-19)) * 1e9, 0);
        const correct = `${lam0} nm`;
        const wrongs = generateWrongNumeric(lam0, 'nm');
        return {
          question: `معدن دالة شغله ${phi} eV. احسب أطول طول موجي للضوء الذي لا يزال يسبب انبعاثاً. (hc = 1.989×10⁻²⁵ J·m)`,
          ...makeNumericChoices(correct, wrongs),
          explanation: `λ₀ = hc/Φ = 1.989×10⁻²⁵ / (${phi}×1.6×10⁻¹⁹) ≈ ${lam0} nm`,
          steps: [
            'الطول الأكبر يقابل تردد العتبة: λ₀ = h c / Φ',
            `Φ = ${phi} × 1.6×10⁻¹⁹ = ${(phi * 1.6e-19).toExponential(3)} J`,
            `λ₀ = 1.989×10⁻²⁵ / ${(phi * 1.6e-19).toExponential(3)}`,
            `≈ ${lam0} nm`,
          ],
        };
      },
    },
  ],

  // ============ 38: تأثير كومبتون ============
  38: [
    {
      generate: () => {
        const theta = pick([60, 90, 120, 180]);
        const factor = round(1 - Math.cos((theta * Math.PI) / 180), 3);
        const dLpm = round(2.43 * factor, 2);
        const correct = `${dLpm} pm`;
        const wrongs = generateWrongNumeric(dLpm, 'pm');
        return {
          question: `اشعاع سيني تشتت على إلكترون حر بزاوية ${theta}°. احسب إزاحة كومبتون. (λ_C = 2.43×10⁻¹² m)`,
          ...makeNumericChoices(correct, wrongs),
          explanation: `Δλ = λ_C(1 − cos θ) = 2.43 pm × ${factor} = ${dLpm} pm`,
          steps: [
            'Δλ = λ_C (1 − cos θ)',
            `cos ${theta}° = ${Math.cos((theta * Math.PI) / 180).toFixed(1)} → (1 − cos θ) = ${factor}`,
            `Δλ = 2.43 pm × ${factor}`,
            `Δλ = ${dLpm} pm`,
          ],
        };
      },
    },
    {
      generate: () => {
        const factor = pick([0.5, 1, 1.5, 2]);
        const dLpm = round(2.43 * factor, 2);
        const cosT = round(1 - factor, 2);
        const theta = Math.round((Math.acos(cosT) * 180) / Math.PI);
        const correct = `${theta}°`;
        const wrongs = generateWrongNumeric(theta, '°');
        return {
          question: `إزاحة كومبتون المرصودة تساوي ${dLpm} pm. احسب زاوية التشتت. (λ_C = 2.43×10⁻¹² m)`,
          ...makeNumericChoices(correct, wrongs),
          explanation: `1 − cos θ = Δλ/λ_C = ${factor} → cos θ = ${cosT} → θ = ${theta}°`,
          steps: [
            'Δλ = λ_C (1 − cos θ)',
            `1 − cos θ = ${dLpm} / 2.43 = ${factor}`,
            `cos θ = ${cosT}`,
            `θ = ${theta}°`,
          ],
        };
      },
    },
    {
      generate: () => {
        const theta = pick([60, 90, 180]);
        const factor = round(1 - Math.cos((theta * Math.PI) / 180), 3);
        const dLpm = round(2.43 * factor, 2);
        const lam0pm = pick([40, 50, 100]);
        const lamPm = round(lam0pm + dLpm, 2);
        const correct = `${lamPm} pm`;
        const wrongs = generateWrongNumeric(lamPm, 'pm');
        return {
          question: `فوتون سيني طوله الموجي ${lam0pm} pm تشتت بزاوية ${theta}°. احسب الطول الموجي بعد التشتت. (λ_C = 2.43×10⁻¹² m)`,
          ...makeNumericChoices(correct, wrongs),
          explanation: `Δλ = 2.43 × ${factor} = ${dLpm} pm، إذن λ' = ${lam0pm} + ${dLpm} = ${lamPm} pm`,
          steps: [
            `Δλ = λ_C(1 − cos ${theta}°) = 2.43 × ${factor} = ${dLpm} pm`,
            "λ' = λ + Δλ",
            `λ' = ${lam0pm} + ${dLpm}`,
            `λ' = ${lamPm} pm`,
          ],
        };
      },
    },
    {
      generate: () => {
        const lc = 6.63e-34 / (9.1e-31 * 3e8);
        const pm = round(lc * 1e12, 2);
        const correct = `${pm} pm`;
        const wrongs = generateWrongNumeric(pm, 'pm');
        return {
          question: 'احسب طول موجة كومبتون للإلكترون من تعريفه. (h = 6.63×10⁻³⁴ ، mₑ = 9.1×10⁻³¹ kg ، c = 3×10⁸)',
          ...makeNumericChoices(correct, wrongs),
          explanation: `λ_C = h/(mₑ c) = 6.63×10⁻³⁴ / ${(9.1e-31 * 3e8).toExponential(2)} = ${pm}×10⁻¹² m`,
          steps: [
            'λ_C = h / (mₑ c)',
            `mₑ c = 9.1×10⁻³¹ × 3×10⁸ = ${(9.1e-31 * 3e8).toExponential(2)}`,
            `λ_C = 6.63×10⁻³⁴ / ${(9.1e-31 * 3e8).toExponential(2)}`,
            `≈ ${pm} ×10⁻¹² m = ${pm} pm`,
          ],
        };
      },
    },
  ],

  // ============ 39: ازدواجية موجة-جسم / دي برولي ============
  39: [
    {
      generate: () => {
        const v = randInt(2, 9);
        const nm = round((6.63e-34 / (9.1e-31 * v * 1e6)) * 1e9, 3);
        const correct = `${nm} nm`;
        const wrongs = generateWrongNumeric(nm, 'nm');
        return {
          question: `إلكترون يتحرك بسرعة ${v}×10⁶ m/s. احسب طول دي برولي المصاحب له. (h = 6.63×10⁻³⁴ ، mₑ = 9.1×10⁻³¹)`,
          ...makeNumericChoices(correct, wrongs),
          explanation: `λ = h/(m v) = 6.63×10⁻³⁴ / (9.1×10⁻³¹ × ${v}×10⁶) ≈ ${nm} nm`,
          steps: [
            'λ = h / (m v)',
            `m v = 9.1×10⁻³¹ × ${v}×10⁶ = ${(9.1e-31 * v * 1e6).toExponential(3)}`,
            `λ = 6.63×10⁻³⁴ / ${(9.1e-31 * v * 1e6).toExponential(3)}`,
            `≈ ${nm} nm`,
          ],
        };
      },
    },
    {
      generate: () => {
        const m = pick([0.1, 0.2]);
        const v = randInt(10, 20);
        const p = m * v;
        const mant = round(6.63e-34 / p / 1e-34, 2);
        const correct = `${mant} ×10⁻³⁴ m`;
        const wrongs = generateWrongNumeric(mant, '×10⁻³⁴ m');
        return {
          question: `كرة كتلتها ${m} kg تتحرك بسرعة ${v} m/s. احسب طول دي برولي لها وفسّر النتيجة.`,
          ...makeNumericChoices(correct, wrongs),
          explanation: `λ = h/(m v) = 6.63×10⁻³⁴ / ${p} = ${mant}×10⁻³⁴ m (مهملة تماماً)`,
          steps: [
            `p = m v = ${m} × ${v} = ${p} kg·m/s`,
            `λ = h / p = 6.63×10⁻³⁴ / ${p}`,
            `λ = ${mant} ×10⁻³⁴ m`,
            'الطول أصغر من نواة الذرة فلا تظهر خواص موجية',
          ],
        };
      },
    },
    {
      generate: () => {
        const nm = randFloat(0.5, 1.5, 1);
        const lam = nm * 1e-9;
        const v = 6.63e-34 / (9.1e-31 * lam);
        const mant = round(v / 1e6, 2);
        const correct = `${mant} ×10⁶ m/s`;
        const wrongs = generateWrongNumeric(mant, '×10⁶ m/s');
        return {
          question: `طول موجة دي برولي لإلكترون ${nm} nm. احسب سرعته. (h = 6.63×10⁻³⁴ ، mₑ = 9.1×10⁻³¹)`,
          ...makeNumericChoices(correct, wrongs),
          explanation: `v = h/(m λ) = 6.63×10⁻³⁴ / (9.1×10⁻³¹ × ${nm}×10⁻⁹) ≈ ${mant}×10⁶ m/s`,
          steps: [
            'v = h / (m λ)',
            `m λ = 9.1×10⁻³¹ × ${nm}×10⁻⁹ = ${(9.1e-31 * lam).toExponential(3)}`,
            `v = 6.63×10⁻³⁴ / ${(9.1e-31 * lam).toExponential(3)}`,
            `v ≈ ${mant} ×10⁶ m/s`,
          ],
        };
      },
    },
    {
      generate: () => {
        const V = pick([50, 100, 150, 200]);
        const inner = 2 * 9.1e-31 * 1.6e-19 * V;
        const lam = 6.63e-34 / Math.sqrt(inner);
        const pm = round(lam * 1e12, 1);
        const correct = `${pm} pm`;
        const wrongs = generateWrongNumeric(pm, 'pm');
        return {
          question: `إلكترون يُسرَّع خلال فرق جهد ${V} V. احسب طول دي برولي الموجي. (h = 6.63×10⁻³⁴ ، mₑ = 9.1×10⁻³¹ ، e = 1.6×10⁻¹⁹)`,
          ...makeNumericChoices(correct, wrongs),
          explanation: `λ = h/√(2 mₑ e V) = 6.63×10⁻³⁴ / √${inner.toExponential(2)} ≈ ${pm} pm`,
          steps: [
            'λ = h / √(2 mₑ e V)',
            `2 mₑ e V = ${inner.toExponential(2)}`,
            `√(2 mₑ e V) = ${Math.sqrt(inner).toExponential(2)}`,
            `λ = 6.63×10⁻³⁴ / ${Math.sqrt(inner).toExponential(2)} ≈ ${pm} pm`,
          ],
        };
      },
    },
    {
      generate: () => {
        const v = randInt(2, 9);
        const p = 9.1e-31 * v * 1e6;
        const mant = round(p / 1e-24, 2);
        const correct = `${mant} ×10⁻²⁴ kg·m/s`;
        const wrongs = generateWrongNumeric(mant, '×10⁻²⁴ kg·m/s');
        return {
          question: `احسب زخم إلكترون سرعته ${v}×10⁶ m/s. (mₑ = 9.1×10⁻³¹ kg)`,
          ...makeNumericChoices(correct, wrongs),
          explanation: `p = m v = 9.1×10⁻³¹ × ${v}×10⁶ = ${mant}×10⁻²⁴ kg·m/s`,
          steps: [
            'p = m v',
            `= 9.1×10⁻³¹ × ${v}×10⁶`,
            `= ${mant} ×10⁻²⁴ kg·m/s`,
          ],
        };
      },
    },
  ],

  // ============ 40: مستويات الطاقة ونموذج بور ============
  40: [
    {
      generate: () => {
        const n = randInt(2, 5);
        const E = round(13.6 / (n * n), 2);
        const correct = `${E} eV`;
        const wrongs = generateWrongNumeric(E, 'eV');
        return {
          question: `احسب مقدار طاقة المستوى الرئيسي n=${n} في ذرة الهيدروجين. (Eₙ = −13.6/n² eV)`,
          ...makeNumericChoices(correct, wrongs),
          explanation: `Eₙ = −13.6/${n}² = −13.6/${n * n} = −${E} eV، والمقدار ${E} eV`,
          steps: [
            'Eₙ = −13.6 / n²',
            `= −13.6 / ${n * n}`,
            `= −${E} eV`,
            `مقدار الطاقة = ${E} eV (الإشارة السالبة تعني أن الإلكترون مربوط)`,
          ],
        };
      },
    },
    {
      generate: () => {
        const n = randInt(3, 6);
        const dE = round(13.6 * (1 / 4 - 1 / (n * n)), 2);
        const correct = `${dE} eV`;
        const wrongs = generateWrongNumeric(dE, 'eV');
        return {
          question: `ينتقل إلكترون في ذرة الهيدروجين من المستوى n=${n} إلى المستوى n=2. احسب طاقة الفوتون المنبعث.`,
          ...makeNumericChoices(correct, wrongs),
          explanation: `ΔE = 13.6(1/2² − 1/${n}²) = 13.6 × ${round(1 / 4 - 1 / (n * n), 4)} = ${dE} eV`,
          steps: [
            'ΔE = E₃ − E₂ = 13.6 (1/n₁² − 1/n₂²)',
            `= 13.6 (1/4 − 1/${n * n})`,
            `= 13.6 × ${round(1 / 4 - 1 / (n * n), 4)}`,
            `= ${dE} eV`,
          ],
        };
      },
    },
    {
      generate: () => {
        const n = randInt(2, 4);
        const r = round(n * n * 5.29e-11 * 1e10, 2);
        const correct = `${r} Å`;
        const wrongs = generateWrongNumeric(r, 'Å');
        return {
          question: `احسب نصف قطر المدار الرئيسي n=${n} في ذرة الهيدروجين بالأنگستروم. (a₀ = 0.529 Å)`,
          ...makeNumericChoices(correct, wrongs),
          explanation: `rₙ = n² a₀ = ${n * n} × 0.529 = ${r} Å`,
          steps: [
            'rₙ = n² a₀',
            `= ${n * n} × 0.529 Å`,
            `= ${r} Å`,
          ],
        };
      },
    },
    {
      generate: () => {
        const n = randInt(1, 4);
        const L = (n * 6.63e-34) / (2 * Math.PI);
        const mant = round(L / 1e-34, 3);
        const correct = `${mant} ×10⁻³⁴ J·s`;
        const wrongs = generateWrongNumeric(mant, '×10⁻³⁴ J·s');
        return {
          question: `احسب الزخم الزاوي للإلكترون في المستوى n=${n} وفق افتراض بور. (h = 6.63×10⁻³⁴ J·s)`,
          ...makeNumericChoices(correct, wrongs),
          explanation: `L = n h/(2π) = ${n} × 6.63×10⁻³⁴ / 6.283 = ${mant}×10⁻³⁴ J·s`,
          steps: [
            'L = n h / (2π)',
            `= ${n} × 6.63×10⁻³⁴ / (2 × 3.1416)`,
            `= ${mant} ×10⁻³⁴ J·s`,
          ],
        };
      },
    },
    {
      generate: () => {
        const n = randInt(3, 5);
        const dE = 13.6 * (1 / 4 - 1 / (n * n));
        const lam = round(1240 / dE, 0);
        const correct = `${lam} nm`;
        const wrongs = generateWrongNumeric(lam, 'nm');
        return {
          question: `ينتقل إلكترون من n=${n} إلى n=2 في ذرة الهيدروجين. احسب طول موجة الفوتون المنبعث. (hc ≈ 1240 eV·nm)`,
          ...makeNumericChoices(correct, wrongs),
          explanation: `ΔE = 13.6(1/4 − 1/${n * n}) = ${round(dE, 3)} eV، λ = 1240/ΔE ≈ ${lam} nm`,
          steps: [
            'ΔE = 13.6 (1/2² − 1/n²)',
            `= 13.6 × ${round(1 / 4 - 1 / (n * n), 4)} = ${round(dE, 3)} eV`,
            'λ = 1240 eV·nm / ΔE',
            `≈ ${lam} nm (سلسلة بالمر)`,
          ],
        };
      },
    },
  ],

  // ============ 41: السلاسل الطيفية لذرة الهيدروجين ============
  41: [
    {
      generate: () => {
        const n = randInt(3, 6);
        const inv = 1.097e7 * (1 / 4 - 1 / (n * n));
        const lam = round((1 / inv) * 1e9, 0);
        const correct = `${lam} nm`;
        const wrongs = generateWrongNumeric(lam, 'nm');
        return {
          question: `احسب طول موجة خط الانتقال من n=${n} إلى n=2 في ذرة الهيدروجين (سلسلة بالمر). (R = 1.097×10⁷ m⁻¹)`,
          ...makeNumericChoices(correct, wrongs),
          explanation: `1/λ = R(1/4 − 1/${n * n}) = ${inv.toExponential(3)} m⁻¹ → λ ≈ ${lam} nm`,
          steps: [
            '1/λ = R (1/2² − 1/n²)',
            `= 1.097×10⁷ × (0.25 − ${round(1 / (n * n), 4)})`,
            `= ${inv.toExponential(3)} m⁻¹`,
            `λ = 1 / ${inv.toExponential(3)} ≈ ${lam} nm`,
          ],
        };
      },
    },
    {
      generate: () => {
        const n = randInt(2, 4);
        const inv = 1.097e7 * (1 - 1 / (n * n));
        const lam = round((1 / inv) * 1e9, 1);
        const correct = `${lam} nm`;
        const wrongs = generateWrongNumeric(lam, 'nm');
        return {
          question: `احسب طول موجة خط الانتقال من n=${n} إلى n=1 (سلسلة لايمان). (R = 1.097×10⁷ m⁻¹)`,
          ...makeNumericChoices(correct, wrongs),
          explanation: `1/λ = R(1 − 1/${n * n}) = ${inv.toExponential(3)} m⁻¹ → λ ≈ ${lam} nm`,
          steps: [
            '1/λ = R (1/1² − 1/n²)',
            `= 1.097×10⁷ × (${round(1 - 1 / (n * n), 4)})`,
            `= ${inv.toExponential(3)} m⁻¹`,
            `λ ≈ ${lam} nm (فوق بنفسجي)`,
          ],
        };
      },
    },
    {
      generate: () => {
        const n = randInt(2, 4);
        const E = round(13.6 * (1 - 1 / (n * n)), 2);
        const correct = `${E} eV`;
        const wrongs = generateWrongNumeric(E, 'eV');
        return {
          question: `احسب طاقة فوتون الانتقال من n=${n} إلى المستوى n=1 في الهيدروجين.`,
          ...makeNumericChoices(correct, wrongs),
          explanation: `E = 13.6(1 − 1/${n * n}) = 13.6 × ${round(1 - 1 / (n * n), 4)} = ${E} eV`,
          steps: [
            'E = 13.6 (1/n₁² − 1/n₂²)',
            `= 13.6 (1 − 1/${n * n})`,
            `= 13.6 × ${round(1 - 1 / (n * n), 4)}`,
            `= ${E} eV`,
          ],
        };
      },
    },
    {
      generate: () => {
        const n1 = pick([1, 2, 3]);
        const inv = 1.097e7 * (1 / (n1 * n1));
        const lam = round((1 / inv) * 1e9, 1);
        const seriesName = n1 === 1 ? 'لايمان' : n1 === 2 ? 'بالمر' : 'باشن';
        const correct = `${lam} nm`;
        const wrongs = generateWrongNumeric(lam, 'nm');
        return {
          question: `احسب حدّ سلسلة ${seriesName} (الانتقال من n = ∞ إلى n=${n1}). (R = 1.097×10⁷ m⁻¹)`,
          ...makeNumericChoices(correct, wrongs),
          explanation: `1/λ = R/n₁² = 1.097×10⁷/${n1 * n1} = ${inv.toExponential(3)} → λ ≈ ${lam} nm`,
          steps: [
            'عند n₂ = ∞ يبقى 1/λ = R / n₁²',
            `= 1.097×10⁷ / ${n1 * n1}`,
            `= ${inv.toExponential(3)} m⁻¹`,
            `λ ≈ ${lam} nm`,
          ],
        };
      },
    },
    {
      generate: () => {
        const n = randInt(2, 3);
        const inv = 1.097e7 * (1 - 1 / (n * n));
        const f = round((3e8 * inv) / 1e15, 2);
        const correct = `${f} ×10¹⁵ Hz`;
        const wrongs = generateWrongNumeric(f, '×10¹⁵ Hz');
        return {
          question: `احسب تردد فوتون الانتقال من n=${n} إلى n=1 في ذرة الهيدروجين. (R = 1.097×10⁷ m⁻¹ ، c = 3×10⁸)`,
          ...makeNumericChoices(correct, wrongs),
          explanation: `f = c·R(1 − 1/${n * n}) = 3×10⁸ × ${inv.toExponential(3)} = ${f}×10¹⁵ Hz`,
          steps: [
            '1/λ = R (1 − 1/n²)',
            `f = c / λ = c × R (1 − 1/n²)`,
            `= 3×10⁸ × ${inv.toExponential(3)}`,
            `= ${f} ×10¹⁵ Hz`,
          ],
        };
      },
    },
  ],

  // ============ 42: النشاط الإشعاعي الطبيعي وأنواع الإشعاعات ============
  42: [
    {
      generate: () => {
        const parent = pick([{ A: 238, Z: 92 }, { A: 226, Z: 88 }, { A: 210, Z: 84 }, { A: 232, Z: 90 }]);
        const Ad = parent.A - 4;
        const Zd = parent.Z - 2;
        const correct = `A = ${Ad} ، Z = ${Zd}`;
        const wrongs = [`A = ${parent.A} ، Z = ${parent.Z}`, `A = ${Ad} ، Z = ${parent.Z}`, `A = ${parent.A - 2} ، Z = ${Zd}`];
        return {
          question: `نظير عدده الكتلي ${parent.A} والذري ${parent.Z} أصدر جسيم ألفا. حدد العدد الكتلي والذري للنواة الناتجة.`,
          ...makeNumericChoices(correct, wrongs),
          explanation: `جسيم ألفا يطرح 4 من العدد الكتلي و2 من الذري: A=${parent.A}−4=${Ad}، Z=${parent.Z}−2=${Zd}`,
          steps: [
            'جسيم ألفا = ⁴₂He (بروتونان ونيوترونان)',
            `العدد الكتلي: ${parent.A} − 4 = ${Ad}`,
            `العدد الذري: ${parent.Z} − 2 = ${Zd}`,
            `الناتج: A = ${Ad} ، Z = ${Zd}`,
          ],
        };
      },
    },
    {
      generate: () => {
        const parent = pick([{ A: 14, Z: 6 }, { A: 32, Z: 15 }, { A: 24, Z: 11 }]);
        const Zd = parent.Z + 1;
        const correct = `A = ${parent.A} ، Z = ${Zd}`;
        const wrongs = [`A = ${parent.A} ، Z = ${parent.Z}`, `A = ${parent.A - 1} ، Z = ${Zd}`, `A = ${parent.A} ، Z = ${parent.Z - 1}`];
        return {
          question: `نظير عدده الكتلي ${parent.A} والذري ${parent.Z} أصاب بضمحللاً بيتا السالب (β⁻). حدد أعداد النواة الناتجة.`,
          ...makeNumericChoices(correct, wrongs),
          explanation: `β⁻ يحوّل نيوتروناً إلى بروتون: A ثابت، Z = ${parent.Z}+1 = ${Zd}`,
          steps: [
            'بيتا السالب: ₀¹n → ₁¹p + ₋₁⁰e',
            `العدد الكتلي يبقى ثابتاً: A = ${parent.A}`,
            `العدد الذري يزيد واحداً: Z = ${parent.Z} + 1 = ${Zd}`,
            `الناتج: A = ${parent.A} ، Z = ${Zd}`,
          ],
        };
      },
    },
    {
      generate: () => {
        const na = pick([2, 3, 4]);
        const nb = randInt(1, 3);
        const Ad = 206;
        const Zd = 82;
        const Ap = Ad + 4 * na;
        const Zp = Zd + 2 * na - nb;
        const correct = `${na} ألفا و ${nb} بيتا`;
        const wrongs = [`${na + 1} ألفا و ${nb} بيتا`, `${na} ألفا و ${nb + 1} بيتا`, `${na - 1} ألفا و ${nb} بيتا`];
        return {
          question: `سلسلة اضمحلال من نواة (A=${Ap}، Z=${Zp}) إلى نواة (A=${Ad}، Z=${Zd}). كم جسيم ألفا وبيتا صدر؟`,
          ...makeNumericChoices(correct, wrongs),
          explanation: `عدد ألفا = (ΔA)/4 = (${Ap}−${Ad})/4 = ${na}؛ ثم nb = 2·na − (Zp−Zd) = ${nb}`,
          steps: [
            `ΔA = ${Ap} − ${Ad} = ${Ap - Ad} → عدد ألفا = ${Ap - Ad}/4 = ${na}`,
            `أثر ألفا على Z = −2×${na} = ${-2 * na}`,
            `ΔZ المطلوب = ${Zp} − ${Zd} = ${Zp - Zd} → عدد بيتا = 2×${na} − ${Zp - Zd} = ${nb}`,
            `الجواب: ${na} ألفا و ${nb} بيتا`,
          ],
        };
      },
    },
    {
      generate: () => {
        const n = randInt(1, 4);
        const dA = 4 * n;
        const dZ = 2 * n;
        const correct = `ΔA = ${dA} ، ΔZ = ${dZ}`;
        const wrongs = [`ΔA = ${dA} ، ΔZ = ${dA}`, `ΔA = ${dZ} ، ΔZ = ${dZ}`, `ΔA = ${n} ، ΔZ = ${n}`];
        return {
          question: `نواة أصدرت ${n} جسيم ألفا. ما النقص في العدد الكتلي والعدد الذري؟`,
          ...makeNumericChoices(correct, wrongs),
          explanation: `كل ألفا ينقص A بأربعة وZ باثنين: ΔA=${n}×4=${dA}، ΔZ=${n}×2=${dZ}`,
          steps: [
            'كل جسيم ألفا: ΔA = 4 ، ΔZ = 2',
            `عدد الجسيمات = ${n}`,
            `ΔA = ${n} × 4 = ${dA}`,
            `ΔZ = ${n} × 2 = ${dZ}`,
          ],
        };
      },
    },
    {
      generate: () => {
        const n = pick([2, 3, 4, 5, 6, 8]);
        const Ap = 238;
        const Ad = 238 - 4 * n;
        const correct = `${n} جسيم ألفا`;
        const wrongs = generateWrongNumeric(n, 'جسيم ألفا');
        return {
          question: `نقص العدد الكتلي في سلسلة اضمحلال من ${Ap} إلى ${Ad}. كم جسيم ألفا صدر (بفرض أن الفقد كله من ألفا)؟`,
          ...makeNumericChoices(correct, wrongs),
          explanation: `عدد ألفا = (ΔA)/4 = (${Ap} − ${Ad})/4 = ${Ap - Ad}/4 = ${n}`,
          steps: [
            `ΔA = ${Ap} − ${Ad} = ${Ap - Ad}`,
            'عدد جسيمات ألفا = ΔA / 4',
            `= ${Ap - Ad} / 4 = ${n}`,
          ],
        };
      },
    },
  ],

  // ============ 43: قانون التحلل الإشعاعي وعمر النصف ============
  43: [
    {
      generate: () => {
        const m0 = pick([64, 80, 160, 320]);
        const n = randInt(1, 4);
        const m = round(m0 / Math.pow(2, n), 2);
        const correct = `${m} g`;
        const wrongs = generateWrongNumeric(m, 'g');
        return {
          question: `عينة كتلتها ${m0} g من نظير مشع. ما الكتلة المتبقية بعد ${n} أعمار نصف؟`,
          ...makeNumericChoices(correct, wrongs),
          explanation: `m = m₀(1/2)^${n} = ${m0} / ${Math.pow(2, n)} = ${m} g`,
          steps: [
            'N = N₀ (1/2)^n حيث n عدد أعمار النصف',
            `(1/2)^${n} = 1/${Math.pow(2, n)}`,
            `m = ${m0} / ${Math.pow(2, n)}`,
            `m = ${m} g`,
          ],
        };
      },
    },
    {
      generate: () => {
        const t = pick([5, 10, 20, 50, 100]);
        const lam = round(0.693 / t, 4);
        const correct = `${lam} s⁻¹`;
        const wrongs = generateWrongNumeric(lam, 's⁻¹');
        return {
          question: `نظير عمر نصفه ${t} s. احسب ثابت التحلل λ. (T½ = 0.693/λ)`,
          ...makeNumericChoices(correct, wrongs),
          explanation: `λ = 0.693/T½ = 0.693/${t} = ${lam} s⁻¹`,
          steps: [
            'λ = 0.693 / T½',
            `= 0.693 / ${t}`,
            `= ${lam} s⁻¹`,
          ],
        };
      },
    },
    {
      generate: () => {
        const N = randInt(2, 9);
        const t = pick([10, 20]);
        const lam = 0.693 / t;
        const R = lam * N * 1e10;
        const mant = round(R / 1e9, 2);
        const correct = `${mant} ×10⁹ Bq`;
        const wrongs = generateWrongNumeric(mant, '×10⁹ Bq');
        return {
          question: `عينة أنويتها ${N}×10¹⁰ وعمر نصفها ${t} s. احسب نشاطها الإشعاعي. (λ = 0.693/T½)`,
          ...makeNumericChoices(correct, wrongs),
          explanation: `λ = 0.693/${t} = ${round(lam, 4)} s⁻¹، R = λN = ${round(lam, 4)} × ${N}×10¹⁰ = ${mant}×10⁹ Bq`,
          steps: [
            `λ = 0.693 / ${t} = ${round(lam, 4)} s⁻¹`,
            'R = λ N',
            `= ${round(lam, 4)} × ${N}×10¹⁰`,
            `= ${mant} ×10⁹ Bq`,
          ],
        };
      },
    },
    {
      generate: () => {
        const n = randInt(2, 4);
        const Th = randInt(4, 20);
        const days = n * Th;
        const frac = Math.pow(2, n);
        const correct = `${days} يوم`;
        const wrongs = generateWrongNumeric(days, 'يوم');
        return {
          question: `عمر نصف نظير ${Th} يوماً. بعد كم يوماً تبقى 1/${frac} من العينة؟`,
          ...makeNumericChoices(correct, wrongs),
          explanation: `1/${frac} = (1/2)^${n} أي ${n} أعمار نصف → t = ${n} × ${Th} = ${days} يوماً`,
          steps: [
            `1/${frac} = (1/2)^${n} → عدد أعمار النصف = ${n}`,
            't = n × T½',
            `= ${n} × ${Th}`,
            `= ${days} يوماً`,
          ],
        };
      },
    },
    {
      generate: () => {
        const n = pick([3, 4, 5]);
        const denom = Math.pow(2, n);
        const pct = round(100 / denom, 2);
        const correct = `${pct}%`;
        const wrongs = generateWrongNumeric(pct, '%');
        return {
          question: `ما النسبة المئوية المتبقية من عينة مشعة بعد ${n} أعمار نصف؟`,
          ...makeNumericChoices(correct, wrongs),
          explanation: `النسبة = (1/2)^${n} = 1/${denom} = ${pct}%`,
          steps: [
            `المتبقي = (1/2)^${n}`,
            `= 1/${denom}`,
            `= ${round(1 / denom, 4)}`,
            `= ${pct}%`,
          ],
        };
      },
    },
  ],

  // ============ 44: التفاعلات النووية والطاقة الربطية ============
  44: [
    {
      generate: () => {
        const dm = randFloat(0.1, 0.5, 2);
        const E = round(dm * 931.5, 1);
        const correct = `${E} MeV`;
        const wrongs = generateWrongNumeric(E, 'MeV');
        return {
          question: `نقص الكتلة في نواة يساوي ${dm} u. احسب طاقتها الربطية. (1 u = 931.5 MeV)`,
          ...makeNumericChoices(correct, wrongs),
          explanation: `E = Δm × 931.5 = ${dm} × 931.5 = ${E} MeV`,
          steps: [
            'E = Δm × 931.5 MeV/u',
            `= ${dm} × 931.5`,
            `= ${E} MeV`,
          ],
        };
      },
    },
    {
      generate: () => {
        const mant = randInt(1, 9);
        const E = mant * 1e-30 * 9e16;
        const Em = round(E / 1e-14, 2);
        const correct = `${Em} ×10⁻¹⁴ J`;
        const wrongs = generateWrongNumeric(Em, '×10⁻¹⁴ J');
        return {
          question: `نقص كتلة نواة يساوي ${mant}×10⁻³⁰ kg. احسب الطاقة المكافئة بالجول. (c = 3×10⁸ m/s)`,
          ...makeNumericChoices(correct, wrongs),
          explanation: `E = Δm c² = ${mant}×10⁻³⁰ × 9×10¹⁶ = ${Em}×10⁻¹⁴ J`,
          steps: [
            'E = Δm c²',
            `= ${mant}×10⁻³⁰ × (3×10⁸)²`,
            `= ${mant}×10⁻³⁰ × 9×10¹⁶`,
            `= ${Em} ×10⁻¹⁴ J`,
          ],
        };
      },
    },
    {
      generate: () => {
        const A = pick([4, 12, 40, 56]);
        const per = pick([6, 7, 8]);
        const EB = A * per;
        const calcPer = round(EB / A, 1);
        const correct = `${calcPer} MeV/نوية`;
        const wrongs = generateWrongNumeric(calcPer, 'MeV/نوية');
        return {
          question: `نواة عددها الكتلي ${A} وطاقتها الربطية الكلية ${EB} MeV. احسب الطاقة الربطية لكل نوية.`,
          ...makeNumericChoices(correct, wrongs),
          explanation: `لكل نوية = E_B / A = ${EB} / ${A} = ${calcPer} MeV/نوية`,
          steps: [
            'E لكل نوية = E_B / A',
            `= ${EB} / ${A}`,
            `= ${calcPer} MeV/نوية`,
          ],
        };
      },
    },
    {
      generate: () => {
        const MeV = pick([50, 100, 150, 200]);
        const J = MeV * 1.6e-13;
        const mant = round(J / 1e-11, 2);
        const correct = `${mant} ×10⁻¹¹ J`;
        const wrongs = generateWrongNumeric(mant, '×10⁻¹¹ J');
        return {
          question: `حوّل طاقة ${MeV} MeV إلى الجول. (1 MeV = 1.6×10⁻¹³ J)`,
          ...makeNumericChoices(correct, wrongs),
          explanation: `E = ${MeV} × 1.6×10⁻¹³ = ${mant}×10⁻¹¹ J`,
          steps: [
            'E(J) = E(MeV) × 1.6×10⁻¹³',
            `= ${MeV} × 1.6×10⁻¹³`,
            `= ${mant} ×10⁻¹¹ J`,
          ],
        };
      },
    },
    {
      generate: () => {
        const A = pick([4, 12, 16]);
        const dm = round(randFloat(0.03, 0.13, 3), 3);
        const EB = round(dm * 931.5, 1);
        const per = round(EB / A, 2);
        const correct = `${per} MeV/نوية`;
        const wrongs = generateWrongNumeric(per, 'MeV/نوية');
        return {
          question: `نقص الكتلة في نواة ${A} نوية يساوي ${dm} u. احسب الطاقة الربطية لكل نوية. (1 u = 931.5 MeV)`,
          ...makeNumericChoices(correct, wrongs),
          explanation: `E_B = ${dm}×931.5 = ${EB} MeV، ولكل نوية = ${EB}/${A} = ${per} MeV`,
          steps: [
            `E_B = Δm × 931.5 = ${dm} × 931.5 = ${EB} MeV`,
            'لكل نوية = E_B / A',
            `= ${EB} / ${A}`,
            `= ${per} MeV/نوية`,
          ],
        };
      },
    },
  ],

  // ============ 45: الانشطار والاندماج والاستخدامات السلمية ============
  45: [
    {
      generate: () => {
        const MeV = pick([180, 200, 210]);
        const J = round((MeV * 1.6e-13) / 1e-11, 2);
        const correct = `${J} ×10⁻¹¹ J`;
        const wrongs = generateWrongNumeric(J, '×10⁻¹¹ J');
        return {
          question: `انشطار واحد يُحرر ${MeV} MeV. احسب هذه الطاقة بالجول. (1 MeV = 1.6×10⁻¹³ J)`,
          ...makeNumericChoices(correct, wrongs),
          explanation: `E = ${MeV} × 1.6×10⁻¹³ = ${J}×10⁻¹¹ J`,
          steps: [
            'E(J) = E(MeV) × 1.6×10⁻¹³',
            `= ${MeV} × 1.6×10⁻¹³`,
            `= ${J} ×10⁻¹¹ J`,
          ],
        };
      },
    },
    {
      generate: () => {
        const MW = pick([500, 1000, 1500]);
        const N = (MW * 1e6) / 3.2e-11;
        const mant = round(N / 1e19, 2);
        const correct = `${mant} ×10¹⁹ انشطار/ثانية`;
        const wrongs = generateWrongNumeric(mant, '×10¹⁹ انشطار/ثانية');
        return {
          question: `مفاعل قدرته ${MW} MW. كم انشطاراً يحدث في الثانية؟ (E لكل انشطار = 3.2×10⁻¹¹ J)`,
          ...makeNumericChoices(correct, wrongs),
          explanation: `عدد الانشطارات/ث = P/E = ${MW}×10⁶ / 3.2×10⁻¹¹ = ${mant}×10¹⁹`,
          steps: [
            `الطاقة في الثانية = ${MW}×10⁶ J = ${(MW * 1e6).toExponential(2)} J`,
            'عدد الانشطارات = P / E',
            `= ${(MW * 1e6).toExponential(2)} / 3.2×10⁻¹¹`,
            `= ${mant} ×10¹⁹ انشطار/ثانية`,
          ],
        };
      },
    },
    {
      generate: () => {
        const MeV = pick([17.6, 20, 24]);
        const J = round((MeV * 1.6e-13) / 1e-12, 2);
        const correct = `${J} ×10⁻¹² J`;
        const wrongs = generateWrongNumeric(J, '×10⁻¹² J');
        return {
          question: `اندماج D-T واحد يُحرر ${MeV} MeV. احسب الطاقة بالجول. (1 MeV = 1.6×10⁻¹³ J)`,
          ...makeNumericChoices(correct, wrongs),
          explanation: `E = ${MeV} × 1.6×10⁻¹³ = ${J}×10⁻¹² J`,
          steps: [
            'E(J) = E(MeV) × 1.6×10⁻¹³',
            `= ${MeV} × 1.6×10⁻¹³`,
            `= ${J} ×10⁻¹² J`,
          ],
        };
      },
    },
    {
      generate: () => {
        const GW = pick([1, 2]);
        const E = GW * 1e9 * 86400;
        const mol = E / 1.93e13;
        const mass = round(mol * 235, 0);
        const correct = `${mass} g`;
        const wrongs = generateWrongNumeric(mass, 'g');
        return {
          question: `مفاعل بقوة ${GW} GW يستهلك يورانيوم-235 (كل مول يعطي 1.93×10¹³ J). احسب كتلة اليورانيوم المستهلكة في يوم تشغيل. (235 g/mol)`,
          ...makeNumericChoices(correct, wrongs),
          explanation: `E = ${GW}×10⁹ × 86400 = ${E.toExponential(2)} J، المولات = ${round(mol, 2)}، الكتلة ≈ ${mass} g`,
          steps: [
            `الطاقة في يوم = ${GW}×10⁹ × 86400 = ${E.toExponential(2)} J`,
            `عدد المولات = ${E.toExponential(2)} / 1.93×10¹³ = ${round(mol, 2)}`,
            `الكتلة = ${round(mol, 2)} × 235`,
            `≈ ${mass} g`,
          ],
        };
      },
    },
    {
      generate: () => {
        const MeV = pick([180, 200, 210]);
        const E = MeV * 6.02e23 * 1.6e-13;
        const mant = round(E / 1e13, 2);
        const correct = `${mant} ×10¹³ J`;
        const wrongs = generateWrongNumeric(mant, '×10¹³ J');
        return {
          question: `احسب الطاقة المتحررة من انشطار مول واحد من اليورانيوم (${MeV} MeV لكل نواة). (Nₐ = 6.02×10²³ ، 1 MeV = 1.6×10⁻¹³ J)`,
          ...makeNumericChoices(correct, wrongs),
          explanation: `E = ${MeV} × 6.02×10²³ × 1.6×10⁻¹³ = ${mant}×10¹³ J`,
          steps: [
            `E(MeV) = ${MeV} × 6.02×10²³ = ${(MeV * 6.02e23).toExponential(3)} MeV`,
            'التحويل للجول × 1.6×10⁻¹³',
            `= ${(MeV * 6.02e23).toExponential(3)} × 1.6×10⁻¹³`,
            `= ${mant} ×10¹³ J`,
          ],
        };
      },
    },
  ],
};
