/*
# Fix RLS policies to explicitly allow admin email access

Updates admin-gated SELECT policies on profiles, ai_queries, and quiz_results
to also grant access when the authenticated user's email is the designated
admin email (mal949100@gmail.com). This prevents a deadlock where the admin
cannot read profiles if their own profile row is missing or is_admin is false.
*/

-- Helper: check if current user is admin by email or profile flag
-- We inline this in each policy since RLS policies cannot call custom
-- SECURITY DEFINER functions that reference auth.users without grants.

-- ==================== profiles: admin SELECT ====================
DROP POLICY IF EXISTS "select_own_profile" ON public.profiles;

CREATE POLICY "select_own_profile"
ON public.profiles FOR SELECT
TO authenticated
USING (
  auth.uid() = id
  OR EXISTS (
    SELECT 1 FROM profiles p
    WHERE p.id = auth.uid() AND p.is_admin = true
  )
  OR EXISTS (
    SELECT 1 FROM auth.users u
    WHERE u.id = auth.uid()
      AND u.email = 'mal949100@gmail.com'
  )
);

-- ==================== ai_queries: admin SELECT ====================
DROP POLICY IF EXISTS "select_admin_queries" ON public.ai_queries;

CREATE POLICY "select_admin_queries"
ON public.ai_queries FOR SELECT
TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM profiles p
    WHERE p.id = auth.uid() AND p.is_admin = true
  )
  OR EXISTS (
    SELECT 1 FROM auth.users u
    WHERE u.id = auth.uid()
      AND u.email = 'mal949100@gmail.com'
  )
);

-- ==================== quiz_results: admin SELECT ====================
DROP POLICY IF EXISTS "select_own_quiz_results" ON public.quiz_results;

CREATE POLICY "select_own_quiz_results"
ON public.quiz_results FOR SELECT
TO authenticated
USING (
  auth.uid() = user_id
  OR EXISTS (
    SELECT 1 FROM profiles p
    WHERE p.id = auth.uid() AND p.is_admin = true
  )
  OR EXISTS (
    SELECT 1 FROM auth.users u
    WHERE u.id = auth.uid()
      AND u.email = 'mal949100@gmail.com'
  )
);
