import { useState } from 'react';
import {
  ClipboardList,
  FileText,
  Calculator,
  Lightbulb,
  ChevronDown,
  Calendar,
  Clock,
  Play,
} from 'lucide-react';
import {
  buildExam,
  examCategories,
  examPlansByCategory,
  getExamPlan,
  type BuiltExam,
  type ExamCategory,
  type ExamPlan,
} from '@/data/examPlans';
import { chapters, chapterLabel, termLabel, type ChapterId } from '@/data/lessons';
import { termSoft } from '@/lib/chapterTheme';
import { clearMockExamDraft, getMockExamDraft, type MockExamDraft } from '@/lib/guestStorage';
import MockExamRunner from '@/components/MockExamRunner';

// The timed paper that belongs to each monthly review.
const examIdByReview: Record<string, string> = {
  october: 'ex-f-ch-1',
  'mid-ch2': 'ex-c-2-1',
};

// An attempt that ran out of time while the tab was closed is dropped, not resumed.
function readResumableAttempt() {
  const draft = getMockExamDraft();
  if (!draft) return null;
  if (draft.endsAt <= Date.now() || !getExamPlan(draft.examId)) {
    clearMockExamDraft();
    return null;
  }
  const exam = buildExam(draft.examId);
  if (!exam) {
    clearMockExamDraft();
    return null;
  }
  return { exam, draft };
}

interface RunningAttempt {
  exam: BuiltExam;
  draft: MockExamDraft | null;
  // Bumped on every (re)start so the runner remounts with a fresh clock.
  attempt: number;
}

interface ExamReview {
  id: string;
  title: string;
  subtitle: string;
  date: string;
  color: string;
  summaries: { title: string; points: string[] }[];
  cheatSheet: { law: string; formula: string; unit: string }[];
  practiceQuestions: { q: string; hint: string }[];
}

const reviews: ExamReview[] = [
  {
    id: 'october',
    title: 'مراجعة شهر أكتوبر — الفصل الأول كاملاً',
    subtitle: 'الميكانيكا (12 درساً)',
    date: 'أكتوبر 2026',
    color: 'blue',
    summaries: [
      {
        title: 'ملخص حركة المقذوفات',
        points: [
          'المقذوف الأفقي: حركتان مستقلتان — أفقية بسرعة ثابتة ورأسية سقوط حر',
          'زمن الطيران: t = √(2y/g)، المدى: R = vₓ × t',
          'المقذوف بزاوية: H = v₀²sin²θ/2g، R = v₀²sin2θ/g، T = 2v₀sinθ/g',
          'أقصى مدى عند زاوية 45° لأن sin 90° = 1',
        ],
      },
      {
        title: 'ملخص عزم القوة والاتزان',
        points: [
          'عزم القوة: τ = F × d (القوة × الذراع العمودي)',
          'اتزان انتقالي: ΣF = 0 في كل محور',
          'اتزان دوراني: Στ = 0 حول أي نقطة',
          'رد فعل الإسناد على سطح أفقي = الوزن',
        ],
      },
      {
        title: 'ملخص كمية الحركة والتصادم',
        points: [
          'كمية التحرك: p = mv، الدفع: J = FΔt = Δp',
          'حفظ كمية الحركة في النظام المعزول: p_before = p_after',
          'تصادم مرن: يُحفظ الزخم والطاقة الحركية',
          'تصادم غير مرن: يُحفظ الزخم فقط، تفقد طاقة',
        ],
      },
      {
        title: 'ملخص الحركة الدائرية وكبلر',
        points: [
          'القوة المركزية: F = mv²/r، التسارع المركزي: a = v²/r',
          'الزمن الدوري: T = 2πr/v = 2π/ω',
          'في الدوران الرأسي: أعلى نقطة F = mv²/r - mg، أسفل F = mv²/r + mg',
          'قانون كبلر الثالث: T² ∝ r³',
          'الجاذبية: F = Gm₁m₂/r²، سرعة القمر: v = √(GM/r)',
        ],
      },
    ],
    cheatSheet: [
      { law: 'السرعة النسبية', formula: 'v_AB = v_A - v_B', unit: 'm/s' },
      { law: 'مدى المقذوف', formula: 'R = v₀²sin2θ / g', unit: 'm' },
      { law: 'أقصى ارتفاع', formula: 'H = v₀²sin²θ / 2g', unit: 'm' },
      { law: 'عزم القوة', formula: 'τ = F × d', unit: 'N·m' },
      { law: 'القدرة', formula: 'P = W / t = F × v', unit: 'W' },
      { law: 'الكفاءة', formula: 'η = P_out / P_in × 100%', unit: '%' },
      { law: 'كمية التحرك', formula: 'p = m × v', unit: 'kg·m/s' },
      { law: 'الدفع', formula: 'J = F × Δt = Δp', unit: 'N·s' },
      { law: 'القوة المركزية', formula: 'F = mv² / r', unit: 'N' },
      { law: 'الزمن الدوري الدائري', formula: 'T = 2πr / v', unit: 's' },
      { law: 'الجاذبية الكونية', formula: 'F = Gm₁m₂ / r²', unit: 'N' },
      { law: 'سرعة القمر', formula: 'v = √(GM / r)', unit: 'm/s' },
    ],
    practiceQuestions: [
      { q: 'قذيفة تُقذف بسرعة 50 m/s بزاوية 37°. احسب المدى وأقصى ارتفاع. (g = 10 m/s²)', hint: 'استخدم R = v₀²sin2θ/g و H = v₀²sin²θ/2g، sin37=0.6، cos37=0.8' },
      { q: 'سيارة 1200 kg في منحنى r=40m بسرعة 15 m/s. احسب القوة المركزية.', hint: 'F = mv²/r مباشرة' },
      { q: 'كرة 0.4 kg بسرعة 8 m/s تلتصق بكرة 0.6 kg ساكنة. احسب السرعة المشتركة وفقد الطاقة.', hint: 'حفظ الزخم ثم ΔKE = KE_before - KE_after' },
      { q: 'قمر يدور على بعد 8×10⁶ m من كوكب كتلته 6×10²⁴ kg. احسب سرعته.', hint: 'v = √(GM/r)، G=6.67×10⁻¹¹' },
      { q: 'محرك قدرة داخله 5000 W وكفاءته 80%. احسب القدرة الناتجة.', hint: 'P_out = η × P_in' },
    ],
  },
  {
    id: 'mid-ch2',
    title: 'مراجعة منتصف الفصل الثاني',
    subtitle: 'الحركة الاهتزازية والموجات (الدروس 1-6)',
    date: 'نوفمبر 2026',
    color: 'emerald',
    summaries: [
      {
        title: 'ملخص الحركة التوافقية البسيطة',
        points: [
          'الإزاحة: x = A cos(ωt)، السرعة: v = -Aω sin(ωt)',
          'التسارع: a = -ω²x (∝ الإزاحة وعكس اتجاهها)',
          'السرعة القصوى: v_max = Aω، التسارع الأقصى: a_max = Aω²',
          'الطاقة الكلية: E = ½kA² = ½mv²_max',
        ],
      },
      {
        title: 'ملخص البندول الزنبركي والبسيط',
        points: [
          'قانون هوك: F = -kx، الطاقة المرونية: PE = ½kx²',
          'بندول زنبركي: T = 2π√(m/k)',
          'بندول بسيط: T = 2π√(L/g) — لا يعتمد على الكتلة',
          'شرط الزاوية الصغيرة: θ < 15° حيث sin θ ≈ θ',
        ],
      },
      {
        title: 'ملخص الموجات والتداخل',
        points: [
          'سرعة الموجة: v = λf، الزمن الدوري: T = 1/f',
          'تداخل بناء: Δx = nλ، تداخل هدام: Δx = (n+½)λ',
          'موجة موقوفة في أنبوب مفتوح: L = λ/2 (أساسي)',
          'موجة موقوفة في أنبوب مغلق: L = λ/4 (أساسي، توافقيات فردية فقط)',
        ],
      },
    ],
    cheatSheet: [
      { law: 'الإزاحة (SHM)', formula: 'x = A cos(ωt)', unit: 'm' },
      { law: 'السرعة القصوى', formula: 'v_max = Aω', unit: 'm/s' },
      { law: 'التسارع الأقصى', formula: 'a_max = Aω²', unit: 'm/s²' },
      { law: 'بندول زنبركي', formula: 'T = 2π√(m/k)', unit: 's' },
      { law: 'بندول بسيط', formula: 'T = 2π√(L/g)', unit: 's' },
      { law: 'قانون هوك', formula: 'F = -kx', unit: 'N' },
      { law: 'الطاقة المرونية', formula: 'PE = ½kx²', unit: 'J' },
      { law: 'سرعة الموجة', formula: 'v = λ × f', unit: 'm/s' },
      { law: 'تداخل بناء', formula: 'Δx = nλ', unit: 'm' },
      { law: 'تداخل هدام', formula: 'Δx = (n + ½)λ', unit: 'm' },
    ],
    practiceQuestions: [
      { q: 'جسم كتلته 0.3 kg على نابض k=120 N/m. احسب الزمن الدوري والتردد.', hint: 'T = 2π√(m/k)، f = 1/T' },
      { q: 'بندول بسيط L=0.9m على القمر (g=1.6 m/s²). احسب زمنه الدوري.', hint: 'T = 2π√(L/g)' },
      { q: 'موجة ترددها 200 Hz وسرعتها 340 m/s. احسب الطول الموجي.', hint: 'λ = v/f' },
      { q: 'أنبوب مغلق طوله 0.17m، سرعة الصوت 340 m/s. احسب التردد الأساسي.', hint: 'L = λ/4 → f = v/4L' },
      { q: 'جسم يهتز بسعة 0.05m وω=10 rad/s. احسب v_max و a_max.', hint: 'v_max = Aω، a_max = Aω²' },
    ],
  },
];

export default function ExamsSection() {
  // A running attempt outlives a reload: the countdown and answers come back from the device.
  const [resumable] = useState(readResumableAttempt);
  const [running, setRunning] = useState<RunningAttempt | null>(() =>
    resumable ? { ...resumable, attempt: 0 } : null,
  );
  const [expandedId, setExpandedId] = useState<string | null>('october');
  const [activeTab, setActiveTab] = useState<'summaries' | 'cheatsheet' | 'questions'>('summaries');
  const [category, setCategory] = useState<ExamCategory>('partial');
  const [chapterFilter, setChapterFilter] = useState<'all' | ChapterId>('all');

  const startPlan = (plan: ExamPlan) => {
    const exam = buildExam(plan.id);
    if (!exam) return;
    clearMockExamDraft();
    setRunning((prev) => ({ exam, draft: null, attempt: (prev?.attempt ?? 0) + 1 }));
  };

  const visiblePlans = examPlansByCategory(category).filter(
    (plan) => chapterFilter === 'all' || plan.chapterIds.includes(chapterFilter),
  );

  const retakeCurrent = () =>
    setRunning((prev) => (prev ? { ...prev, draft: null, attempt: prev.attempt + 1 } : null));

  if (running) {
    return (
      <MockExamRunner
        key={`${running.exam.id}-${running.attempt}`}
        exam={running.exam}
        draft={running.draft}
        onExit={() => setRunning(null)}
        onRetake={retakeCurrent}
      />
    );
  }

  return (
    <div className="space-y-6">
      <div className="bg-white dark:bg-slate-900 rounded-2xl p-6 shadow-sm border border-slate-100 dark:border-slate-800">
        <div className="flex items-center gap-3 mb-4">
          <div className="w-12 h-12 bg-amber-50 dark:bg-amber-500/15 rounded-xl flex items-center justify-center">
            <ClipboardList className="w-6 h-6 text-amber-600 dark:text-amber-300" />
          </div>
          <div>
            <h2 className="text-xl font-bold text-slate-800 dark:text-slate-100">الامتحانات التجريبية والمراجعات</h2>
            <p className="text-sm text-slate-500 dark:text-slate-300">امتحانات موقّتة بنتيجة تُسجَّل على جهازك، وملخصات وجداول قوانين وأسئلة متوقعة</p>
          </div>
        </div>
      </div>

      <div className="bg-white dark:bg-slate-900 rounded-2xl p-5 shadow-sm border border-slate-100 dark:border-slate-800">
        <div className="flex flex-wrap gap-2 mb-3">
          {examCategories.map((item) => (
            <button
              key={item.id}
              onClick={() => setCategory(item.id)}
              className={`px-4 py-2 rounded-xl text-xs font-bold transition-all ${
                category === item.id
                  ? 'bg-primary-600 text-white'
                  : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700'
              }`}
            >
              {item.label}
              <span className="block text-[10px] font-semibold opacity-80 mt-0.5">{item.hint}</span>
            </button>
          ))}
        </div>
        <div className="flex flex-wrap gap-1.5">
          <button
            onClick={() => setChapterFilter('all')}
            className={`text-xs px-3 py-1.5 rounded-lg font-bold transition-all ${
              chapterFilter === 'all'
                ? 'bg-slate-800 text-white dark:bg-slate-200 dark:text-slate-800'
                : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300'
            }`}
          >
            كل الفصول
          </button>
          {chapters.map((chapter) => (
            <button
              key={chapter.id}
              onClick={() => setChapterFilter(chapter.id)}
              className={`text-xs px-3 py-1.5 rounded-lg font-bold transition-all ${
                chapterFilter === chapter.id
                  ? 'bg-slate-800 text-white dark:bg-slate-200 dark:text-slate-800'
                  : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300'
              }`}
            >
              {chapterLabel(chapter.id)}
            </button>
          ))}
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
        {visiblePlans.map((plan) => (
          <div
            key={plan.id}
            className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-100 dark:border-slate-800 shadow-sm p-5 flex flex-col hover:shadow-md transition-all"
          >
            <div className="flex items-start gap-2 mb-2">
              <div className="w-10 h-10 bg-primary-50 dark:bg-primary-500/15 rounded-xl flex items-center justify-center flex-shrink-0">
                <Clock className="w-5 h-5 text-primary-600 dark:text-primary-300" />
              </div>
              <h3 className="font-bold text-sm text-slate-800 dark:text-slate-100 leading-snug">{plan.title}</h3>
            </div>
            <p className="text-xs text-slate-500 dark:text-slate-300 leading-relaxed mb-3 flex-1">{plan.description}</p>
            <div className="flex flex-wrap items-center gap-1.5 mb-3">
              <span className="text-xs px-2 py-1 rounded-lg bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 font-bold">
                {plan.questionCount} سؤال
              </span>
              <span className="text-xs px-2 py-1 rounded-lg bg-amber-50 dark:bg-amber-500/15 text-amber-700 dark:text-amber-300 font-bold">
                {plan.minutes} دقيقة
              </span>
              <span className="text-xs px-2 py-1 rounded-lg bg-emerald-50 dark:bg-emerald-500/15 text-emerald-700 dark:text-emerald-300 font-bold">
                {plan.lessonIds.length} درس
              </span>
              <span className={`text-xs px-2 py-1 rounded-lg font-bold ${termSoft[plan.term]}`}>
                {termLabel(plan.term)}
              </span>
            </div>
            <button
              onClick={() => startPlan(plan)}
              className="w-full py-2.5 bg-primary-600 hover:bg-primary-700 text-white rounded-xl text-sm font-bold transition-all inline-flex items-center justify-center gap-2"
            >
              <Play className="w-4 h-4" />
              ابدأ الامتحان
            </button>
          </div>
        ))}
      </div>

      <div className="space-y-4">
        {reviews.map((review) => {
          const isOpen = expandedId === review.id;
          const isBlue = review.color === 'blue';
          const linkedExamId = examIdByReview[review.id];
          const linkedExam = linkedExamId ? getExamPlan(linkedExamId) : undefined;
          return (
            <div
              key={review.id}
              className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-100 dark:border-slate-800 shadow-sm overflow-hidden transition-all hover:shadow-md"
            >
              <button
                onClick={() => setExpandedId(isOpen ? null : review.id)}
                className="w-full flex items-center gap-4 p-5 text-right hover:bg-slate-50/50 transition-colors"
              >
                <div
                  className={`flex-shrink-0 w-12 h-12 rounded-xl flex items-center justify-center ${
                    isBlue ? 'bg-blue-50 dark:bg-blue-500/15 text-blue-600 dark:text-blue-300' : 'bg-emerald-50 dark:bg-emerald-500/15 text-emerald-600 dark:text-emerald-300'
                  }`}
                >
                  <FileText className="w-6 h-6" />
                </div>
                <div className="flex-1 min-w-0">
                  <h3 className="font-bold text-slate-800 dark:text-slate-100 text-base">{review.title}</h3>
                  <div className="flex items-center gap-2 mt-1">
                    <span
                      className={`text-xs px-2 py-0.5 rounded-full ${
                        isBlue ? 'bg-blue-50 dark:bg-blue-500/15 text-blue-600 dark:text-blue-300' : 'bg-emerald-50 dark:bg-emerald-500/15 text-emerald-600 dark:text-emerald-300'
                      }`}
                    >
                      {review.subtitle}
                    </span>
                    <span className="flex items-center gap-1 text-xs text-slate-400 dark:text-slate-500">
                      <Calendar className="w-3 h-3" />
                      {review.date}
                    </span>
                  </div>
                </div>
                <ChevronDown
                  className={`w-5 h-5 text-slate-400 dark:text-slate-500 flex-shrink-0 transition-transform ${
                    isOpen ? 'rotate-180' : ''
                  }`}
                />
              </button>

              {isOpen && (
                <div className="px-5 pb-5 animate-slide-down">
                  <div className="border-t border-slate-100 dark:border-slate-800 pt-4">
                    {linkedExam && (
                      <div className="flex items-center justify-between gap-3 rounded-xl bg-slate-50 dark:bg-slate-800 px-3 py-2.5 mb-4">
                        <p className="text-xs text-slate-600 dark:text-slate-300 font-semibold">
                          بعد المراجعة جرّب نفسك: {linkedExam.questionCount} سؤالاً في {linkedExam.minutes} دقيقة، والنتيجة تُسجَّل في سجل نتائجك.
                        </p>
                        <button
                          onClick={() => startPlan(linkedExam)}
                          className="flex-shrink-0 px-3 py-2 bg-primary-600 hover:bg-primary-700 text-white rounded-lg text-xs font-bold transition-all inline-flex items-center gap-1.5"
                        >
                          <Play className="w-3.5 h-3.5" />
                          امتحان موقّت
                        </button>
                      </div>
                    )}

                    {/* Tab switcher */}
                    <div className="flex gap-2 mb-4">
                      <button
                        onClick={() => setActiveTab('summaries')}
                        className={`px-4 py-2 rounded-lg text-xs font-bold transition-all ${
                          activeTab === 'summaries'
                            ? 'bg-primary-600 text-white'
                            : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700'
                        }`}
                      >
                        <FileText className="w-4 h-4 inline ml-1" />
                        الملخصات
                      </button>
                      <button
                        onClick={() => setActiveTab('cheatsheet')}
                        className={`px-4 py-2 rounded-lg text-xs font-bold transition-all ${
                          activeTab === 'cheatsheet'
                            ? 'bg-primary-600 text-white'
                            : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700'
                        }`}
                      >
                        <Calculator className="w-4 h-4 inline ml-1" />
                        جدول القوانين
                      </button>
                      <button
                        onClick={() => setActiveTab('questions')}
                        className={`px-4 py-2 rounded-lg text-xs font-bold transition-all ${
                          activeTab === 'questions'
                            ? 'bg-primary-600 text-white'
                            : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700'
                        }`}
                      >
                        <Lightbulb className="w-4 h-4 inline ml-1" />
                        أسئلة متوقعة
                      </button>
                    </div>

                    {/* Summaries tab */}
                    {activeTab === 'summaries' && (
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-3 animate-fade-in">
                        {review.summaries.map((s, idx) => (
                          <div key={idx} className="bg-slate-50 dark:bg-slate-800 rounded-xl p-4 border border-slate-100 dark:border-slate-800">
                            <h4 className="font-bold text-sm text-slate-700 dark:text-slate-100 mb-2 flex items-center gap-2">
                              <FileText className="w-4 h-4 text-primary-600 dark:text-primary-300" />
                              {s.title}
                            </h4>
                            <ul className="space-y-1.5">
                              {s.points.map((p, pIdx) => (
                                <li key={pIdx} className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed flex items-start gap-2">
                                  <span className="w-1.5 h-1.5 bg-primary-500 rounded-full mt-1.5 flex-shrink-0"></span>
                                  {p}
                                </li>
                              ))}
                            </ul>
                          </div>
                        ))}
                      </div>
                    )}

                    {/* Cheat sheet tab */}
                    {activeTab === 'cheatsheet' && (
                      <div className="overflow-x-auto animate-fade-in">
                        <table className="w-full text-sm">
                          <thead>
                            <tr className="bg-slate-50 dark:bg-slate-800 border border-slate-100 dark:border-slate-800 rounded-lg">
                              <th className="p-3 text-right font-bold text-slate-700 dark:text-slate-100 text-xs">القانون</th>
                              <th className="p-3 text-center font-bold text-slate-700 dark:text-slate-100 text-xs">المعادلة</th>
                              <th className="p-3 text-center font-bold text-slate-700 dark:text-slate-100 text-xs">الوحدة</th>
                            </tr>
                          </thead>
                          <tbody>
                            {review.cheatSheet.map((item, idx) => (
                              <tr key={idx} className="border-b border-slate-50 dark:border-slate-800 hover:bg-slate-50/50 transition-colors">
                                <td className="p-3 text-right text-xs text-slate-600 dark:text-slate-300 font-semibold">{item.law}</td>
                                <td className="p-3 text-center text-xs text-primary-700 dark:text-primary-300 font-bold" dir="ltr">
                                  {item.formula}
                                </td>
                                <td className="p-3 text-center">
                                  <span className="text-xs px-2 py-0.5 bg-amber-50 dark:bg-amber-500/15 text-amber-700 dark:text-amber-300 rounded-lg font-semibold">
                                    {item.unit}
                                  </span>
                                </td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    )}

                    {/* Practice questions tab */}
                    {activeTab === 'questions' && (
                      <div className="space-y-2 animate-fade-in">
                        {review.practiceQuestions.map((pq, idx) => (
                          <div key={idx} className="bg-slate-50 dark:bg-slate-800 rounded-xl p-3 border border-slate-100 dark:border-slate-800">
                            <div className="flex items-start gap-2 mb-2">
                              <span className="flex-shrink-0 w-6 h-6 bg-primary-600 text-white rounded-full flex items-center justify-center text-xs font-bold">
                                {idx + 1}
                              </span>
                              <p className="text-sm text-slate-700 dark:text-slate-100 leading-relaxed">{pq.q}</p>
                            </div>
                            <div className="flex items-start gap-2 pr-8">
                              <Lightbulb className="w-4 h-4 text-amber-500 dark:text-amber-300 flex-shrink-0 mt-0.5" />
                              <p className="text-xs text-slate-500 dark:text-slate-300 leading-relaxed">
                                <span className="font-bold text-amber-600 dark:text-amber-300">تلميح: </span>
                                {pq.hint}
                              </p>
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}
