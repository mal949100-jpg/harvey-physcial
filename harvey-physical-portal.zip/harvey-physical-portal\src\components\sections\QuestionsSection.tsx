import { useState, useMemo } from 'react';
import { ChevronDown, HelpCircle, CheckCircle2, Lightbulb, PenLine } from 'lucide-react';
import { chapterLabel, lessons, chapters } from '@/data/lessons';
import { chapterSoft } from '@/lib/chapterTheme';

interface QuestionsSectionProps {
  searchQuery: string;
}

export default function QuestionsSection({ searchQuery }: QuestionsSectionProps) {
  const [expandedIds, setExpandedIds] = useState<Set<string>>(new Set());
  const [selectedChapter, setSelectedChapter] = useState<number>(0);

  const filtered = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    if (!q) return lessons;
    return lessons.filter(
      (l) =>
        l.title.toLowerCase().includes(q) ||
        l.questions.some((qs) => qs.q.toLowerCase().includes(q))
    );
  }, [searchQuery]);

  const chapterLessons = filtered.filter(
    (l) => l.chapter === selectedChapter || selectedChapter === 0
  );

  const toggle = (key: string) => {
    setExpandedIds((prev) => {
      const next = new Set(prev);
      if (next.has(key)) next.delete(key);
      else next.add(key);
      return next;
    });
  };

  return (
    <div className="space-y-6">
      <div className="bg-white dark:bg-slate-900 rounded-2xl p-6 shadow-sm border border-slate-100 dark:border-slate-800">
        <div className="flex items-center gap-3 mb-4">
          <div className="w-12 h-12 bg-emerald-50 dark:bg-emerald-500/15 rounded-xl flex items-center justify-center">
            <HelpCircle className="w-6 h-6 text-emerald-600 dark:text-emerald-300" />
          </div>
          <div>
            <h2 className="text-xl font-bold text-slate-800 dark:text-slate-100">بنك الأسئلة والحلول المفصلة</h2>
            <p className="text-sm text-slate-500 dark:text-slate-300">أسئلة شهيرة مع حل مفصل خطوة بخطوة</p>
          </div>
        </div>

        <div className="flex gap-2 flex-wrap">
          <button
            onClick={() => setSelectedChapter(0)}
            className={`px-4 py-2 rounded-lg text-sm font-semibold transition-all ${
              selectedChapter === 0
                ? 'bg-primary-600 text-white shadow-md'
                : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700'
            }`}
          >
            جميع الأسئلة
          </button>
          {chapters.map((ch) => (
            <button
              key={ch.id}
              onClick={() => setSelectedChapter(ch.id)}
              className={`px-4 py-2 rounded-lg text-sm font-semibold transition-all text-right ${
                selectedChapter === ch.id
                  ? 'bg-primary-600 text-white shadow-md'
                  : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700'
              }`}
            >
              <span className="block">{ch.title}</span>
              <span className="block text-[11px] font-normal opacity-80">{ch.subtitle}</span>
            </button>
          ))}
        </div>
      </div>

      <div className="space-y-4">
        {chapterLessons.map((lesson) => (
          <div key={lesson.id} className="space-y-3">
            <div className="flex items-center gap-2 px-1">
              <span className={`text-xs font-bold px-3 py-1 rounded-full ${chapterSoft[lesson.chapter]}`}>
                درس {lesson.id} — {chapterLabel(lesson.chapter)}
              </span>
              <h3 className="text-sm font-bold text-slate-700 dark:text-slate-100">{lesson.title}</h3>
            </div>

            {lesson.questions.map((question, qIdx) => {
              const key = `${lesson.id}-${qIdx}`;
              const isOpen = expandedIds.has(key);
              return (
                <div
                  key={key}
                  className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-100 dark:border-slate-800 shadow-sm overflow-hidden transition-all hover:shadow-md"
                >
                  <button
                    onClick={() => toggle(key)}
                    className="w-full flex items-start gap-3 p-4 text-right hover:bg-slate-50/50 transition-colors"
                  >
                    <div className="flex-shrink-0 w-8 h-8 bg-amber-50 dark:bg-amber-500/15 rounded-lg flex items-center justify-center mt-0.5">
                      <PenLine className="w-4 h-4 text-amber-600 dark:text-amber-300" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-semibold text-slate-700 dark:text-slate-100 leading-relaxed">{question.q}</p>
                    </div>
                    <ChevronDown
                      className={`w-5 h-5 text-slate-400 dark:text-slate-500 flex-shrink-0 transition-transform mt-1 ${
                        isOpen ? 'rotate-180' : ''
                      }`}
                    />
                  </button>

                  {isOpen && (
                    <div className="px-4 pb-4 animate-slide-down">
                      <div className="border-t border-slate-100 dark:border-slate-800 pt-3">
                        <div className="flex items-center gap-2 mb-3">
                          <Lightbulb className="w-4 h-4 text-amber-500 dark:text-amber-300" />
                          <h4 className="text-sm font-bold text-slate-600 dark:text-slate-300">الحل مفصل خطوة بخطوة:</h4>
                        </div>
                        <div className="space-y-2">
                          {question.steps.map((step, idx) => (
                            <div
                              key={idx}
                              className="flex items-start gap-3 bg-slate-50 dark:bg-slate-800 rounded-lg p-3 animate-slide-up"
                              style={{ animationDelay: `${idx * 50}ms` }}
                            >
                              <span className="flex-shrink-0 w-6 h-6 bg-primary-600 text-white rounded-full flex items-center justify-center text-xs font-bold">
                                {idx + 1}
                              </span>
                              <p className="text-sm text-slate-700 dark:text-slate-100 leading-relaxed" dir="auto">
                                {step}
                              </p>
                            </div>
                          ))}
                        </div>

                        <div className="mt-3 flex items-center gap-2 bg-emerald-50 dark:bg-emerald-500/15 rounded-xl p-3 border border-emerald-100 dark:border-emerald-500/30">
                          <CheckCircle2 className="w-5 h-5 text-emerald-600 dark:text-emerald-300 flex-shrink-0" />
                          <p className="text-sm font-bold text-emerald-800 dark:text-emerald-200">{question.answer}</p>
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        ))}
      </div>

      {chapterLessons.length === 0 && (
        <div className="text-center py-12 text-slate-400 dark:text-slate-500">
          <HelpCircle className="w-12 h-12 mx-auto mb-3 opacity-40" />
          <p>لا توجد أسئلة مطابقة لبحثك</p>
        </div>
      )}
    </div>
  );
}
