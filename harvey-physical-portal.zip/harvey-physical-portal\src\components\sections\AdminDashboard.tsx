import { useState, useEffect } from 'react';
import {
  Shield,
  Users,
  MessageSquare,
  TrendingUp,
  Calendar,
  Mail,
  ArrowLeft,
  LogOut,
} from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/context/AuthContext';

interface StudentProfile {
  id: string;
  full_name: string;
  email: string;
  created_at: string;
}

interface AdminDashboardProps {
  onBack: () => void;
}

export default function AdminDashboard({ onBack }: AdminDashboardProps) {
  const { profile, signOut } = useAuth();
  const [students, setStudents] = useState<StudentProfile[]>([]);
  const [totalQueries, setTotalQueries] = useState(0);
  const [dataLoading, setDataLoading] = useState(true);
  const [accessError, setAccessError] = useState<string | null>(null);

  useEffect(() => {
    (async () => {
      try {
        const { data: studentsData, error } = await supabase
          .from('profiles')
          .select('id, full_name, email, created_at')
          .order('created_at', { ascending: false });
        if (error) {
          setAccessError(
            `تعذّر قراءة بيانات الطلاب: ${error.message} — تأكد من تنفيذ migration تأمين الصلاحيات وأن هذا الحساب role='admin'.`,
          );
        }
        setStudents((studentsData as StudentProfile[]) ?? []);

        const { count } = await supabase
          .from('ai_queries')
          .select('*', { count: 'exact', head: true });
        setTotalQueries(count ?? 0);
      } catch {
        setAccessError('تعذّر الاتصال بقاعدة البيانات.');
      }
      setDataLoading(false);
    })();
  }, []);

  const formatDate = (d: string) => {
    return new Date(d).toLocaleDateString('ar-EG', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
    });
  };

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-800">
      <div className="bg-gradient-to-l from-slate-900 to-slate-800 text-white">
        <div className="max-w-6xl mx-auto px-4 lg:px-8 py-6 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 bg-amber-500 rounded-xl flex items-center justify-center">
              <Shield className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="text-xl font-bold">لوحة تحكم الإدارة</h1>
              <p className="text-sm text-slate-400 dark:text-slate-500">{profile.full_name || profile.email}</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={() => void signOut().then(onBack)}
              className="flex items-center gap-2 px-4 py-2 bg-error-600 hover:bg-error-700 rounded-xl text-sm font-semibold transition-all"
            >
              <LogOut className="w-4 h-4" />
              خروج
            </button>
            <button
              onClick={onBack}
              className="flex items-center gap-2 px-4 py-2 bg-white/10 hover:bg-white/20 rounded-xl text-sm font-semibold transition-all"
            >
              <ArrowLeft className="w-4 h-4" />
              العودة للمنصة
            </button>
          </div>
        </div>
      </div>

      <div className="max-w-6xl mx-auto p-4 lg:p-8 space-y-6">
        {accessError && (
          <div className="bg-amber-50 dark:bg-amber-500/15 border border-amber-200 dark:border-amber-500/30 rounded-xl p-4 text-center">
            <p className="text-sm text-amber-700 dark:text-amber-300 font-semibold">{accessError}</p>
          </div>
        )}

        <div className="bg-primary-50 dark:bg-primary-500/15 border border-primary-100 dark:border-primary-500/30 rounded-xl p-4 text-center">
          <p className="text-sm text-primary-700 dark:text-primary-300">
            الدخول تم عبر جلسة Supabase — الصلاحية من عمود <span className="font-bold">role</span> في جدول
            <span className="font-bold"> profiles</span>. تم إنشاء هذا الموقع بواسطة{' '}
            <span className="font-bold">محمد علي الدفراوي</span>
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <div className="bg-white dark:bg-slate-900 rounded-2xl p-5 shadow-sm border border-slate-100 dark:border-slate-800">
            <div className="flex items-center gap-3 mb-3">
              <div className="w-10 h-10 bg-blue-50 dark:bg-blue-500/15 rounded-lg flex items-center justify-center">
                <Users className="w-5 h-5 text-blue-600 dark:text-blue-300" />
              </div>
              <p className="text-sm text-slate-500 dark:text-slate-300">إجمالي الطلاب</p>
            </div>
            <p className="text-3xl font-bold text-slate-800 dark:text-slate-100">
              {dataLoading ? '...' : students.length}
            </p>
          </div>

          <div className="bg-white dark:bg-slate-900 rounded-2xl p-5 shadow-sm border border-slate-100 dark:border-slate-800">
            <div className="flex items-center gap-3 mb-3">
              <div className="w-10 h-10 bg-emerald-50 dark:bg-emerald-500/15 rounded-lg flex items-center justify-center">
                <MessageSquare className="w-5 h-5 text-emerald-600 dark:text-emerald-300" />
              </div>
              <p className="text-sm text-slate-500 dark:text-slate-300">إجمالي استفسارات الذكاء الاصطناعي</p>
            </div>
            <p className="text-3xl font-bold text-slate-800 dark:text-slate-100">
              {dataLoading ? '...' : totalQueries}
            </p>
            <p className="mt-2 text-xs text-slate-400 dark:text-slate-500">
              يُسجَّل استفسار المساعد للطلاب الذين دخلوا بحساب فقط.
            </p>
          </div>

          <div className="bg-white dark:bg-slate-900 rounded-2xl p-5 shadow-sm border border-slate-100 dark:border-slate-800">
            <div className="flex items-center gap-3 mb-3">
              <div className="w-10 h-10 bg-amber-50 dark:bg-amber-500/15 rounded-lg flex items-center justify-center">
                <TrendingUp className="w-5 h-5 text-amber-600 dark:text-amber-300" />
              </div>
              <p className="text-sm text-slate-500 dark:text-slate-300">متوسط الاستفسارات لكل طالب</p>
            </div>
            <p className="text-3xl font-bold text-slate-800 dark:text-slate-100">
              {dataLoading || students.length === 0
                ? '...'
                : (totalQueries / students.length).toFixed(1)}
            </p>
          </div>
        </div>

        <div className="bg-white dark:bg-slate-900 rounded-2xl shadow-sm border border-slate-100 dark:border-slate-800 overflow-hidden">
          <div className="p-5 border-b border-slate-100 dark:border-slate-800">
            <h2 className="font-bold text-slate-800 dark:text-slate-100 flex items-center gap-2">
              <Users className="w-5 h-5 text-primary-600 dark:text-primary-300" />
              قائمة الطلاب المسجلين
            </h2>
          </div>

          {dataLoading ? (
            <div className="p-8 text-center text-slate-400 dark:text-slate-500">جاري التحميل...</div>
          ) : students.length === 0 ? (
            <div className="p-8 text-center text-slate-400 dark:text-slate-500">لا يوجد طلاب مسجلون بعد</div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="bg-slate-50 dark:bg-slate-800">
                    <th className="p-3 text-right font-bold text-slate-700 dark:text-slate-100 text-xs">الاسم</th>
                    <th className="p-3 text-right font-bold text-slate-700 dark:text-slate-100 text-xs">البريد الإلكتروني</th>
                    <th className="p-3 text-right font-bold text-slate-700 dark:text-slate-100 text-xs">تاريخ التسجيل</th>
                  </tr>
                </thead>
                <tbody>
                  {students.map((student) => (
                    <tr
                      key={student.id}
                      className="border-b border-slate-50 dark:border-slate-800 hover:bg-slate-50/50 transition-colors"
                    >
                      <td className="p-3">
                        <div className="flex items-center gap-2">
                          <div className="w-8 h-8 bg-gradient-to-br from-primary-500 to-primary-700 rounded-full flex items-center justify-center text-xs font-bold text-white">
                            {student.full_name?.charAt(0) || student.email?.charAt(0).toUpperCase()}
                          </div>
                          <span className="text-xs text-slate-700 dark:text-slate-100 font-semibold">
                            {student.full_name || 'بدون اسم'}
                          </span>
                        </div>
                      </td>
                      <td className="p-3">
                        <div className="flex items-center gap-1.5 text-xs text-slate-500 dark:text-slate-300">
                          <Mail className="w-3.5 h-3.5" />
                          {student.email}
                        </div>
                      </td>
                      <td className="p-3">
                        <div className="flex items-center gap-1.5 text-xs text-slate-500 dark:text-slate-300">
                          <Calendar className="w-3.5 h-3.5" />
                          {formatDate(student.created_at)}
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
