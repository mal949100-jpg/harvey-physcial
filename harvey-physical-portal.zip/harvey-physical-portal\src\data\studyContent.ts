import { lessons } from '@/data/lessons';
import { generateQuizQuestions, QUESTIONS_PER_MODEL } from '@/data/quizGenerator';
import type { ChapterId } from '@/data/lessonTypes';

export interface QuizQuestion {
  id: string;
  topic: string;
  question: string;
  choices: string[];
  correctIndex: number;
  explanation: string;
  steps: string[];
}

export type QuizDifficulty = 'easy' | 'medium' | 'hard';

export interface Quiz {
  id: string;
  title: string;
  description: string;
  chapter: ChapterId;
  lessonId: number;
  lessonTitle: string;
  difficulty: QuizDifficulty;
  questions: QuizQuestion[];
}

const difficultyConfig: { key: QuizDifficulty; title: string; description: string }[] = [
  { key: 'easy', title: 'النموذج الأول — سهل مباشر', description: 'مفاهيم أساسية وتطبيقات مباشرة من الدرس' },
  { key: 'medium', title: 'النموذج الثاني — متوسط تطبيقي', description: 'تطبيقات متعددة الخطوات وتحليل العلاقات' },
  { key: 'hard', title: 'النموذج الثالث — صعب متقدم', description: 'أفكار عليا وتريكات امتحانية' },
];

export const ministryQuizzes: Quiz[] = lessons.flatMap((lesson) =>
  difficultyConfig.map((model) => ({
    id: `lesson-${lesson.id}-${model.key}`,
    title: `${lesson.title} — ${model.title}`,
    description: model.description,
    chapter: lesson.chapter,
    lessonId: lesson.id,
    lessonTitle: lesson.title,
    difficulty: model.key,
    questions: generateQuizQuestions(lesson, model.key, QUESTIONS_PER_MODEL),
  })),
);

export interface Flashcard {
  id: string;
  front: string;
  back: string;
  category: string;
  lessonId?: number;
  chapter?: ChapterId;
}

/** Curated quick-review deck — the laws a student is asked to memorise verbatim. */
const CURATED_CARDS: Flashcard[] = [

  { id: 'fc1', front: 'السرعة النسبية', back: 'v_AB = v_A - v_B\nسرعة الجسم A بالنسبة لـ B = فرق متجهي السرعتين', category: 'الميكانيكا' },
  { id: 'fc2', front: 'مدى المقذوف', back: 'R = v₀²sin(2θ) / g\nأقصى مدى عند θ = 45°', category: 'الميكانيكا' },
  { id: 'fc3', front: 'أقصى ارتفاع للمقذوف', back: 'H = v₀²sin²θ / (2g)', category: 'الميكانيكا' },
  { id: 'fc4', front: 'عزم القوة', back: 'τ = F × d\nالقوة × الذراع العمودي، الوحدة N·m', category: 'الميكانيكا' },
  { id: 'fc5', front: 'الاتزان الانتقالي', back: 'ΣF = 0\nمجموع القوى = صفر في كل محور', category: 'الميكانيكا' },
  { id: 'fc6', front: 'الاتزان الدوراني', back: 'Στ = 0\nمجموع العزوم = صفر حول أي نقطة', category: 'الميكانيكا' },
  { id: 'fc7', front: 'القدرة', back: 'P = W / t = F × v\nالوحدة: Watt (W)', category: 'الميكانيكا' },
  { id: 'fc8', front: 'الكفاءة', back: 'η = (P_out / P_in) × 100%\nدائماً أقل من 100%', category: 'الميكانيكا' },
  { id: 'fc9', front: 'كمية الحركة', back: 'p = m × v\nالوحدة: kg·m/s، كمية متجهة', category: 'الميكانيكا' },
  { id: 'fc10', front: 'الدفع', back: 'J = F × Δt = Δp\nيساوي التغير في كمية الحركة', category: 'الميكانيكا' },
  { id: 'fc11', front: 'القوة المركزية', back: 'F = mv² / r\nتجه نحو المركز، الوحدة N', category: 'الميكانيكا' },
  { id: 'fc12', front: 'الزمن الدوري الدائري', back: 'T = 2πr / v = 2π/ω', category: 'الميكانيكا' },
  { id: 'fc13', front: 'الجاذبية الكونية', back: 'F = Gm₁m₂ / r²\nG = 6.67×10⁻¹¹ N·m²/kg²', category: 'الميكانيكا' },
  { id: 'fc14', front: 'بندول زنبركي', back: 'T = 2π√(m / k)\nلا يعتمد على g', category: 'الموجات' },
  { id: 'fc15', front: 'بندول بسيط', back: 'T = 2π√(L / g)\nلا يعتمد على الكتلة', category: 'الموجات' },
  { id: 'fc16', front: 'قانون هوك', back: 'F = -kx\nالقوة المرونية ∝ الإزاحة وعكس اتجاهها', category: 'الموجات' },
  { id: 'fc17', front: 'سرعة الموجة', back: 'v = λ × f\nالطول الموجي × التردد', category: 'الموجات' },
  { id: 'fc18', front: 'التداخل البناء', back: 'Δx = nλ\nفرق المسار = عدد صحيح من الأطوال الموجية', category: 'الموجات' },
  { id: 'fc19', front: 'التداخل الهدام', back: 'Δx = (n + ½)λ\nفرق المسار = عدد نصفي من الأطوال الموجية', category: 'الموجات' },
  { id: 'fc20', front: 'الطاقة المرونية', back: 'PE = ½kx²\nطاقة مخزنة في النابض', category: 'الموجات' },

  { id: 'fc21', front: 'قانون كولوم', back: 'F = k q₁q₂ / r²\nk = 9×10⁹ N·m²/C² — القوة تتناسب عكسياً مع مربع المسافة', category: 'الكهرباء والمغناطيسية' },
  { id: 'fc22', front: 'شدة المجال الكهربائي', back: 'E = F / q = kQ / r²\nالوحدة N/C أو V/m', category: 'الكهرباء والمغناطيسية' },
  { id: 'fc23', front: 'فرق الجهد', back: 'V = W / Q\nالوحدة Volt (J/C)', category: 'الكهرباء والمغناطيسية' },
  { id: 'fc24', front: 'السعة الكهربائية', back: 'C = Q / V\nالوحدة Farad (C/V)، والموازي C = ε₀A / d', category: 'الكهرباء والمغناطيسية' },
  { id: 'fc25', front: 'قانون أوم', back: 'V = I × R\nبثبات درجة الحرارة', category: 'الكهرباء والمغناطيسية' },
  { id: 'fc26', front: 'المقاومة النوعية', back: 'R = ρL / A\nρ وحدة Ω·m، تعتمد على المادة ودرجة الحرارة', category: 'الكهرباء والمغناطيسية' },
  { id: 'fc27', front: 'القدرة الكهربائية', back: 'P = V I = I²R = V²/R\nالوحدة Watt', category: 'الكهرباء والمغناطيسية' },
  { id: 'fc28', front: 'التوالي والتوازي', back: 'توالي: R = R₁+R₂ ، I ثابتة\nتوازي: 1/R = 1/R₁+1/R₂ ، V ثابت', category: 'الكهرباء والمغناطيسية' },
  { id: 'fc29', front: 'القوة على موصل في مجال', back: 'F = B I L sinθ\nالوحدة N، والمجال B بوحدة Tesla', category: 'الكهرباء والمغناطيسية' },
  { id: 'fc30', front: 'قانون فاراديه', back: 'emf = -N ΔΦ / Δt\nالقوة الدافعة ∝ معدل التغير في الفيض', category: 'الكهرباء والمغناطيسية' },
  { id: 'fc31', front: 'المحول الكهربائي', back: 'V₂/V₁ = N₂/N₁\nالقدرة ثابتة مثالياً: V₁I₁ = V₂I₂', category: 'الكهرباء والمغناطيسية' },
  { id: 'fc32', front: 'التيار المتردد', back: 'I = I₀ sin(ωt)\nI_rms = I₀/√2 ، V_rms = V₀/√2', category: 'الكهرباء والمغناطيسية' },

  { id: 'fc33', front: 'علاقة بلانك', back: 'E = h f = h c / λ\nh = 6.63×10⁻³⁴ J·s', category: 'الفيزياء الحديثة' },
  { id: 'fc34', front: 'التأثير الكهروضوئي', back: 'KEmax = h f - Φ\nلا انبعاث إذا f < تردد العتبة f₀', category: 'الفيزياء الحديثة' },
  { id: 'fc35', front: 'شغل الهدم', back: 'Φ = h f₀\nالحد الأدنى من الطاقة لنزع إلكترون من السطح', category: 'الفيزياء الحديثة' },
  { id: 'fc36', front: 'طول دي برولي', back: 'λ = h / (m v)\nكل جسم متحرك له طول موجي مصاحب', category: 'الفيزياء الحديثة' },
  { id: 'fc37', front: 'تأثير كومبتون', back: 'Δλ = h/(mₑc) (1 - cosθ)\nيثبت للفوتون زخماً', category: 'الفيزياء الحديثة' },
  { id: 'fc38', front: 'طاقة مستوى الهيدروجين', back: 'Eₙ = -13.6 / n²  eV\nn = 1 الحالة الأرضية', category: 'الفيزياء الحديثة' },
  { id: 'fc39', front: 'سلسلة بالمر', back: 'انتقالات إلى n = 2\nتقع في المنطقة المرئية من الطيف', category: 'الفيزياء الحديثة' },
  { id: 'fc40', front: 'قانون التحلل الإشعاعي', back: 'N = N₀ e^(-λt)\nالنشاط يقل أسياً مع الزمن', category: 'الفيزياء الحديثة' },
  { id: 'fc41', front: 'عمر النصف', back: 'T½ = 0.693 / λ\nزمن اضمحلال نصف الأنوية', category: 'الفيزياء الحديثة' },
  { id: 'fc42', front: 'تكافؤ الكتلة والطاقة', back: 'E = Δm c²\n1 u ≈ 931.5 MeV', category: 'الفيزياء الحديثة' },
  { id: 'fc43', front: 'الانشطار والاندماج', back: 'انشطار: ثقيل → خفيف + طاقة\nاندماج: خفيف → ثقيل + طاقة أكبر لكل كتلة', category: 'الفيزياء الحديثة' },
];

const cardCategoryChapter: Record<string, ChapterId> = {
  الميكانيكا: 1,
  الموجات: 2,
  'الكهرباء والمغناطيسية': 3,
  'الفيزياء الحديثة': 4,
};

/** lessonId 0 marks the memorise-by-heart deck, used by the flashcard filters. */
export const coreFlashcards: Flashcard[] = CURATED_CARDS.map((card) => ({
  ...card,
  lessonId: 0,
  chapter: cardCategoryChapter[card.category] ?? 1,
}));

/**
 * One card per law and per concept of every lesson, so the flashcard deck really
 * covers the whole syllabus instead of only the mechanics basics. The ministry layer
 * (terms/notes/reasons/capsule) adds the definition, observation and «علل» decks.
 */
const lessonFlashcards: Flashcard[] = lessons.flatMap((lesson) => [
  ...lesson.laws.map((law, i) => ({
    id: `fc-l${lesson.id}-law${i + 1}`,
    front: `${law.name}`,
    back: `${law.formula}\nالوحدة: ${law.units}\n${law.explanation}`,
    category: lesson.title,
    lessonId: lesson.id,
    chapter: lesson.chapter,
  })),
  ...lesson.concepts.map((concept, i) => ({
    id: `fc-l${lesson.id}-c${i + 1}`,
    front: `${concept.title}`,
    back: `${concept.detail}\n— درس: ${lesson.title}`,
    category: lesson.title,
    lessonId: lesson.id,
    chapter: lesson.chapter,
  })),
  ...(lesson.terms ?? []).map((term, i) => ({
    id: `fc-l${lesson.id}-t${i + 1}`,
    front: `${term.term}`,
    back: `${term.meaning}\n— مصطلح من درس: ${lesson.title}`,
    category: lesson.title,
    lessonId: lesson.id,
    chapter: lesson.chapter,
  })),
  ...(lesson.reasons ?? []).map((reason, i) => ({
    id: `fc-l${lesson.id}-r${i + 1}`,
    front: reason.question,
    back: `${reason.answer}\n— تعليل من درس: ${lesson.title}`,
    category: lesson.title,
    lessonId: lesson.id,
    chapter: lesson.chapter,
  })),
  ...(lesson.notes ?? []).map((note, i) => ({
    id: `fc-l${lesson.id}-n${i + 1}`,
    front: `ملاحظة ${i + 1} — ${lesson.title}`,
    back: note,
    category: lesson.title,
    lessonId: lesson.id,
    chapter: lesson.chapter,
  })),
  ...(lesson.capsule && lesson.capsule.length > 0
    ? [
        {
          id: `fc-l${lesson.id}-capsule`,
          front: `كبسولة مراجعة: ${lesson.title}`,
          back: lesson.capsule.join('\n• '),
          category: lesson.title,
          lessonId: lesson.id,
          chapter: lesson.chapter,
        },
      ]
    : []),
]);

export const flashcards: Flashcard[] = [...coreFlashcards, ...lessonFlashcards];
